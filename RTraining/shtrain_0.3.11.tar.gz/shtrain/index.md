[Dev site](file://sandhills.int/file/Data/DTA/R/Resources/website/dev/index.html)
[Live site](file://sandhills.int/file/Data/DTA/R/Resources/website/index.html)



# Internal packages

Sandhills has 5 internal packages, shconfig2, shtrain, shapi, savin, and shreport. This website
is primarily focused on shtrain, since that is what the majority of our work uses.

shconfig2 is used to manage shared libraries and work with our different environments --
you working interactively at your computer versus something automated running on a server.

shtrain includes the most content. It has data access functions, conveniences
for cleaning data, along with functions to capture our process for re-use in SQL for FE.

shapi is an interface to the web APIs at Sandhills. This includes MakeModelManager (MMM)
and EquipmentEvaluation. Most of the interfaces are rough copies of what is on the web API
test page, but there is ongoing work to encapsulate the most used API methods in more
convenient R functions.

savin is an R6 interface to access VIN data and work with it in R. Provides the raw data, 
methods for merging it to listings, removing disagreeing values from listings, and summary
statistics comparing the two sets of information.

shreport is a major work in progress, and does not offer any stable tools at this point.
The goal is to provide a set of functions to generate reports, leading to more consistently
formatted results for consumption by others.

## Installation 

Only one package (shconfig2) needs to be installed in your user library. Most R installations 
have two libraries: user and system. We will have three: user, system, and shared. shconfig2
provides the tools necessary for accessing the shared library.


```{r}
### Install shconfig2 first.
install.packages("//sandhills.int/file/Data/DTA/R/InternalPackages/shconfig2_0.1.2.zip",
                 repos = NULL, 
                 type = "win.binary")

### Load and attach shconfig2.
library(shconfig2)
### This loads our most-used packages, including shtrain.
load_packages()
### `search()` shows what packages are loaded for use.
search()

```
## Adding Content to DTA Reference Website

1. Open Rstudio.   
If already opened, restart your R session by navigating "Session" -> "Restart R", or Ctrl+Shift+F10.

2. If you've done package development, jump to step 3. Otherwise, copy all folders [here](file://sandhills.int/file/Data/DTA/R/Rlibaries/2017-10-15)
to [here](%USERPROFILE%\Documents\R\win-library\3.3).   
Accept all overwrites if applicable.

3.	[In TFS](file://sandhills.int/file/Data/DTA/R/learning/resources/HowTo-TFS-ChangesAndShelvesets.html):
    
    a.	Navigate to /DataAnalytics/shtrain/
    
    b.	Highlight shtrain, right-click and select 'Get Latest Version'
    
    c.	Right-click and 'Check Out for Edit...'

4.	In Rstudio, Open Project, shtrain 

5.	Open the pertinent target file to update/add new information/article links, etc, such as: 	
    
    * [Homepage](file://sandhills.int/file/Data/DTA/R/Resources/website/index.html)
  
                ( [index.md](file://sandhills/SandhillsSoftware/DataAnalytics/shtrain/index.md) )
    
     * [Resources](file://sandhills.int/file/Data/DTA/R/Resources/website/articles/resources.html)
  
                ( [vignettes](file://sandhills/SandhillsSoftware/DataAnalytics/shtrain/vignettes) )

6.	Determine what part of the website to update and run the appropriate statement [refer to pkgdown.r-lib.org](https://pkgdown.r-lib.org/articles/pkgdown.html), such as: 
    
    * All articles: pkgdown::build_articles() 
      
    * One particular section: [pkgdown::build_article('resources')](file://sandhills/SandhillsSoftware/DataAnalytics/shtrain/vignettes/)
      
    * A new article by creating one in the vignettes folder with the correct headings (copy from another vignette)

    * To update the home page, run, pkgdown::build_home()

    * To add to one of the drop-downs, edit the pkgdown.yml file in shtrain (there is a section at the end that defines the menus. Should be relatively self-explanatory with some trial and error) using the current format as a guide, then run pkgdown::build_site()

    * For any of the above, to include images in the narrative, use:   `![](vignettes/img/website_setup/FILENAME.png)`. You can put captions in the square brackets, but it seems to work best to enter descriptions separately. Use the SnagIt tool to take pictures and crop. Once started, you can use ctrl+shift+x to bring it to the foreground. SnagIT has lots of different modes to help you capture menus, etc.

7.	Check in change for the single file you edited, then undo pending changes on rest of shtrain.


## Usage

See individual function documentation on the details of what each does.   
The below was updated on `2019-06-06`, with `shtrain_0.3.5`.
```{r}
library(shconfig2)
set_library("2017-10-15")
set_wd()
load_packages()

# set_auction_bounds(1000, 120000) ### no longer necessary
set_retail_bounds(2000, 150000)

con <- create_server_connection()
all_data <- get_all_data(con = con,
                         category_id = 1038,
                         selections = c("hours", "horse_power", "capacity"),
                         archive = TRUE,
                         invalid_aftersale = TRUE)
                         
all_data <- mm_check(all_data)
                         
### Adds all default and supplemental specs for the category.
all_data <- add_specs(con = con, 
                      data = all_data, 
                      selections = c(str_c("sup_", c("year", "hours", "horse_power", "capacity", 
                                                     "does_not_run", "engine_rebuilt", 
                                                     "transmission_rebuilt", "hours_meter_inaccurate")),
                                     str_c("def_", c("horse_power", "capacity"))))
odbcClose(con)

### Basic formatting of the data.
all_data <- recipe(all_data, info = NULL) %>%
  add_date() %>%
  format_numeric() %>%
  format_character() %>%
  step_validate(validate = list(horse_power = c(9, 200), 
                                capacity = c(500, 30000), 
                                hours = c(1, 20000))) %>%
  add_region(region_list = list("united kingdom" = c("united kingdom", "ireland"))) %>%
  trained()

### Apply filters to the data. 
filtered_data <- recipe(all_data, info = NULL) %>%
  filter_company_id() %>%
  filter_review_status_id() %>%
  filter_event_type_id() %>%
  filter_sale_currency() %>%
  filter_sale_status() %>%
  filter_sale_type() %>% 
  filter_exclude_hi_lo_avg() %>%
  filter_auction_exclusions() %>%
  filter_aftersale_exclusions() %>%
  filter_year() %>%
  filter_sale_date() %>%
  filter_condition() %>%
  filter_sup_conditions %>%
  filter_country(include = c("united kingdom", "ireland")) %>%
  step_validate(validate = list(usd_sale_price = c(500, 80000), 
                                usd_list_price = c(1000, 85000))) %>% 
  filter(odc_status == "active") %>% 
trained()

### Very basic feature engineering.
feature_data <- recipe(filtered_data, info = NULL) %>%
  step_coalesce(order = c("dlr", "sup", "def", "imp")) %>% 
  add_age() %>%
  step_dt(NULL, `:=`(mean_usd_sale_price = mean(usd_sale_price, na.rm = TRUE),
                     med_usd_sale_price = median(usd_sale_price, na.rm = TRUE),
                     sd_usd_sale_price = sd(usd_sale_price, na.rm = TRUE))) %>% 
trained()

```