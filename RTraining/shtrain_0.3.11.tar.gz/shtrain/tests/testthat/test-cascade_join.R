context("test-cascade_join.R")
library(data.table)
library(testthat)
library(shtrain)
dt <- data.table(x = letters, y = letters, z = letters, val = 1:26)
lookup <- rbind(data.table(x = c(letters[1:25], NA_character_),
                     y = c(letters[1:24], NA_character_, NA_character_),
                     z = c(letters[1:23], rep(NA_character_, 3)),
                     new_val = c(1:23, 40, 50, 60)),
                data.table(x = "x", y = "x", z = "x", new_val = 1e4))


test_that("`limit == 0` works correctly.", {
  expected <- cascade_join(dt, lookup, on = c("x", "y", "z"), limit = 0)
  expect_equal_to_reference(expected, file = "rds/cascade_join-limit0.rds")
})

test_that("The most specific join value is used.", {
  expected <- cascade_join(dt, lookup, on = c("x", "y", "z"), limit = 1)
  expect_equal_to_reference(expected, file = "rds/cascade_join-most_specific.rds")
})

test_that("`step_cascade_join()` matches `cascade_join()` results.",
          {
            expected <- recipe(dt) %>% step_cascade_join(lookup, on = c("x", "y", "z"), limit = 1) %>% trained()
            expect_equal_to_reference(expected, file = "rds/cascade_join-most_specific.rds")
            expected <- recipe(dt) %>% step_cascade_join(lookup, on = c("x", "y", "z"), limit = 0) %>% trained()
            expect_equal_to_reference(expected, file = "rds/cascade_join-limit0.rds")
          })