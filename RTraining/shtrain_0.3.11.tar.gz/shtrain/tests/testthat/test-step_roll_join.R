context("test-step_roll_join.R")

library(data.table)
library(testthat)
library(shtrain)
dt <- data.table(x = letters, date = seq(as.Date("2015-01-01"), by = "1 day", length.out = 26))
lookup <- data.table(value = 1:10, date = seq(as.Date("2014-12-31"), by = "5 days", length.out = 10))
test_that("Equivalent to data.table rolling join.", {
 dt_value <- lookup[dt, on = 'date', roll = 2, rollends = rep(TRUE, 2)]
 step_value <- recipe(dt) %>%
   step_roll_join(lookup, on = "date", roll = 2, rollends = rep(TRUE, 2)) %>%
   trained()
 expect_identical(step_value, dt_value)
})

