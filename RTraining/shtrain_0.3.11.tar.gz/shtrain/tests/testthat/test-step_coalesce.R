context("test-step_coalesce.R")
library(shtrain)
library(dplyr)
library(data.table)
library(testthat)
cache_names(r = shtrain:::shdata$name_table$r, sql = shtrain:::shdata$name_table$sql)
cache_names(r = 'make_model', sql = "MakeModel")
test_that("Specs are replaced in order.", {
  set.seed(702)
  dt <- data.table(capacity = sample(c(1, NA), 10, replace = TRUE), def_capacity = sample(c(2, NA), 10, replace = TRUE),
                   imp_capacity = sample(c(4, NA),prob = c(.95, .05), 10, replace = TRUE))
  testthat::expect_equal_to_reference(recipe(dt) %>% step_coalesce(order = c("dlr", "def", "imp")) %>% trained(), file = "rds/step_coalesce.rds")
})
