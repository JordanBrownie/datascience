context("test-fix_numerics.R")

#step_dimensions
test_that("Dimension data is cleaned and scaled",{
dt_dm <- data.table(length = c(53, 50.5, "11'6\"", "53'", 1728, "46 1/2", "46.5'", "48ft", "19ft, 5ft tail", "48x102", "45-74", "14+2", "32' & 28'"))
expected_dm <- data.table(length = c(636, 606, 138, 636, 144, 552, 558, 576, 228, 576, 540, 168, 384))
dt_dm <- recipe(dt_dm) %>% step_dimensions("length", unit = c("foot" = 60), base_unit = c("inch" = 720)) %>% prep() %>% bake()
expect_equal(dt_dm, expected_dm)
})

#step_spacings
test_that("Spacing data is cleaned and scaled",{
  dt_sp <- data.table(row_spacing = c("12.4in", 18, "14 in", "12\""))
  expected_sp <- data.table(row_spacing = c(12.4, 18, 14, 12))
  dt_sp <- step_spacings(recipe(dt_sp), "row_spacing") %>% prep() %>% bake()
  expect_equal(dt_sp, expected_sp)
})

#step_counts_usage
test_that("Count (usage) data is cleaned and scaled",{
  dt_dm <- data.table(num_bales = c("10k", "12000-15000", "12000", "12.000", "15,000", "approx12000", ">1500"))
  expected_dm <- data.table(num_bales = c(10000, 15000, 12000, 12000, 15000, 12000, 1500))
  dt_dm <- recipe(dt_dm) %>% step_counts_usage("num_bales") %>% trained()
  expect_equal(dt_dm, expected_dm)
  dt2 <- data.table(num_bales = paste0(1:10, ",000"))
  dt2 <- recipe(dt2) %>% step_counts_usage("num_bales") %>% trained()
  expected_dt2 <- data.table(num_bales = (1:10)*1e3)
  expect_equal(dt2, expected_dt2)


})



##step_mass
#test_that("Mass data is cleaned and scaled",{
#  dt_ms <- data.table(gross_vehicle_weight = c("approx 12,540#", "15,000lbs", "15000kg-16000kg", "33,000 GVW", "18000 kg", "12 tons", "13mt", 12, "all of it"))
#  expected_ms <- data.table(gross_vehicle_weight = c(12540, 15000, NA, 33000, 39683.20716, 24000, 28660.09406, 12000, NA))
#  dt_ms <- step_mass(dt_ms, "gross_vehicle_weight", unit = c("ton" = 50, "kilogram" = 221000, "metric ton" = 46, "half ton" = 100), base_unit = c("pound" = 100000))
#  expect_equal(dt_ms, expected_ms)
#})

#strip_ft_in
test_that("Ft/In Label has been successfully removed", {
dt_eval <- data.table(length = c("12-ft", 12, "12'", "144\"", "12ft 4in", "12'4\"", "144 inch", "12' - 5'", "46x53"))
expected_eval <- data.table(length = c(12, 12, 12, 144, 148, 148, 144, 12, "46x53"))
dt_eval <- strip_ft_in(dt_eval,"length")
expect_equal(dt_eval, expected_eval)
})

#cleanse_numerics
test_that("Numeric specs have been accurately scaled", {
dt_num <- data.table(length = c(12, 144, 60, 720, 1728))
expected_num <- data.table(length = c(144, 144, 60, 720, 144))
dt_num <- cleanse_numerics(dt_num, "length", unit = c("foot" = 60), base_unit = c("inch" = 720))
expect_equal(dt_num, expected_num)
})
