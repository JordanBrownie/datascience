context("test-find_replacement.R")
library(shtrain)
library(RODBC)
library(testthat)
test_that("Prefixes (imp_, sup_, def_) are correctly handled by *_prefix.", {
  con <- create_server_connection()
  on.exit(odbcClose(con))
  cols <- sql_columns(con, 1026, raw = FALSE, all = FALSE)[['default']]
  sup <- sql_columns(con, 1026, raw = FALSE, all = FALSE)[['supplemental']]
  cols <- setdiff(cols, c('make_model', 'object_default_id', 'reference_id', 'reference_type_id'))
  sup <- setdiff(sup, c('make_model', 'object_default_id', 'reference_id', 'reference_type_id'))
  expect_true(identical(shtrain:::has_prefix(cols, "def_"), seq_along(cols)), label = "All def_ prefixes detected")
  expect_true(identical(shtrain:::has_prefix(sup, "sup_"), seq_along(sup)), label = "All sup_ prefixes detected")

  no_prefixes <- c(shtrain:::rm_prefix(sup, "sup_"), shtrain:::rm_prefix(cols, "def_"))
  expect_true(setequal(c(no_prefix(no_prefixes, "sup_"), no_prefix(no_prefixes, "def")), seq_along(no_prefixes)), "Prefixes removed properly")


})
