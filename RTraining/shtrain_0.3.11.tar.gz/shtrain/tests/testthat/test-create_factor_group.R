context("test-train-create_factor_group.R")

library(shtrain)
library(data.table)
test_that("makes 'other' group, or not.", {
  test_dt <- data.table("fctr" = c(rep(c("yes", "no", "maybe"), 20), 'indecesive', "what"), hi = 60)
  other_dt <- data.table(test_dt,

                         "fctr_group" = c(rep(c("definite", "definite", "indefinite"), 20),
                                          'other', "other"))
  no_other_dt <- data.table(test_dt,
                            "fctr_group" = c(rep(c("definite", "definite", "indefinite"), 20),
                                             NA, NA))
  has_other_group <- .create_factor_group(test_dt, "fctr", list(definite = c("yes", "no"),
                                                                indefinite = "maybe"), other = TRUE)
  no_other_group <- .create_factor_group(test_dt, "fctr", list(definite = c("yes", "no"),
                                                               indefinite = "maybe"), other = FALSE)
  expect_equal(has_other_group,
               other_dt)
  expect_equal(no_other_group,
               no_other_dt)
})

test_that("ignores `NA` in `fctr`.", {
  test_dt <- data.table("fctr" = c(rep(c("yes", "no", "maybe"), 20), NA, "other"), hi = 60)
  expect_dt <- data.table(test_dt,
                          "fctr_group" = c(rep(c("definite", "definite", "indefinite"), 20),
                                           NA, "other"))
  has_na_fctr <- .create_factor_group(test_dt, "fctr", list(definite = c("yes", "no"),
                                                            indefinite = "maybe"), other = TRUE)
  expect_equal(has_na_fctr, expect_dt)

})

