test_helper <- function() {
  cache_names(r = shtrain:::shdata$name_table$r, sql = shtrain:::shdata$name_table$sql)

}
test_helper()
