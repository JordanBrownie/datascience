context("test-check_insufficient_data.R")

library(shtrain)
library(dplyr)
library(data.table)
library(testthat)
cache_names(r = shtrain:::shdata$name_table$r, sql = shtrain:::shdata$name_table$sql)
cache_names(r = 'make_model', sql = "MakeModel")


test_that("Factor-derived factor values not in xlevels are logged.", {
info <- list(formula_vars = c('rops_type', "hours_group",  'mmg'),
             base_vars = c('rops_type',"make_model"),
             used_vars = c("hours", "rops_type", "mmg"),
             source_vars = c("hours", "make_model"),
             derived_vars = c("hours_group", "mmg"),
             xlevels = list(hours_group = c('a', 'b', 'c', 'd'),
                            mmg = c('make_21', 'make_41'),
                            rops_type = c('open', 'enclosed')),
             dependencies = list(hours_group = "hours",
                                 mmg = 'make_model')

             )
test_dt <- data.table(rops_type = c('open', 'enclosed', 'enc'),
                      make_model = c("make_1", 'make_2', 'make_4'),
                      mmg = c(NA, 'make_21', 'make_41'),
                      hours_group = c('a', 'b', 'f'),
                      hours = c(1, 10, 15), insufficient_data = "",
                      skip_checks = FALSE)
expected <- recipe(test_dt, info = info) %>% check_insufficient_data() %>% trained()
expect_known_value(expected, file = "rds/missing_levels_caught.rds", update = TRUE)
  })


test_that("Bad level errors are logged.", {
  info <- list(formula_vars = c('rops_type', "hours_group", 'mmg'),
               base_vars = c('rops_type',"make_model"),
               used_vars = c("hours", "rops_type", "mmg"),
               source_vars = c("hours", "make_model"),
               derived_vars = c("hours_group", "mmg"),
               xlevels = list(hours_group = c('a', 'b', 'c', 'd'),
                              mmg = c('make_21', 'make_41'),
                              rops_type = c('open', 'enclosed', "enc")),
               dependencies = list(hours_group = "hours",
                                   mmg = 'make_model')

  )
  bad_levels <- list(rops_type = "enclosed", mmg = "make_41")
  test_dt <- data.table(rops_type = c('open', 'enclosed', 'enc'),
                        make_model = c("make_1", 'make_2', 'make_4'),
                        mmg = c("make_21", 'make_21', 'make_41'),
                        hours_group = c('a', 'b', 'f'),
                        hours = c(1, 10, 15), insufficient_data = "",
                        required_fields = "",
                        invalid_data = "",
                        priority_order = c(1, 5, NA),
                        skip_checks = FALSE)
  expected <- recipe(test_dt, info = info) %>% check_insufficient_data(bad_levels = bad_levels) %>%
    trained()

  expect_known_value(expected, file = "rds/bad_levels_removed.rds", update = TRUE)
})

test_that("Numeric-sourced variables are ignored.", {
  info <- list(formula_vars = c('rops_type', "hours_group", 'mmg'),
               base_vars = c('rops_type',"make_model"),
               used_vars = c("hours", "rops_type", "mmg"),
               source_vars = c("hours", "make_model"),
               derived_vars = c("hours_group", "mmg"),
               xlevels = list(hours_group = c('a', 'b', 'c', 'd'),
                              mmg = c('make_21', 'make_41'),
                              rops_type = c('open', 'enclosed')),
               dependencies = list(hours_group = "hours",
                                   mmg = 'make_model')

  )
  test_dt <- data.table(rops_type = c('open', 'enclosed', 'enc'),
                        make_model = c("make_1", 'make_2', 'make_4'),
                        mmg = c("make_21", 'make_21', 'make_41'),
                        hours_group = c('a', 'b', 'f'),
                        hours = c(NA, 10, 15), insufficient_data = "",
                        required_fields = "",
                        invalid_data = "",
                        skip_checks = FALSE)
  expected <- recipe(test_dt, info = info) %>% check_insufficient_data() %>%
    trained()

  expect_known_value(expected, file = "rds/ignore_numeric_sourced.rds", update = FALSE)
})


test_that("Factor-derived numerics are detected.", {
  info  <- list(formula_vars = c('rops_type', "hours_group", 'mm_score'),
                base_vars = c('rops_type',"make_model"),
                used_vars = c("hours", "rops_type", "mm_score"),
                source_vars = c("hours", "make_model"),
                derived_vars = c("hours_group", "mm_score"),
                xlevels = list(hours_group = c('a', 'b', 'c', 'd'),
                               rops_type = c('open', 'enclosed')),
                dependencies = list(hours_group = "hours",
                                    mm_score = 'make_model'))
  test_dt <- data.table(rops_type = c('open', 'enclosed'),
                        make_model = c("good_mm", "bad_mm"),
                        mm_score = c(1700, NA),
                        hours = 1,
                        hours_group = "a",
                        evaluation = c(1, NA),
                        priority_order = c(1, NA),
                        skip_checks = FALSE
                        )
  expected <- recipe(test_dt, info = info) %>% check_insufficient_data() %>%
    trained()
  expect_known_value(expected, file = "rds/factor_derived_numerics.rds", update = FALSE)
})

test_that("bad_levels correctly formats expected inputs.", {
  info <- list(formula_vars = c('rops_type', "hours_group", 'mmg'),
               base_vars = c('rops_type',"make_model"),
               used_vars = c("hours", "rops_type", "mmg"),
               source_vars = c("hours", "make_model"),
               derived_vars = c("hours_group", "mmg"),
               xlevels = list(hours_group = c('a', 'b', 'c', 'd'),
                              mmg = c('make_21', 'make_41'),
                              rops_type = c('open', 'enclosed')),
               dependencies = list(hours_group = "hours",
                                   mmg = 'make_model')

  )
  test_dt <- data.table(rops_type = c('open', 'enclosed', 'enc'),
                        make_model = c("make_1", 'make_2', 'make_4'),
                        mmg = c("make_21", 'make_21', 'make_41'),
                        hours_group = c('a', 'b', 'f'),
                        hours = c(1, 10, 15), insufficient_data = "",
                        priority_order = c(1, 5, NA),
                        skip_checks = FALSE)
  inputs <- list(list(rops_type = "enclosed"), data.table(factor = "rops_type", level = "enclosed"))

  output1 <-
    recipe(test_dt, info = info) %>% check_insufficient_data(inputs[[1]]) %>% prep() %>% {
      .$steps[[1]]$bad_levels
    }
  output2 <-
    recipe(test_dt, info = info) %>% check_insufficient_data(inputs[[2]]) %>% prep() %>% {
      .$steps[[1]]$bad_levels
    }
  expect_equal(output1, output2)
  expected <- recipe(test_dt, info = info) %>% check_insufficient_data(bad_levels = inputs[[1]]) %>%
    prep() %>% bake()
  expect_known_value(expected, file = "rds/bad_levels_non_empty.rds", update = FALSE)
})


test_that("bad_levels handles expected empty inputs.", {
  info <- list(
    formula_vars = c('rops_type', "hours_group", 'mmg'),
    base_vars = c('rops_type', "make_model"),
    used_vars = c("hours", "rops_type", "mmg"),
    source_vars = c("hours", "make_model"),
    derived_vars = c("hours_group", "mmg"),
    xlevels = list(
      hours_group = c('a', 'b', 'c', 'd'),
      mmg = c('make_21', 'make_41'),
      rops_type = c('open', 'enclosed')
    ),
    dependencies = list(hours_group = "hours",
                        mmg = 'make_model')

  )
  test_dt <-
    data.table(
      rops_type = c('open', 'enclosed', 'enc'),
      make_model = c("make_1", 'make_2', 'make_4'),
      mmg = c("make_21", 'make_21', 'make_41'),
      hours_group = c('a', 'b', 'f'),
      hours = c(1, 10, 15),
      insufficient_data = "",
      priority_order = c(1, 5, NA),
      skip_checks = FALSE
    )
  inputs <-
    list(
      list(),
      NULL,
      data.table(NULL)
    )
  for (k in seq_along(inputs)) {
    s <- recipe(test_dt, info = info) %>% check_insufficient_data(inputs[[k]]) %>% prep() %>%
  {.$steps[[1]]$bad_levels}
  expect_equal(!!s, data.table(factor = character(0L), level = character(0L), label = character(0L)),
               info = inputs[[k]])
  }
  expected <-
    recipe(test_dt, info = info) %>% check_insufficient_data(bad_levels = inputs[[1]]) %>%
    trained()
  expect_known_value(expected, file = "rds/bad_levels_empty.rds", update = FALSE)

})

test_that("Errors computed correctly with `subset` argument", {
  info <- list(formula_vars = c('rops_type', "hours_group",  'mmg'),
               base_vars = c('rops_type',"make_model"),
               used_vars = c("hours", "rops_type", "mmg"),
               source_vars = c("hours", "make_model"),
               derived_vars = c("hours_group", "mmg"),
               xlevels = list(hours_group = c('a', 'b', 'c', 'd'),
                              mmg = c('make_21', 'make_41'),
                              rops_type = c('open', 'enclosed')),
               dependencies = list(hours_group = "hours",
                                   mmg = 'make_model')

  )
  test_dt <- data.table(rops_type = c('open', 'enclosed', 'enc'),
                        make_model = c("make_1", 'make_2', 'make_4'),
                        mmg = c(NA, NA, 'make_41'),
                        hours_group = c('a', 'b', 'f'),
                        hours = c(1, 10, 15), insufficient_data = "",
                        skip_checks = FALSE)
  expected <- recipe(test_dt, info = info) %>% check_insufficient_data(subset = make_model == "make_1") %>% trained()
  expect_known_value(expected, file = "rds/multiple_insufficient.rds")
})