context("test-step_validate.R")
library(shtrain)
library(dplyr)
library(data.table)
library(testthat)
cache_names(r = shtrain:::shdata$name_table$r, sql = shtrain:::shdata$name_table$sql)
cache_names(r = 'make_model', sql = "MakeModel")
test_that("Values exceeding bounds are removed for dealer-entered values.", {
  dt <- data.table(x = seq(from = -100, to = 100, length.out = 20),
                   y = seq(from = 700, to = 100000, length.out = 20))
  validated <- recipe(dt) %>% step_validate(validate = list(x = c(-50, 50), y = c(500, 48000)), spec_type = "dlr") %>% trained()
 testthat::expect_equal_to_reference(validated, file = "rds/step_validate_numeric.rds")
})


test_that("Values exceeding bounds are removed for every spec_type provided.", {
  dt <- data.table(x = seq(from = -100, to = 100, length.out = 20),
                   def_x = seq(from = -200, to = 200, length.out = 20))
  validated <- recipe(dt) %>%
    step_validate(validate = list(x = c(-50, 50), y = c(500, 48000)), spec_type = c("dlr", "def")) %>%
    trained()
  testthat::expect_equal_to_reference(validated, file = "rds/step_validate_multiple_types.rds")
})

test_that("Invalid values for character vectors are removed.", {
dt <- data.table(a = letters, b = LETTERS, c = 1:26, def_a = "z")
validated <- recipe(dt) %>% step_validate(list(a = letters[1:23], b = LETTERS[1:5]), spec_type = c("dlr", "def")) %>% trained()
testthat::expect_equal_to_reference(validated, file = "rds/step_validate_character.rds")
})


test_that("Providing both numeric & character specs works.", {
  dt <- data.table(a = letters, b = LETTERS, c = as.double(1:26))
  validated <- recipe(dt) %>% step_validate(list(a = letters[1:23], b = LETTERS[1:5], c = c(1, 25)), spec_type = "dlr") %>% trained()
  testthat::expect_equal_to_reference(validated, file = "rds/step_validate_both.rds")
})