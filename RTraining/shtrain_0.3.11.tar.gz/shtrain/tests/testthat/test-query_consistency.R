context("test-translate_names.R")
library(shtrain)
library(data.table)
library(testthat)
library(stringr)

expect_better_setequal <- function(object, expected, message = NULL) {
  act <- quasi_label(enquo(object))
  exp <- quasi_label(enquo(expected))
  act$val <- sort(unique(act$val))
  exp$val <- sort(unique(exp$val))
  comp <- compare(act$val, exp$val)
  expect(comp$equal, sprintf("%s \n %s not set-equal to %s .\n%s",
                             message, act$lab, exp$lab,  comp$message))
  invisible(act$val)
}

test_that("All view names get translated.", {
  ids <- c(14, 210, 1038, 1108)
  con <- create_server_connection()
  on.exit(RODBC::odbcClose(con))
  for (k in seq_along(ids)) {
  sql_names <- shtrain:::sql_columns(con, ids[k], raw = TRUE, all = TRUE)
  ind <- seq_along(sql_names)
  view <- names(sql_names)
  r_names <- lapply(ind, function(x) translate_names(names = sql_names[x], from = view[x], to = "r"))
  in_common <- lapply(ind, function(x) intersect(sql_names[x], r_names[x]))
  expect_identical(sum(lengths(in_common)), 0L, label = get_industry(category_id = ids[k]))
  }
})

# No longer need due to `reconcile_names`
# test_that("Supplemental and default names match base and dynamic.", {
#   con <- create_server_connection()
#   on.exit(RODBC::odbcClose(con))
#   ids <- sqlQuery(con, "SELECT ObjectCategoryID from CategoryForView where Status = 'Active';")$ObjectCategoryID
#
#   base_names <- shtrain:::shdata$name_table$r
#   for (k in seq_along(ids)) {
#     sql_names <- sql_columns(con, ids[k], raw = TRUE, all = TRUE)
#     if (length(sql_names) == 3) {
#       next
#     }
#     if ('dynamic' %in% names(sql_names)) {
#     dyn <- rm_prefix(sql_names[["dynamic"]], "DYN_")
#     fixed <- unique(c(base_names, to_snake_case(dyn)))
#     } else {
#       fixed <- base_names
#     }
#     names(fixed) <- str_replace_all(fixed, "_", "")
#     if ('supplemental' %in% names(sql_names)) {
#        sup <- rm_prefix(sql_names[["supplemental"]], "SUP_")
#        names(sup) <- tolower(sup)
#        sup_overlap <- intersect(names(sup), names(fixed))
#     sup_fixed <- fixed[sup_overlap]
#     sup <- to_snake_case(sup[sup_overlap])
#    res <-  expect_better_setequal(sup_fixed, sup, glue::glue("Category {ids[k]}:"))
#
#     }
#     if ('default' %in% names(sql_names)) {
#       def <- rm_prefix(sql_names[["default"]], "DEF_")
#       names(def) <- tolower(def)
#       def_overlap <- intersect(names(def), names(fixed))
#       def <- to_snake_case(def[def_overlap])
#       def_fixed <- fixed[def_overlap]
#      res <- expect_better_setequal(def_fixed, def, glue::glue("Category {ids[k]}:"))
#     }
#   }
#
# })

