context("test-add_imputations.R")

test_that("add_imputations does not break on NA.", {
  test_dt <- data.table(make_model = c(rep('cat1', 10),
                                       rep('cat5', 10),
                                       rep('cat10', 10)
  ),
  capacity = c(1:5, 5, NA, NA, 5, 5,
               rep(NA, 8), 8, 8,
               rep(5, 5), rep(10, 5)),
  drive = c(rep('4wd', 5),
            rep('2wd', 3),
            NA, NA, rep('4wd', 5), rep('2wd', 5),
            NA, '3wd', '2wd', rep('2wd', 7)),
  rops_type = c(rep(NA, 25), rep('enclosed', 5)),
  all_empty = NA_character_
  )
  imputed_dt <- recipe(test_dt) %>% add_imputations(c("drive","rops_type", 'capacity', 'all_empty'), by = "make_model") %>% prep() %>% bake()
 expect_equal_to_reference(imputed_dt,
                           file = "rds/add_imputations_data.rds")
})


