context("test-sql-to_sql_names.R")
library(RODBC)
library(shtrain)
library(snakecase)
test_that("all special cases except axle are accounted for", {
  con <- create_server_connection()
  on.exit(RODBC::odbcClose(con))
  tables <- sqlTables(con)$TABLE_NAME
  tables <- tables[grepl("^vw_.*", tables)]
  names <- vector(mode = "list", length = length(tables))
  for (i in seq_along(tables)) {
    names[[i]] <- tolower(sqlColumns(con, tables[i])$COLUMN_NAME)
  }
  sql_names <- unique(unlist(names, use.names = FALSE))
  r_names <- to_snake_case(sql_names)
  sql_names_2 <- tolower(shtrain:::to_sql_case(r_names))
  expect_equal(sql_names, sql_names_2)
})
