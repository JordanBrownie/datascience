context("test-sql-format_numerics.R")
library(data.table)
library(shtrain)
test_that("integer and doubles to doubles", {
  test <- data.table(int = 1L:20L, double = 1:20 + 0.1, char = "yes")
  converted_dt <- .format_numeric(test)
  types <- vapply(converted_dt, typeof, FUN.VALUE = "character", USE.NAMES = FALSE)
  expect_equal(types, c("double", "double", "character"))
  })
