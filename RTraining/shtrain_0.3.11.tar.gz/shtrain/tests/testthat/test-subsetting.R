context("test-subsetting.R")


library(shtrain)
library(dplyr)
library(data.table)
library(testthat)
cache_names(r = shtrain:::shdata$name_table$r, sql = shtrain:::shdata$name_table$sql)
cache_names(r = 'make_model', sql = "MakeModel")
test_that("Special data.table subsets work, even nested in different frames.", {
  dt <- data.table(data_type = c("auction", "auction", "aftersale", "aftersale", "asking"), id = 1:5,
                   web_end_date = Sys.Date() + 1:5)
  expect_equal(dt[auction()], dt[data_type == "auction"])
  expect_equal(dt[aftersale()], dt[data_type == "aftersale"])
  expect_equal(dt[asking()], dt[data_type == "asking"])
  expect_equal(dt[current_asking()], dt[data_type == "asking" & web_end_date > Sys.Date()])

  expect_equal(dt[(auction())], dt[data_type == "auction"])
  expect_equal(dt[(aftersale())], dt[data_type == "aftersale"])
  expect_equal(dt[((((asking()))))], dt[data_type == "asking"])
  expect_equal(dt[(!(!current_asking()))], dt[data_type == "asking" & web_end_date > Sys.Date()])
})


