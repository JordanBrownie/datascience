context("test-check_required_fields.R")


library(shtrain)
library(dplyr)
library(data.table)
library(testthat)
test_that("`include` are checked, `excluded`` are not.", {
  test_helper()
  info <- list(used_vars = 'hours')
dt <- data.table(hours = c(1:2, NA, 4, NA), x = c(NA, 2, 3, 4, NA), required_fields = "", skip_checks = FALSE)
expected <- recipe(dt, info = info) %>% check_required_fields(include = "x",
                                                              exclude = "hours") %>%
  prep() %>% bake()
expect_known_value(expected, file = "rds/include_exclude_required.rds", update = FALSE)
})

test_that("multiple messages can be recorded.", {
  test_helper()
  info <- list(used_vars = c('hours', 'x'))
  dt <- data.table(hours = c(1:2, NA, 4, NA), x = c(NA, 2, 3, 4, NA), required_fields = "", skip_checks = FALSE)
  expected <- recipe(dt, info = info) %>% check_required_fields() %>%
    prep() %>% bake()
  expect_known_value(expected, file = "rds/multiple_required.rds", update = FALSE)
})

test_that("only rows corresponding to subset receive error.",
          {
            set.seed(702)
            dt <- data.table(make_model = sample(c(letters[1:4], NA), size = 50, replace = TRUE),
                             class = sample(c("big", "small"), size = 50, replace = TRUE),
                             important_small_var = NA_character_,
                             skip_checks = FALSE, # Indicator fed to `check` functions to skip it.
                             required_fields = "") # All error fields are initialized as empty strings
            cache_names(r = c("class", "enormous_bucket"), sql = c("Class", "Enormous Bucket"))
            # Add a column, "enormous_bucket", which is small for `class == "small"` but is "yes", "no" or
            # `NA_character_` for `class == "big"`.
            dt[,enormous_bucket := dplyr::if_else(class == 'big',
                                                  true = sample(c("yes", "no", NA_character_),
                                                                size = 50,
                                                                replace = TRUE),
                                                  NA_character_)]
          expected <-  recipe(dt) %>% check_required_fields(subset = class == "big", check = "enormous_bucket") %>%
              check_required_fields(subset = class == "small", check = "important_small_var") %>%
              check_required_fields(subset = NULL, check = "make_model") %>%
              trained()
          expect_known_value(expected, file = "rds/required_fields_subset.rds", update = FALSE)
          })