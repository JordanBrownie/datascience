#' Order columns for viewing data
#'
#' `step_view` creates a *specification* of a recipe step that will
#'   reorder columns for more coherent viewing.
#' @inheritParams step_basic
#' @param subset Logical. If `TRUE`, only include columns which end
#'  up in the reordering process.
#' @param sup Show supplemental?
#' @param def Show default? This will only show default columns corresponding
#' to variables present in the formula.
#' @param imp Show imputed? This will only show imputed columns corresponding
#' to variables present in the formula.
#' @param before columns to be included at beginning
#' @param after columns to be included at end
#' @param ref_order Generated automatically.
#' @inherit step_basic return
#' @export
#' @details
#'  * Step:  Gets `source_vars`, `base_vars` and `derived_vars` from `recipe$info`
#'  * Prep: Goes in the order `before`, `metadata`, `source_vars`, `base_vars`,
#'   `derived_vars`, `sup/def/imp`, `evaluation data`, `after`.
#'  * Bake:  Reorders the data.
step_view <- function(recipe,
                      subset = TRUE,
                      sup = TRUE,
                      def = TRUE,
                      imp = TRUE,
                      before = NULL,
                      after = NULL,
                      ref_order = NULL,
                      trained = FALSE) {

  add_step(
    recipe,
    step_view_new(
      subset = subset,
      sup = sup,
      def = def,
      imp = imp,
      before = before,
      after = after,
      ref_order = recipe$info[c("source_vars", "base_vars", "derived_vars")],
      trained = trained
    )
  )
}

step_view_new <- function(subset = TRUE,
                          sup = TRUE,
                          def = TRUE,
                          imp = TRUE,
                          before = NULL,
                          after = NULL,
                          ref_order = NULL,
                          trained = FALSE) {

  step(
    subclass = "view",
    subset = subset,
    sup = sup,
    def = def,
    imp = imp,
    before = before,
    after = after,
    ref_order = ref_order,
    trained = trained
  )
}

#' @importFrom data.table chmatch
#' @importFrom stringr str_replace
prep.step_view <- function(x, training, ...) {
#Compute any parameters from training needed in scoring.
  info_vars <- c(unlist(x$ref_order, use.names = FALSE))
nms <- change_names(names = names(training), from = "sql")
display_vars_mid <- info_vars
matcher <- paste(c("sup_", "def_", "imp_")[c(x$sup, x$def, x$imp)], collapse = "|")
extras <- names(training)[grepl(matcher, nms)]
no_prefix <- str_replace(extras, "^(sup_|def_|imp)", "extras")
base_in_vars <- chmatch(no_prefix, display_vars_mid, nomatch = 0)
included_extras <- extras[base_in_vars]
display_vars_start <- c("ref_id", "ds_lookup_id", "manufacturer", "make_model",
                        "sale_week", "sale_date")
display_vars_end <- c("usd_list_price", "usd_sale_price", "evaluation", "priority_order",
                      "abs_error", "rel_error", "r_message")
ref_order <- unique(c(x$before, display_vars_start, display_vars_mid, included_extras, display_vars_end, x$after))
step_view_new(
  sup = x$sup,  def = x$def, imp = x$imp,
  before = x$before, after = x$after, ref_order = ref_order,
  trained = TRUE
)
}
bake.step_view <- function(object, newdata, ...) {
# Do anything which needs to be done to both training/testing
setnames(newdata, old = change_names(names = names(newdata), from = "sql"))
ref <- intersect(object$ref_order, names(newdata))
setcolorder(newdata, neworder = unique(c(ref, names(newdata))))
if (object$subset == TRUE) {
  newdata[,(setdiff(names(newdata),object$ref_order)) := NULL]
}
newdata
}
