
#' Apply a function during bake
#'
#'   __Deprecated__ Do not use this function. Use [step_dt()] instead.
#' This function will be removed in future versions.
#' @inheritParams step_basic
#' @param fun string giving the function name. Must exist within one of the packages loaded for scoring
#' @param options Named list of arguments for the function, excluding data.
#' @inherit step_basic return
#' @export
#' @details
#'  Step: Nothing
#'  Prep: Nothing
#'  Bake: Calls function
step_transform <- function(recipe, fun = NA, options = NULL, trained = FALSE) {
  add_step(recipe,
           step_transform_new(
             fun = fun,
             options = options,
             trained = trained
           )
  )
}

step_transform_new <- function(fun, options, trained = FALSE) {
  step(subclass = "transform",
       fun = fun,
       options = options,
       trained = trained
  )
}

#' @importFrom pryr make_function
#' @export
prep.step_transform <- function(x, training, ...) {
  step_transform_new(
    fun = x$fun,
    options = x$options,
    trained = TRUE
  )
}
#' @export
bake.step_transform <- function(object, newdata, ...) {
  options <- c(list(data = newdata), object$options)
  newdata <- do.call(object$fun, options)
  invisible(newdata)
}