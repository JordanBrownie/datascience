#' Add evaluations to listings
#'
#' `add_evaluations()` scores a list of [stats::predict()]-compatible models. For
#' each row, it keeps the first non-`NA` prediction.
#'
#' @inheritParams step_basic
#' @param type 'auction' or 'retail' for 2-recipe export models. For 1-recipe
#' export models, the name of the prediction column.
#' @param models A list of `glm` objects. Other model classes are untested, but may work with
#' if the [stats::predict()] method has a `newdata` argument.
#' @param priorities A vector of priority orders, the same length as the number of models.
#' @export
#' @details
#' * Step: Nothing
#' * Prep: Nothing
#' * Bake: Adds 'evaluation' and 'priority_order' columns.
add_evaluations <-
  function(recipe,
           type,
           models,
           priorities,
           trained = FALSE) {
    add_step(
      recipe,
      add_evaluations_new(
        type = type,
        models = models,
        priorities = priorities,
        trained = trained
      )
    )
  }

add_evaluations_new <-
  function(type,
           models,
           priorities,
           trained = FALSE) {
    add(
      subclass = "evaluations",
      type = type,
      models = models,
      priorities = priorities,
      trained = trained
    )
  }



prep.add_evaluations <- function(x, training, ...) {
  add_evaluations_new(
    type = x$type,
    models = x$models,
    priorities = x$priorities,
    trained = TRUE
  )
}

bake.add_evaluations <- function(object, newdata, ...) {
 if (object$type %chin% c("auction", "retail")) {
   eval_ind <- newdata[eval_type == object$type, which = TRUE]
   eval_data <- newdata[eval_ind]
   eval_name <- "evaluation"
 } else {
   eval_ind <- seq.int(length.out = nrow(newdata))
   eval_data <- newdata
   eval_name <- object$type
 }
 if (!(eval_name %chin% names(newdata))) {
   set(x = newdata,
       i = NULL,
       j = eval_name,
       value = NA_real_)
 } else{
   eval_ind <- intersect(which(is.na(newdata[[eval_name]])), eval_ind)
 }
 missing <- eval_ind
 if (all(class(object$models) == "list")) {
   data_list <- lapply(object$models, function(x) batch_to_na(data = eval_data, object = x))
   for (k in seq_along(object$models)) {
   set(x = newdata,
       i = missing,
       j = eval_name,
       value = predict(object = object$models[[k]],
                       newdata = data_list[[k]][missing]))
   set(x = newdata,
       i = missing,
       j = "priority_order",
       value = object$priorities[k])
   missing <- intersect(which(is.na(newdata[[eval_name]])), eval_ind)
   if (length(missing) == 0) {
     break
   }
 }
 } else {
   data_list <- batch_to_na(data = eval_data, object = object$models)
   set(x = newdata,
       i = missing,
       j = eval_name,
       value = predict(object = object$models,
                       newdata = data_list[missing]))
   set(x = newdata,
       i = missing,
       j = "priority_order",
       value = object$priorities)
   missing <- intersect(which(is.na(newdata[[eval_name]])), eval_ind)
 }

 set(x = newdata,
     i = which(is.na(newdata[[eval_name]])),
     j = "priority_order",
     value = NA_real_)
 newdata
 }



summary.add_evaluations <- function(x, ...) {
data.table(evaluation_type = x$type,
           n_models = length(x$models),
           n_best = sum(which(x$priorities <= 25)),
           n_top_tier = sum(which(x$priorities > 25 & x$priorities < 200)),
           n_other = sum(which(x$priorities > 199)))
}