# #' Scales and/or reformats mass specs to be numeric and in the correct base unit.
# #'
# #' `step_mass` is a *specification* of a recipe step
# #' which will reformat if necessary and scale to the correct base unit any mass specs that should be numeric.
# #' @inheritParams step_basic
# #' @inheritParams cleanse_numerics
# #' @details
# #'
# #' Uses different regex calls to parse out the relevant numerics and remove any labeling or bad entry.  The regex can handle labels
# #' like lbs, kgs, tons, or metric tons.  The regex will remove ranges and over approximations and it will clear out bad
# #' entry such as words or symbols.  The function will handle decimals and commas.  Any values that are already in the correct numeric
# #' format will be scaled to the correct base unit using the `cleanse_numerics` function.
# #'
# #' For correctly formatted values, any value strictly lower than the bound for the unit value(s) supplied will be scaled to the base
# #' unit. Any value strictly higher than the bound for the base unit value supplied will be scaled down, as the entered value was most
# #' likely scaled correctly initially but given the wrong unit label and scaled again. For values that must be formatted, regex is used
# #' to subset the data to remove bad entry and to the corresponding unit labels.  Certain units will be scaled using the measurement
# #' table to be in the correct base unit. Assumed that correctly formatted values are in the correct unit system and need minor scaling.
# #'
# #' * Step: Captures relevant information in order to reformat and/or scale the column appropriately.
# #' * Prep: Queries and stores the measurement table
# #' * Bake: Reformats if necessary and scales column to the base unit that is stored in database for the spec.
# #' @export
# #' @import stringr
# #' @importFrom data.table copy set
# #' @importFrom RODBC odbcClose sqlQuery
# #' @importFrom data.table is.data.table
# #' @importFrom rlang is_named
# #' @include helper_numerics.R
# # step_mass <- function(recipe, col, unit = c(ton = NA, kg = NA, mt = NA, ht = NA), base_unit = c(label = NA), trained = FALSE, measurements = # NULL){
# #   add_step(recipe, step_mass_new(
# #     col = col,
# #     trained = trained
# #   ))
# # }
# #
# # step_mass_new <- function(col, unit = c(ton = NA, kg = NA, mt = NA, ht = NA), base_unit = c(label = NA), trained = FALSE, measurements = # NULL){
# #   step(subclass = 'mass',
# #        col = col,
# #        trained = trained
# #   )
# # }
# #
# # prep.step_mass <- function(x, training, ...){
# #   ntnu <- tolower(names(x$unit[1]))
# #   nkgu <- tolower(names(x$unit[2]))
# #   nmtu <- tolower(names(x$unit[3]))
# #   nhtu <- tolower(names(x$unit[4]))
# #   nbu <- tolower(names(x$base_unit))
# #   dbhandle <- shtrain:::create_server_connection()
# #   on.exit(odbcClose(dbhandle))
# #   stopifnot(is.data.table(training), is_named(x$unit), is_named(x$base_unit))
# #   measurements <- sqlQuery(dbhandle,"SELECT Unit AS unit, BaseUnit AS base_unit, MultiplyBy AS multiply_by, UnitGroup AS unit_group
# #                            FROM dbMMM.dbo.MeasurementUnit MU(NOLOCK)
# #                            WHERE UnitGroup = 'MASS';",
# #                            stringsAsFactors = FALSE)
# #   measurements <- tolower(measurements)
# #   measurements <- rbind(measurements, data.table(unit = "half ton", base_unit = "pound", multiply_by = 1000.0000000000, unit_group = "mass"# ))
# #   measurements_tn <- measurements[measurements$base_unit == nbu & measurements$unit == ntnu,]
# #   measurements_kg <- measurements[measurements$base_unit == nbu & measurements$unit == nkgu,]
# #   measurements_mt <- measurements[measurements$base_unit == nbu & measurements$unit == nmtu,]
# #   measurements_ht <- measurements[measurements$base_unit == nbu & measurements$unit == nhtu,]
# #   step_mass_new(col = x$col,
# #                       unit = x$unit,
# #                       base_unit = x$base_unit,
# #                       trained = TRUE,
# #                       measurements = measurements)
# # }
# #
# # bake.step_mass <- function(object, newdata, ...){
# #   newdata <- copy(newdata)
# #   trim <- str_which(newdata[[col]], "gvwr?|ap{1,2}r?o?x?|about")
# #   set(x = newdata,
# #       i = trim,
# #       j = object$col,
# #       value = str_replace(data[[col]][trim], "gvwr?|ap{1,2}r?o?x?\\.?\\,?", ""))
# #   if (!can_be_numeric(newdata[[object$col]]) ) {
# #     bad <- str_which(newdata[[col]], "[a-z]{5,}|[\\-\\+\\<\\>\\/]|\\d+(to)\\d+|plus|over")
# #     set(x = newdata,
# #         i = bad,
# #         j = object$col,
# #         value = NA_real_)
# #     lbs <-str_which(newdata[[col]], "\\d+(lbs?|#)")
# #     set(x = newdata,
# #         i = lbs,
# #         j = object$col,
# #         value = str_replace(str_extract(data[[col]][lbs], "\\d{1,3}[\\.\\,]?\\d{0,3}"),"[\\,\\.]", ""))
# #     kgs <- str_which(newdata[[col]], "\\d+kgs?")
# #     set(x = newdata,
# #         i = kgs,
# #         j = object$col,
# #         value =  str_replace(str_extract(data[[col]][kgs], "\\d{1,3}[\\.\\,]?\\d{0,3}"),"[\\,\\.]", "")*object$measurements_kg[, "multiply_b# y"])
# #     tons <- str_which(newdata[[col]], "\\d+tons?")
# #     set(x = newdata,
# #         i = tons,
# #         j = object$col,
# #         value =  str_replace(str_extract(data[[col]][tons], "\\d{1,3}[\\.\\,]\\d{0,3}"),"\\,", "\\.")*object$measurements_tn[, "multiply_by"# ])
# #     mt <- str_which(newdata[[col]], "\\d+(mt|met|to?)|^t\\s\\d+")
# #     set(x = newdata,
# #         i = mt,
# #         j = object$col,
# #         value =  str_replace(str_extract(data[[col]][mt], "\\d{1,3}[\\.\\,]\\d{0,3}"),"\\,", "\\.")*object$measurements_mt[, "multiply_by"])
# #     ht <- str_which(newdata[[col]], "\\d+k")
# #     set(x = newdata,
# #        i = ht,
# #        j = object$col,
# #        value = str_extract(data[[col]][ht], "\\d{1,3}")*object$measurements_ht[, "multiply_by"])
# #     num <- str_which(newdata[[col]], "\\d+\\w+")
# #     set(x = newdata,
# #         i = num,
# #         j = object$col,
# #         value = str_replace(str_extract(data[[col]][num], "\\d{1,3}[\\.\\,]?\\d{0,3}"),"[\\,\\.]", ""))
# #     words <- str_which(newdata[[col]], "[a-z]+")
# #     set(x = newdata,
# #         i = words,
# #         j = object$col,
# #         value = NA_real_)
# #   }
# #   cleanse_numerics(data = newdata, spec = object$col, unit = object$unit[nhtu], base_unit = object$base_unit, measurements = object$measurem# ents)
# # }
#