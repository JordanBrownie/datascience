#' Impute values by ratio
#'
#' Given data, a vector of columns, and something to group by,
#' impute values which meet the ratio and count criteria provided.
#' @param data Data with all columns in `col` and `by`.
#' @param col A vector of column names.
#' @param by A vector of column names to group by.
#' @param min_ratio The minimum ratio necessary for a default value to be selected.
#' Does not include missing values in the ratio computation. Can be length-1, or the
#' same length as `col`. Matches `col` by position.
#' @param min_count The minimum number of listings which must have the imputed value.
#' Can be length-1, or the same length as `col`. Matches `col` by position.
#' @param verbose Print diagnostic messages?
#' @return A `data.table` with columns `key`, `value`, `count`, `total`, and `prop`;
#' along with columns in the `by` vector. See details for transforming into the usual
#' form. The return value is keyed by `c(by, "key")`.
#' @details
#' `impute_ratio()` supplies the result in a form which is not ready for merging. This
#' is to better provide information about the imputed values. To put in the usual form,
#' use `summary()` on the result. This will drop the `count`, `total`,
#' and `prop` columns, creating new columns corresponding to the unique values in `key`.
#' If there are multiple imputed values for each group and spec, it will choose the one
#' with the highest proportion.
#' @export
#' @seealso summary.impute_ratio
impute_ratio <- function(data, col, by, min_ratio, min_count, verbose = TRUE) {
  data <- copy(data)
  if (length(min_ratio) == 1) {
    min_ratio <- rep(min_ratio, times = length(col))
  } else if (length(min_ratio) != length(col)) {
    stop("`min_ratio` must be either a length-1 vector, or length-`length(col)`.",
         call. = FALSE)
  }
  if (length(min_count) == 1) {
    min_count <- rep(min_count, times = length(col))
  } else if (length(min_count) != length(col)) {
    stop("`min_count` must be either a length-1 vector, or length-`length(col)`.",
         call. = FALSE)
  }
  tables <- vector(mode = 'list', length = length(col))
  if ("k" %in% names(data)) {
    stop("Don't name your a column \"k\". This is used to loop internally.", call. = FALSE)
  }
  for (k in seq_along(col)) {

    not_missing <- !is.na(data[[col[k]]])
    tables[[k]] <- data[not_missing,list(count = .N,
                                         value = get(col[k])),
                        by = c(by, col[k])][,list(total = sum(count),
                                                  count = count,
                                                  value = value), by = c(by)][
                                                    , prop := count/total,
                                                    by = c(by)][total > min_count[k]][prop > min_ratio[k]]
    tables[[k]][,key := eval(paste0("imp_", col[k]))]
    setcolorder(tables[[k]], c(by, 'key', 'value', 'count', 'total', 'prop'))

  }
  imputed <- rbindlist(tables, use.names = TRUE, fill = TRUE)
  if (anyDuplicated(imputed, by = by) ) {
      if (interactive() && verbose) {
      warning("Duplicated `by` value present in result of `impute_ratio()`.",
              "The first value for each imputed ",
              "will be chosen in `summary()`, which corresponds to a mode.", call. = FALSE)
      }
    }
  attr(imputed, "by") <- by
  attr(imputed, "min_ratio") <- min_ratio
  attr(imputed, "min_count") <- min_count
  attr(imputed, "col") <- col
  class(imputed) <- c("impute_ratio", "impute", class(imputed))
  setkeyv(imputed, c(by, "key"))
}

#' Wide-form imputations for merging
#'
#' Takes the output from [impute_ratio()] and assigns the imputed variables the
#' correct [typeof()]: `logical`, `numeric`, or `character`. If there are multiple
#' rows per group, it will chose the one with the highest proportion of values.
#' @param data Output of [impute_ratio()].
#' @importFrom data.table dcast
#' @export
#' @rdname impute_ratio
#' @include utils.R
summary.impute_ratio <- function(data) {

  formula <- paste(paste(attr(data, "by"), collapse = "+"), "~key")
  dt <- dcast(setorderv(copy(data), "prop", order = -1L), formula = formula, value.var = "value", fun.aggregate = function(x) x[1] %||% NA_character_)
  cols <- names(dt)[vapply(dt, is.character, FUN.VALUE = logical(1L), USE.NAMES = FALSE)]
  for (k in seq_along(cols)) {
    set(x = dt,
        i = NULL,
        j = cols[k],
        value = type.convert(dt[[cols[k]]], as.is = TRUE, numerals = "warn.loss"))
  }
  .format_numeric(dt)
}


#' Impute numeric values by ratio
#'
#' Given data, a vector of columns, something to group by, and an acceptable percent or
#' absolute variance, impute values which meet the ratio and count criteria provided.
#' @param data Data with all columns in `col` and `by`.
#' @param col A vector of column names.
#' @param by A vector of column names to group by.
#' @param variance A vector of allowable percentage or absolute variances. Can be
#' length-1, or the same length as `col`. Matches `col` by position.
#' @param min_ratio The minimum ratio necessary for a default value to be selected.
#' Does not include missing values in the ratio computation. Can be length-1, or the
#' same length as `col`. Matches `col` by position.
#' @param min_count The minimum number of listings which must have the imputed value.
#' Can be length-1, or the same length as `col`. Matches `col` by position.
#' @param variance_type A character vector defining whether a percent or absolute variance
#' should be used. "percent" or "absolute" are the only valid elements for this vector.
#' Can be length-1, or the same length as `col`. Matches `col` by position.
#' @param verbose Print diagnostic messages?
#' @return A `data.table` with columns `key`, `value`, `count_exact`, `count_window`,
#' `total`, `prop_exact`, and `prop_window`; along with columns in the `by` vector.
#' See details for transforming into the usual form.
#' @details
#' `impute_numeric()` supplies the result in a form which is not ready for merging. This
#' is to better provide information about the imputed values. To put in the usual form,
#' use `summary()` on the result. This will drop the `count_exact`, `count_window`, `total`,
#' `prop_exact`, and `prop_window` columns, creating new columns corresponding to the unique
#' values in `key`.
#' @export
#' @seealso summary.impute_numeric
impute_numeric <- function(data, col, by, variance, min_ratio, min_count, variance_type = "percent", verbose = TRUE) {

  newdata <- na.omit(data, cols = by)

  if (!all(col %in% names(newdata))) {
    stop("Not all columns supplied in `col` are found within the data.")
  }

  if (!all(by %in% names(newdata))) {
    stop("Not all columns supplied in `by` are found within the data.")
  }

  if (length(variance) == 1) {
    variance <- rep(variance, times = length(col))
  } else if (length(variance) != length(col)) {
    stop("`variance` must be a vector of either length-1 or length-`length(col)`.",
         call. = FALSE)
  }

  if (length(min_ratio) == 1) {
    min_ratio <- rep(min_ratio, times = length(col))
  } else if (length(min_ratio) != length(col)) {
    stop("`min_ratio` must be a vector of either length-1 or length-`length(col)`.",
         call. = FALSE)
  }

  if (length(min_count) == 1) {
    min_count <- rep(min_count, times = length(col))
  } else if (length(min_count) != length(col)) {
    stop("`min_count` must be a vector of either length-1 or length-`length(col)`.",
         call. = FALSE)
  }

  if (!all(variance_type %in% c("percent", "absolute"))) {
    stop("`variance_type` can only contain elements 'percent' or 'absolute'.")
  }
  if (length(variance_type) == 1) {
    variance_type <- rep(variance_type, times = length(col))
  } else if (length(variance_type) != length(col)) {
    stop("`variance_type` must be a vector of either length-1 or length-`length(col)`.",
         call. = FALSE)
  }

  tables <- vector(mode = 'list', length = length(col))

  if ("i" %in% names(newdata)) {
    stop("Do not name a column \"i\". This is used to loop internally.", call. = FALSE)
  }
  if ("k" %in% names(newdata)) {
    stop("Do not name a column \"k\". This is used to loop internally.", call. = FALSE)
  }

  for (i in seq_along(col)) {

    table <- na.omit(newdata, cols = col[i])
    table <- table[,list(count_exact = .N, value = get(col[i])), by = c(by, col[i])]

    if (variance_type[i] == "percent") {
      table[,`:=`(lower_lim = value * (1 - variance[i]),
                  upper_lim = value * (1 + variance[i]))]
    }
    if (variance_type[i] == "absolute") {
      table[,`:=`(lower_lim = (value - variance[i]),
                  upper_lim = (value + variance[i]))]
    }

    table[,count_window := .SD[.SD, on = c(by, "value>=lower_lim", "value<=upper_lim"), sum(x.count_exact), by = .EACHI]$V1]

    tables[[i]] <- table[,list(total = sum(count_exact), count_exact = count_exact, count_window = count_window, value = value, lower = lower_lim, upper = upper_lim), by = c(by)
                         ][,`:=`(prop_exact = count_exact/total, prop_window = count_window/total)
                           ][,key := str_c("imp_", col[i])
                             ][,c("upper", "lower") := NULL]

    tables[[i]] <- tables[[i]][total > min_count[i]][prop_window > min_ratio[i]]
    setcolorder(tables[[i]], c(by, "key", "value", "count_exact", "count_window", "total", "prop_exact", "prop_window"))

    # not_missing <- !is.na(newdata[[col[i]]])
    # table <- newdata[not_missing, list(count_exact = .N, count_window = NA_real_, value = get(col[i])), by = c(by, col[i])]
    # table <- na.omit(newdata, cols = col[i])
    # table <- table[,list(count_exact = .N, count_window = NA_real_, value = get(col[i])), by = c(by, col[i])]
    #
    # for (j in 1:nrow(table)) {
    #   temp_value = table[j, value]
    #   temp_range = c(temp_value*(1-variance[i]), temp_value*(1+variance[i]))
    #   temp_table <- copy(table)
    #   for (k in seq_along(by)) {
    #     temp_table <- temp_table[get(by[k]) == table[j, get(by[k])] & value %between% temp_range]
    #   }
    #   table[j, count_window := sum(temp_table$count_exact)]
    # }
    #
    # tables[[i]] <- table[,list(total = sum(count_exact), count_exact = count_exact, count_window = count_window, value = value), by = c(by)
    #                      ][,`:=`(prop_exact = count_exact/total, prop_window = count_window/total)
    #                        ][,key := str_c("imp_", col[i])]
    #
    # tables[[i]] <- tables[[i]][total > min_count[i]][prop_window > min_ratio[i]]
    # setcolorder(tables[[i]], c(by, "key", "value", "count_exact", "count_window", "total", "prop_exact", "prop_window"))

  }

  imputed <- rbindlist(tables, use.names = TRUE, fill = TRUE)
  setorderv(imputed, c("prop_exact"), order = -1L)

  attr(imputed, "col") <- col
  attr(imputed, "by") <- by
  attr(imputed, "variance") <- variance
  attr(imputed, "min_ratio") <- min_ratio
  attr(imputed, "min_count") <- min_count
  attr(imputed, "variance_type") <- variance_type
  class(imputed) <- c("impute_numeric", class(imputed))

  imputed

}


#' Wide-form imputations for merging
#'
#' Takes the output from [impute_numeric()] and assigns the imputed variables the
#' correct [typeof()]: `logical`, `numeric`, or `character`. If there are multiple
#' rows per group, it will chose the one with the highest proportion of values.
#'
#' @param data Output of [impute_numeric()].
#' @importFrom data.table dcast
#' @export
#' @rdname impute_numeric
#' @include utils.R
summary.impute_numeric <- function(data) {

  formula <- paste(paste(attr(data, "by"), collapse = "+"), "~key")
  dt <- dcast(data, formula = formula, value.var = "value", fun.aggregate = function(x) x[1] %||% NA_character_)
  cols <- names(dt)[vapply(dt, is.character, FUN.VALUE = logical(1L), USE.NAMES = FALSE)]

  for (k in seq_along(cols)) {
    set(x = dt,
        i = NULL,
        j = cols[k],
        value = type.convert(dt[[cols[k]]], as.is = TRUE, numerals = "warn.loss"))
  }

  .format_numeric(dt)

}
