# Suppress global variable notes R CMD CHECK -----------------------------------

# Initialize data for use internally -------------------------------------------
# shref$name_cache <- data.frame(r = character(), sql = character(), stringsAsFactors = FALSE)
shdata$current_name_scheme <- "r"
shdata$available_filters <- gsub("bake\\.*","", ls(pattern = "^(bake\\.filter_)", envir = asNamespace("shtrain")))
shdata$used_filters <- NULL
shdata$check_filters_counter <- 0
shdata$db_lookup <- data.table(base_category_id = c(4, 13, 27, 28, 464),
                               industry = c("mat", "cnt", "trk", "trl", "tho"),
                               db_name = c("dbMachinery", "dbController", "dbTruck", "dbTruck", "dbTractorHouse"),
                               stringsAsFactors = FALSE)

evalqOnLoad({
 ### Ugly hack to circumvent failure on R CMD BUILD/CHECK ---------------------
  # command_arguments <- function(env = NULL) {
  #   command_arguments <- commandArgs(trailingOnly = TRUE)
  #   if (is.null(env)) {
  #     env <- getOption("shconfig2.env")
  #   }
  #   if (length(command_arguments) == 6) {
  #     names(command_arguments) <- c("db_connection", "base_dir", "api_link", "env", "base_lib", "import_type")
  #     command_arguments <- c(as.list(command_arguments), list(sql_driver = '{ODBC Driver 11 for SQL Server}'))
  #   } else {
  #     command_arguments <- vector(mode = "list", length = 7L)
  #     names(command_arguments) <-  c("db_connection", "base_dir", "api_link", "env", "base_lib", "import_type", "sql_driver")
  #     command_arguments$db_connection <- 'server=AGLIWEBDW.SANDHILLS.INT; uid=RDevelopmentUser; pwd=kn2G0|6Fh86LH^kevOQf; MultiSubnetFailover=Yes;'
  #     command_arguments$sql_driver <- '{ODBC Driver 11 for SQL Server}'
  #     if (is.null(env) || env == "dev" ||  env == "local") {
  #       command_arguments$env <- ifelse(is.null(env), "local", ifelse(env == "dev", "dev", "local"))
  #       command_arguments$api_link <- 'http://devApiDS.dsdev.ext/EquipmentEvaluation/B45DE5615B1AE7B6172D85BF2C3B91CD/api/equipmentevaluationmodelimport'
  #       command_arguments$base_dir <- "\\\\dsdev.ext/file/DataScience"
  #       if (!is.null(env) && env == "dev") {
  #         command_arguments$base_lib <- "\\\\dsdev.ext/file/DataScience/SharedPackages"
  #       } else {
  #         command_arguments$base_lib <- "\\\\sandhills.int/file/data/dta/r/rlibraries"
  #       }
  #     } else if (env == "staging") {
  #       command_arguments$env <- "staging"
  #       command_arguments$api_link <-  "http://stgApiDS.dsstag.ext/EquipmentEvaluation/B45DE5615B1AE7B6172D85BF2C3B91CD/api/equipmentevaluationmodelimport"
  #       command_arguments$base_dir <- "\\\\dsstag.ext/file/DataScience"
  #       command_arguments$base_lib <- "\\\\dsstag.ext/file/DataScience/SharedPackages"
  #     } else if (env == "lab") {
  #       command_arguments$env <- "lab"
  #       command_arguments$db_connection <- 'server=SISQLDWSTG1\\DTA; uid=RDevelopmentUser; pwd=kn2G0|6Fh86LH^kevOQf; MultiSubnetFailover=Yes;'
  #       command_arguments$api_link <-  "http://stgApiDS.dsstag.ext/EquipmentEvaluation/B45DE5615B1AE7B6172D85BF2C3B91CD/api/equipmentevaluationmodelimport"
  #       command_arguments$base_dir <- "\\\\dsstag.ext/file/DataScience/Lab"
  #       command_arguments$base_lib <- "\\\\dsstag.ext/file/DataScience/Lab/SharedPackages"
  #     } else {stop("Either pass NULL, 'local', 'dev', 'staging', or 'lab' for `env`.")}
  #   }
  #   command_arguments
  # }
 # connection_string <- sprintf('driver=%s; %s database=dbDataScientist; ',
 #                              command_arguments()[["sql_driver"]],
 #                              command_arguments()[["db_connection"]])
 ### Ugly hack to circumvent failure on R CMD BUILD/CHECK ---------------------
 # if (!grepl("http://", command_arguments()[["api_link"]])) {
 # #   connection_string <-  "driver={ODBC Driver 11 for SQL Server}; server=AGLIWEBDW.SANDHILLS.INT; uid=RDevelopmentUser; pwd=kn2G0|6Fh86LH^kevOQf; MultiSubnetFailover=Yes; database=dbDataScientist; "
 # # }
 # con <- RODBC::odbcDriverConnect(connection = connection_string)
con <- create_server_connection()
  # con <- -1
if (con != -1) {
 on.exit(suppressWarnings(RODBC::odbcClose(con)))
 category_table <- RODBC::sqlQuery(con,
                                  "SELECT BaseCategoryID as base_category_id, ObjectCategoryID as category_id ,
                                  Category as category, Parentid as parent_id
                                  FROM dbMMM.dbo.ObjectCategories (NOLOCK)
                                  WHERE BaseCategoryID in (4, 13, 27, 28, 464);",
                                  stringsAsFactors = FALSE)
 category_table$industry <- ifelse(category_table$base_category_id == 4, "mat",
                                 ifelse(category_table$base_category_id == 27, "trk",
                                        ifelse(category_table$base_category_id == 28, "trl",
                                               ifelse(category_table$base_category_id == 464, "tho",
                                                      ifelse(category_table$base_category_id == 13, "cnt",
                                                      "unknown")))))
 shdata$static_categories <- NULL
} else {
warning("SQL connection for the category reference table could not be established on load.",
     " Loading static table.", call. = FALSE)
category_table <- shdata$static_categories
shdata$static_categories <- NULL
}
 shdata$category_reference <- category_table
})

