#' @title Internal package environment
#'
#' @description This is the environment used to store internal package information.
#'   Some of this is static, and some is created upon load (dynamic).
#'   See details for an explanation of each object.
#'
#' @name shdata
#'
#' @details
#' \itemize{
#'   \item{auction_exlusion_table} {Dynamic. Table from SQL containing information to
#'     exclude bad auction listings. Add a new one in SSMS using Pr_AddListingExclusion}
#'   \item{category_reference} {Dynamic. Table From SQL containing information on the
#'     relationship between category, category ID, base category ID, and industry.
#'     Used for industry and base category ID lookup.}
#'   \item{name_table} {Static. Table linking R names to their corresponding
#'   auction, aftersale, and asking view names.}
#'   \item{name_cache} {Dynamic. Generated within package function calls as appropriate.
#'     This can be written to directly using \code{cache_names}.}
#'   \item{special_selections}{Static. A list, where each name expands to the character
#'     vector that list element contains.}
#'   \item{filter_selections}{Static. A list containing the variables which must always
#'     be queried in order to use in filtering.}
#'   \item{excluded_company_ids}{Dynamic. Table from SQL containing information to exclude
#'    listings which have bad sale price data.}
#'   \item{default_selection_table}{Static. Table containing which variables (as R names) should
#'    always be selected. can differ on an industry basis.}
#'   \item{Other}{Other items will be listed with \code{ls(envir=shtrain:::shdata)}. These
#'     are used and updated internally within the package.}
#'   }
#'
NULL


#' #' @describeIn shdata Given a character string, lookup the object in \code{shdata}.
#' #'   This is not for use within the package.
#' #' @export
#' #' @include aaa.R
#'  get_shdata <- function(x) {
#'    if (exists("shdata", mode = "environment", envir = asNamespace('shtrain')))
#'   shdata[[x]]
#' }