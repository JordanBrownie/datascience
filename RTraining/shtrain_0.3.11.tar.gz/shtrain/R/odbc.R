#' Connect to databases using the odbc package
#'
#' Connect to Sandhills' databases using the odbc package.
#' @param server A valid server.
#' @param database A valid database for the server.
#' @param trusted Logical, defaults to `FALSE`. If `TRUE`, uses personal credentials
#' as defined in [CredentialManager](file://sandhills.int/file/data/dta/r/learning/resources/HowTo-CredentialManager.html)
#' instead of RDevelopmentUser.
#' @return A connection created using [odbc::dbConnect()].
#' @family connection functions
#' @import odbc
#' @export
create_odbc_connection <- function(server = "AGLIWEBDW.SANDHILLS.INT", database = "dbDataScientist", trusted = FALSE) {
  if (length(commandArgs(trailingOnly = TRUE) > 0) || !is.null(getOption("shconfig2.env"))) {
    command_arguments <- shtrain:::command_arguments()
    connection_string <- sprintf('driver=%s; %s database=dbDataScientist; ',
                                 command_arguments$sql_driver,
                                 command_arguments$db_connection)
    return(odbc::dbConnect(odbc::odbc(),
                           .connection_string = connection_string))
  }
  if (grepl("agliwebdw", tolower(server)) && trusted == FALSE) {
    return(odbc::dbConnect(
      odbc::odbc(),
      .connection_string =
        glue::glue(
          "driver={ODBC Driver 11 for SQL Server}; server=<<server>>; database=dbDataScientist;uid=RDevelopmentUser; pwd=kn2G0|6Fh86LH^kevOQf;multisubnetfailover=yes",
          .open = "<<",
          .close = ">>"
        )
    ))
  } else if (trusted && tolower(database) != "dbdatascientist") {
    if (grepl("agliwebdw", tolower(server))) {
      return(odbc::dbConnect(
        odbc::odbc(),
        .connection_string =  glue::glue("driver={ODBC Driver 11 for SQL Server}; server=<<server>>; database=<<database>>;trusted_connection=yes;multisubnetfailover=yes",
                                         .open = "<<",

                                         .close = ">>"
        )
      ))
    }
    return(odbc::dbConnect(
      odbc::odbc(),
      .connection_string =  glue::glue("driver={ODBC Driver 11 for SQL Server}; server=<<server>>; database=<<database>>;trusted_connection=yes;",
                                       .open = "<<",

                                       .close = ">>"
      )
    ))
  } else {
    stop("`create_odbc_connection()` can either connect to dbDataScientist with RDevelopmentUser on AGLIWEBDW.SANDHILLS.INT, ",
         "or connect to a different database with your Windows credentials. Any other type of connection ",
         "must be specified manually", call. = FALSE)
  }
}




#' Execute a SQL Stored Procedure (SP)
#'
#' A simple interface to stored procedures which return a single result-set.
#' Incompatible with multiple result-sets, due to the underlying package "odbc"
#' not supporting them.
#' @param name The SP to call. If not in the database the connection was established
#' with, fully qualify the name.
#' @param ... Name-value pairs to pass arguments into the SP. See "Details" for how
#' a vector is concatenated to a single value. See [sp_info()] for determining possible
#' arguments.
#' @param print Simple helper for debugging. It will print the SP call if `TRUE`.
#' @param collapse Separator for collapsing vectors greater than length 1. Defaults to `","`
#' @param con A connection from [create_odbc_connection()].
#' @return It will return a data.table with columns corresponding
#' to those specified from a call to [sp_info()].
#' @details
#' Every input to the SP must be length-1. For inputs greater than length-1, the
#' vector will be collapsed with `collapse` as the separator.
#' @family SQL functions
#' @family SP functions
#' @import data.table
#' @import odbc
#' @include utils.R
execute_sp <- function(name, ..., con, collapse = ",", print = FALSE) {
  dots <- list(...)
  if (any(names(dots) == "")) {
    stop("All Stored Procedure arguments must be named.", call. = FALSE)
  }
  non_null_args <-
    dots[!vapply(dots, is.null, FUN.VALUE = logical(1L))]
  list_params <-
    stringr::str_detect(tolower(names(non_null_args)), "^list|list$")
  list_params <- names(non_null_args)[list_params]
  non_null_args <-
    modifyList(non_null_args, lapply(
      non_null_args[list_params],
      FUN = function(x)
        paste(x, collapse = collapse)
    ))
  sp_call <- glue::glue("EXEC {name}")
  for (k in seq_along(non_null_args)) {
    nm <- names(non_null_args)[k]
    if (k != 1) {
      sp_call <- stringr::str_c(sp_call, ',')
    }
    sp_call <-
      stringr::str_c(
        sp_call,
        glue::glue_data_sql(
          " @{nm}={non_null_args[[k]]*}",
          .con = con,
          .x = dots
        ),
        collapse = " "
      )
  }
  if (length(non_null_args)) {
    patterns <- paste0("'", names(non_null_args), "'")
    replacements <- names(non_null_args)
    names(replacements) <- patterns
    sp_call <- stringr::str_replace_all(sp_call, pattern = replacements)
  }
  if (print)
    message(sp_call)

  data.table::setDT(odbc::dbGetQuery(con, sp_call))
}




#' SQL Stored Procedure (SP) information
#'
#' Identifies SP inputs and outputs, as well as a view of the definition.
#' @inheritParams execute_sp
#' @param print_definition Prints the Stored Procedure's definiton to the console.
#' This is preferable to returning it as a character vector, since it will be
#' formatted to print prettily.
#' @return A `data.table` with columns "role", "name", and "default".
#' Role may be either "argument" or "output_column". Several values of "name" may
#' have both roles. A value in "default" only makes sense for `role == "argument"`.
#' No rows with `role == "output_column"` could indicate that dynamic SQL is used
#' in the SP, thus the result-set could not be determined.
#' @section Warning:
#' Arguments to an SP are determined by parsing the definition, because SQL
#' Server does not provide a method for retrieving the arguments which can be
#' used through the odbc package. If something seems off, you should print the definition.
#' @family SQL functions
#' @family SP functions
sp_info <- function(name, con, print_definition = FALSE) {
  definition <-
    setDT(dbGetQuery(con, glue::glue_sql(.con = con, "EXEC sp_helptext N{name};")))

  output <-
    tryCatch({
      setDT(dbGetQuery(
        con,
        glue::glue_sql(.con = con, "EXEC sp_describe_first_result_set N{name}")
      ))[, list(role = "output_column",
                name = name,
                default = NA)]
    },
    error = function(e) {
      data.table(role = "output_column",
                 name = NA,
                 default = NA)
    })


  if (print_definition == TRUE) {
    cat(stringr::str_c(definition$Text, collapse = ""))
  }
  start_line <- stringr::str_which(definition$Text, "^CREATE PROCEDURE") + 1
  end_line <- stringr::str_which(definition$Text, "\\s*?AS\\s*?")[1] - 1
  variables <- stringr::str_trim(definition$Text[start_line:end_line])
  variables <- variables[variables != ""]
  defaults <- stringr::str_match(variables, " =\\s?([^,]+),?$")[, 2]
  variables <- stringr::str_match(variables, "@([^ ]*)\\s")[, 2]

  rbind(data.table(role = "argument", name = variables, default = defaults),
        output,
        fill = TRUE)
}


#' Check status of database restores
#'
#' `db_restore_check` is a function which checks the status of certain database
#' restores, using the stored procedure `dbDataScientist.dbo.Pr_CheckAutoRestoreJob`.
#'
#' @param category_id A single numeric category id. If provided, the function will only
#' check the relevant industry database for restore status. The default is NULL, and the
#' function will then check all industry databases for restore status.
#' @export
#' @details
#' This function should be included at the top of each updated master.R script, after the
#' proper libraries have been loaded.
#'
#' By default, the following databases are checked for restore status: dbMMM, dbPostSale
#' dbDealerServicesInventory, dbMachinery, dbTractorHouse, dbTruck, dbController.
#'
#' If a category_id is supplied, only dbMMM, dbPostSale, dbDealerServicesInventory, and
#' the industry database relevant to that category will be checked.
#' @examples \dontrun{
#' library("shconfig2")
#' load_packages("2017-10-15")
#' set_wd()
#' db_restore_check()
#' db_restore_check(category_id = 210)
#' }
db_restore_check <- function(category_id = NULL) {

  con <- create_odbc_connection()
  on.exit(odbc::dbDisconnect(con))
  flags <- data.table::setDT(shtrain:::execute_sp(name = "dbo.Pr_CheckAutoRestoreJob", con = con))

  if (is.null(category_id)) {
    restored <- flags[IsRestored == 1, DatabaseName]
    not_restored <- flags[IsRestored == 0, DatabaseName]
    if (length(not_restored) > 0) {
      stop(str_c(str_c(not_restored, collapse = ", ")), " not restored. Script execution stopped.")
    }
  }

  if (!is.null(category_id)) {
    ind_db <- shtrain:::base_db(shtrain:::get_industry(category_id))
    flags <- flags[DatabaseName %in% c("dbMMM", "dbPostSale", "dbDealerServicesInventory", ind_db)]
    restored <- flags[IsRestored == 1, DatabaseName]
    not_restored <- flags[IsRestored == 0, DatabaseName]
    if (length(not_restored) > 0) {
      stop(str_c(str_c(not_restored, collapse = ", ")), " not restored. Script execution stopped.")
    }
  }

  if (length(not_restored) == 0 && interactive()) {
    message(glue::glue("{str_c(restored, collapse = ', ')} all restored. Proceeding with script execution."))
  }

}
