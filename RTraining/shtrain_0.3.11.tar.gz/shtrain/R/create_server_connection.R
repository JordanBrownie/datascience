#' Retrieve or spoof the command arguments
#'
#' Gets (or spoofs) the command argument parameters that indicate the shared location,
#' the API URL, the driver, and the server connection information
#'
#' @param env NULL, 'local', 'dev', 'staging', or 'lab'. Environment that you
#' want to run in (only used when ran locally).
#'
#' @return a named list of the command arguments. Always reference by name, not position.
#' @family server connection functions
command_arguments <- function(env = NULL) {
  command_arguments <- commandArgs(trailingOnly = TRUE)
  if (is.null(env)) {
    env <- getOption("shconfig2.env")
  }
  if (length(command_arguments) == 6) {
    names(command_arguments) <- c("db_connection", "base_dir", "api_link", "env", "base_lib", "import_type")
    command_arguments <- c(as.list(command_arguments), list(sql_driver = '{ODBC Driver 11 for SQL Server}'))
  } else {
    command_arguments <- vector(mode = "list", length = 7L)
    names(command_arguments) <-  c("db_connection", "base_dir", "api_link", "env", "base_lib", "import_type", "sql_driver")
    command_arguments$db_connection <- 'server=AGLIWEBDW.SANDHILLS.INT; uid=RDevelopmentUser; pwd=kn2G0|6Fh86LH^kevOQf; MultiSubnetFailover=Yes;'
    command_arguments$sql_driver <- '{ODBC Driver 11 for SQL Server}'
    if (is.null(env) || env == "dev" ||  env == "local") {
      command_arguments$env <- ifelse(is.null(env), "local", ifelse(env == "dev", "dev", "local"))
      command_arguments$api_link <- 'http://devApiDS.dsdev.ext/EquipmentEvaluation/B45DE5615B1AE7B6172D85BF2C3B91CD/api/equipmentevaluationmodelimport'
      command_arguments$base_dir <- "\\\\dsdev.ext/file/DataScience"
      if (!is.null(env) && env == "dev") {
        command_arguments$base_lib <- "\\\\dsdev.ext/file/DataScience/SharedPackages"
      } else {
        command_arguments$base_lib <- "\\\\sandhills.int/file/data/dta/r/rlibraries"
      }
    } else if (env == "staging") {
      command_arguments$env <- "staging"
      command_arguments$api_link <-  "http://stgApiDS.dsstag.ext/EquipmentEvaluation/B45DE5615B1AE7B6172D85BF2C3B91CD/api/equipmentevaluationmodelimport"
      command_arguments$base_dir <- "\\\\dsstag.ext/file/DataScience"
      command_arguments$base_lib <- "\\\\dsstag.ext/file/DataScience/SharedPackages"
    } else if (env == "lab") {
      command_arguments$env <- "lab"
      command_arguments$db_connection <- 'server=SISQLDWSTG1\\DTA; uid=RDevelopmentUser; pwd=kn2G0|6Fh86LH^kevOQf; MultiSubnetFailover=Yes;'
      command_arguments$api_link <-  "http://stgApiDS.dsstag.ext/EquipmentEvaluation/B45DE5615B1AE7B6172D85BF2C3B91CD/api/equipmentevaluationmodelimport"
      command_arguments$base_dir <- "\\\\dsstag.ext/file/DataScience/Lab"
      command_arguments$base_lib <- "\\\\dsstag.ext/file/DataScience/Lab/SharedPackages"
    } else {stop("Either pass NULL, 'local', 'dev', 'staging', or 'lab' for `env`.")}
  }
  command_arguments
}

#' Connect to the specified environment
#'
#' Creates a connection to the specified environment (dev, staging, lab, or live).
#' An optional server argument lets you specify what server to connect to locally.
#' Defaults to `command_arguments()$db_connection`.
#
#' @param env Environment that you want to connect to (overwritten by command arguments).
#' Can be NULL, 'local', 'dev', 'staging', or 'lab' to allign with `command_arguments()`.
#'
#' @return RODBC connection to database.
#' @family server connection functions
#' @export
#'
#' @importFrom RODBC odbcDriverConnect
create_server_connection <- function(server = NULL, env = NULL) {
  # If this changes, update code in zzz.R
  command_arguments <- command_arguments(env = env)
  connection_string <- stringr::str_c("driver=",command_arguments$sql_driver,";database=dbDataScientist;",
                                      stringr::str_replace_all(command_arguments$db_connection, " ", ""))

  if (is.null(server) || length(commandArgs(trailingOnly = TRUE) > 0)) {
    connection_string <- stringr::str_c("driver=",command_arguments$sql_driver,";database=dbDataScientist;",
                                        stringr::str_replace_all(command_arguments$db_connection, " ", ""))
  } else {
    server <- str_replace_all(server, "\\\\", "\\\\\\\\")
    connection_string <- stringr::str_c("driver=",command_arguments$sql_driver,";database=dbDataScientist;",
                                        stringr::str_replace_all(command_arguments$db_connection, " ", ""))
    connection_string <- gsub("AGLIWEBDW(\\.SANDHILLS\\.INT)?", server, connection_string, ignore.case = TRUE)
  }
  odbcDriverConnect(connection_string)

}


#' Connect to SQL using Windows Authentication
#'
#' Connects to SQL using Windows Authentication. Only valid on your own computer.
#'
#' @param database The database you are making your queries against.
#' @param server SQl server to connect to. Must be defined in your Credential Manager.
#' @return RODBC connection to database using your Windows authentication. Note
#' that this connection will only work on your local machine, not on production
#' environments.
#' @family server connection functions
#' @export
create_trusted_connection <- function(database = "dbMachinery", server = "AGLIWEBDW") {
  if (tolower(server) == 'agliwebdw') {
  odbcDriverConnect(glue::glue("driver={ODBC Driver 11 for SQL Server}; server={server}; database={db};trusted_connection=yes; MultiSubnetFailover=Yes;"))
  } else {
    odbcDriverConnect(glue::glue("driver={ODBC Driver 11 for SQL Server}; server={server}; database={db};trusted_connection=yes;"))
  }
}
