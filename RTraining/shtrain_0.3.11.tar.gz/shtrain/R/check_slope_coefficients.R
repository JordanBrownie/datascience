#' Coefficient comparison for numeric and factor interactions
#'
#' Coefficient comparison for numeric/factor interactions. Outlying levels
#' within a factor are detected using a coefficient comparison. These levels
#' go through additional checks, resulting in a data.table containing information
#' about the bad levels. See details.
#'
#' @param data Data used to train the model.
#' @param model [stats::glm()] model containing numeric:factor interactions.
#' @param ratio_bounds A length-2 numeric vector. The ratio referenced is the
#' coefficient value divided by the average price for a machine for that factor level.
#' If it lies outside the bounds provided, it is "too extreme", and will be excluded.
#' Overridden by `n_bounds`.
#' @param n_bounds A length-2 numeric vector. If a factor level in an interaction occurs
#' at most `n_bounds[1]` times, it will be included in the output table. If a factor
#' level in an interaction occurs more than `n_bounds[2]` times, it will never be included
#' in the output table. The `ratio_bounds` provided are used to diagnose the terms with
#' factor levels in between `n_bounds`.
#'
#' @return data.table containing information on bad coefficients, with columns
#' "coef_name", "numeric", "factor", "level", "count", "ratio", "coef_value", "mean_price_usd".
#' This table can be passed to `check_insufficient_data()` to not value machines
#' containing one of these factor levels.
#' @export
#' @details
#' This function is used to identify machines which we don't want to value on FE.
#' It does this by comparing the average price for a machine with the given level
#' in each interaction to the value of the coefficient.
#'
#' Suppose that we have an `age:manufacturer` interaction. Consider the manufacturer
#' level "badman". The overall effect of age for badman machines is
#' `age:manufacturer badman + age`. So, for each increase of 1 in age will
#' increase the value of the machine by the coefficient (hopefully negative).
#' Suppose the mean USD sale price for such a manufacturer is 50,000. Yet the
#' overall effect of age for badman machines is -25,000. This means it loses
#' 50% of the average value every year -- clearly unreasonable. The ratio from
#' this calculation would be `-0.5`. This is an extreme effect on age. We do not
#' want to show this on the site, unless we are confident this value is somehow reasonable.
#' For example, if I have 20,000 badman observations, I would have confidence
#' the coefficient is accurate, and opt to keep it. `n_bounds[2]` sets this "confidence level".
#' Similarly, if I had very few, I'd ignore the heuristic and exclude. `n_bounds[1]` sets
#' this "confidence level".
#'
#' The determination of ratio bounds might be a bit more difficult. For age, we want our
#' ratio to be negative -- `ratio_bounds[2] <=0`. `ratio_bounds[1] == -0.5` is not a good
#' choice, but what about `-0.05` vs. `-0.10`? It is hard to say. This function is aimed
#' at removing the most egregious examples, so either choice would be okay.
#'
#'
#' @importFrom stringr str_split str_detect str_match
check_slope_coefficients <- function(data, model, ratio_bounds = c(-Inf, Inf), n_bounds = c(-Inf, Inf)) {

  stopifnot(is.data.table(data),
            is.numeric(ratio_bounds),
            is.numeric(n_bounds),
            length(ratio_bounds) == 2,
            length(n_bounds) == 2)
  response <- get_response(model)
  # This block determines which coefficients are comprised of num/fctr or fctr/num interactions.
  coefficients <- model$coefficients
  is_factor <- attr(model$terms, "dataClasses") %in% c("factor", "character")
  numerics <- names(attr(model$terms, "dataClasses"))[!is_factor]
  factors <- names(attr(model$terms, "dataClasses"))[is_factor]
  split <- str_split(names(model$coefficients), ":")
  simple_factor_search <- paste(factors, collapse = "|")
  numeric_search <- str_c(numerics, collapse = "|")
  has_factor <- lapply(split, str_detect,  pattern = simple_factor_search)
  names(has_factor) <- names(coefficients)
  has_one_factor <- unlist(lapply(has_factor, function(x) sum(x) == 1 & length(x) == 2), use.names = FALSE)
  num_fctr_vals <- coefficients[has_one_factor]
  num_fctr_terms <- names(num_fctr_vals)
  numeric_search <- str_c(".*:?(", str_c(str_c("\\Q", numerics, "\\E"), collapse = "|"), "):?.*")
  factor_search <- str_c(".*:?(", str_c(factors, collapse = "|"), "):?.*")
  level_search <- str_c("(", str_c(str_c("\\Q", factors, "\\E"), collapse = "|"), ")([^:]*)")
  if (length(num_fctr_terms) == 0) {
    return(
      data.table::data.table(
        coef_name = character(),
        numeric = character(),
        factor = character(),
        level = character(),
        count = numeric(),
        ratio = numeric(),
        coef_value = numeric(),
        mean_price_usd = numeric()
      )
    )
  }
  parsed_coef <- data.table(coef_name = num_fctr_terms,
                            numeric = str_match(num_fctr_terms, pattern = numeric_search)[, 2], # First capture group (first numierc)
                            factor = str_match(num_fctr_terms, pattern = factor_search)[, 2], # First capture group (first factor)
                            level = str_match(num_fctr_terms, pattern = level_search)[, 3], # Second capture group (first factor, second level)
                            coef_value = num_fctr_vals)
  # Compares coefficient values to upper and lower bounds calculated by group, adds main effect
  num_value <- coefficients[match(parsed_coef[["numeric"]], numerics, nomatch = 0)]
  parsed_coef[, coef_value := coef_value + num_value]
  parsed_coef[, `:=`(lb = quantile(coef_value, probs = 0.25, na.rm = TRUE) - 1.5*IQR(coef_value, na.rm = TRUE),
                     ub = quantile(coef_value, probs = 0.75, na.rm = TRUE) + 1.5*IQR(coef_value, na.rm = TRUE)) , by = c("numeric", "factor")]

  # Subsets to potential outliers
  outliers <- parsed_coef[coef_value > ub | coef_value < lb]
  if (nrow(outliers) == 0) {
    return(
      data.table::data.table(
        coef_name = character(),
        numeric = character(),
        factor = character(),
        level = character(),
        count = numeric(),
        ratio = numeric(),
        coef_value = numeric(),
        mean_price_usd = numeric()
      )
    )
  }
  # Used to determine which levels for which factors are potential outliers
  outlier_levels <- dcast(outliers, level~factor, value.var =  "level", fun.aggregate = function(x) as.character(length(x)) )
  factor <- names(outlier_levels)[-1] # Names of factors, drop -1 because it retains level column.
  prices <- vector(mode = "list", length = length(factors))
  # This loop subsets the data to one element of `factor` at a time,
  # then calculates the mean price and count by level. These results are
  # combined and then merged back to outliers to form the result table.
  for (k in seq_along(factor)) {
    i <- outlier_levels[[factor[k]]] > 0

    outlier_levels[i, (factor[k]) := level]
    temp_data <- data[outlier_levels[i, factor[k], with = FALSE],
                      nomatch = 0,
                      on = factor[k]]
    prices[[k]] <- melt(temp_data[, list(mean_price = round(mean(get(response), na.rm = TRUE), 0),
                                         count = sum(!is.na(get(response)))),
                                  by = c(factor[k])],
                        measure.vars = factor[k],
                        na.rm = TRUE,
                        variable.name = "factor", value.name = "level")
  }
  all_prices <- rbindlist(prices)
  result <- outliers[all_prices,
                     `:=`(mean_price_usd = i.mean_price,
                          count = i.count),
                     on = c("factor", "level")][
                       !is.na(mean_price_usd)]
  result <- result[,`:=`(ratio = coef_value/mean_price_usd,
                         ub = NULL,
                         lb = NULL)][
                           (ratio > ratio_bounds[2] |
                              ratio < ratio_bounds[1] |
                              count <= n_bounds[1]) & !(count >= n_bounds[2])]
  setcolorder(result, c("coef_name", "numeric", "factor", "level", "count", "ratio", "coef_value", "mean_price_usd"))
  result
}