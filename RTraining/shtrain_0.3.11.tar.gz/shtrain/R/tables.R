#' MSRP table
#'
#' Queries the MSRP table and returns the
#' information keyed to `make_model`.
#' @param con RODBC connection.
#' @param category_id `NULL` for the entire table, or a vector of category IDs.
#' @return Table with `make_model`, `msrp_currency`, `msrp_base`, and `msrp_year`.
#' @export
#' @importFrom RODBC sqlQuery
#' @seealso add_msrp
#' @family SQL table functions
#' @importFrom data.table setDT
msrp_table <- function(con, category_id = NULL) {
  q <-  "SELECT CONCAT(LOWER(od.manufacturer), ' ', LOWER(od.model)) as
  make_model, msrp.Year as msrp_year, msrp.MSRPBaseline as msrp_base,
  LOWER(msrp.Currency) as msrp_currency
    from dbmmm.dbo.objectdefaults od
  inner join dbmmm.dbo.objectdefaultcatmsrpbaseline (NOLOCK) msrp on
  msrp.ObjectDefaultID = od.ObjectDefaultID "
  filter <- if (length(category_id) > 0) {
    glue::glue("WHERE msrp.CategoryID IN ({glue::collapse(category_id, sep = ', ')})")
  } else ""
  res <- setDT(sqlQuery(con, paste(q, filter), stringsAsFactors = FALSE))
  # cache_dependency(source = "make_model", derived = "msrp_base")
  res
}


#' Modified SQL region table
#'
#' Combines state and statecode into one column. The query pulls region's specific
#' to the category ID, then the general ones. The correct California region is picked
#' for trucks. This will return inappropriate output for several categories, use
#' with caution! To define regions based on country instead of state, construct
#' a list of the form `list(region1 = c(country1, country2), ...)` and pass to
#' `region_list` in [add_region()].
#'
#' @param con An `RODBC`  connection from [create_server_connection()
#' @param category_id A vector of category IDs.
#'
#' @return a `data.table`` with columns "region" and "state".
#'
#' @importFrom data.table as.data.table melt
#' @importFrom glue glue
#' @importFrom RODBC sqlQuery
#' @family SQL table functions
#' @export
region_table <- function(con, category_id) {
  if (length(category_id) != 1) {
    stop("`region_table` only supports one category ID. Please create your region table through",
         " multiple calls.", call. = FALSE)
  }
  filter <- glue("ObjectCategoryID IN ({category_id}) or (ObjectCategoryID is NULL AND BaseCategoryID is NULL)")
  if (tolower(category_id) != "null" && get_industry(category_id = category_id) == "trk") {
    filter <- glue("{filter} or (ObjectCategoryID IS NULL and BaseCategoryID = 27)")
  }
  regions <- setDT(sqlQuery(con, glue("SELECT LOWER(Region) as region,
                                      LOWER(State) as state, LOWER(StateCode) as state_code
                                      from dbo.Region where {filter}"), stringsAsFactors = FALSE))
  # Added to fix mis-specified function calls in formula
  if (tolower(category_id) != "null" && get_industry(category_id = category_id) == "trk") {
    regions <- regions[!(state == "california" & region == "western")]
  }
  regions <- melt(as.data.table(regions), id.vars = "region", measure.vars = c("state", "state_code"), value.name = "state")
  cache_dependency(source = "state", derived = "region")
  regions[,list(region, state)]
}

#' Internal category reference table
#'
#' Modified copy of dbMMM.dbo.ObjectCategories. Contains relationship between
#' category ID, parent category ID, category, industry, and base category ID.
#' @param category_id Optional. A vector of category IDs to filter results.
#' @param industry Optional. A vector of industry abbreviations to filter results.
#' @param category Optional. A (case-insensitive) regular expression to filter results.
#' @param base_category_id Optional. A vector of base category IDs to filter results.
#' @return By default, all of `shtrain:::shdata$category_table` with as a `data.table`.
#' It will filter on each argument provided.
#' @export
#' @importFrom data.table as.data.table
#' @family SQL table functions
category_table <- function(category_id = NULL, industry = NULL, category = NULL, base_category_id = NULL) {
  tb <- as.data.table(shdata$category_reference, stringsAsFactors = FALSE)
  if (!is.null(category_id)) {
    .cat <- category_id
    tb <- tb[category_id %in% .cat]
  }
  if (!is.null(industry)) {
    .ind <- industry
    tb <- tb[industry %in% .ind]
  }
  if (!is.null(base_category_id)) {
    .bci <- base_category_id
    tb <- tb[base_category_id %in% .bci]
  }
  if (!is.null(category)) {
    .catname <- category
    tb <- tb[tolower(category) %like% .catname]
  }
  tb
}


#' Make model table
#'
#' Table consisting of all active category/make/model combinations.
#' @param con An `RODBC` connection from [create_server_connection()]
#' @param category_id Optional. A vector of category IDs to filter results.
#' @param base_category_id Optional. A vector of category IDS to filter results.
#' @param manufacturer Optional. A vector of manufacturers to filter results.
#' @param model Optional. A vector of models to filter results.
#' @param and_or Either "and" or "or". "And" means each row returned satisfies
#' all filter criteria, while "or" means each row satisfies at least one critieron.
#' @return A `data.table` with columns `category_id`, `base_category_id`,
#' `manufacturer`, `make_model_group`, `make_model`, `odc_status`, `od_status`, and `n_categories`.
#' @details
#' `odc_status == 'active' & od_status == 'active'` aligns with what is typically
#' meant by active cat make models. `n_categories` indicates how many categories
#' the `make_model` is active in. `od_status` doesn't seem to indicate much of anything.
#' There are no make models which `odc_status == 'active' & od_status == 'inactive'`
#'  though there are make models with `od_status == 'active' & n_categories == 0`.
#' @importFrom glue glue collapse
#' @importFrom data.table setDT
#' @importFrom RODBC sqlQuery
#' @export
#' @family SQL table functions
#' @family MMM functions
mm_table <- function(con, category_id = NULL, base_category_id = NULL, manufacturer = NULL,  model = NULL,
                     and_or = "and") {
  stopifnot(and_or %in% c("and", "or"))
  and_or <- paste(" ", and_or, " ")
  filters <- c(category_id = "category_id IN {sql_c(category_id)}",
               base_category_id = "base_category_id IN {sql_c(base_category_id)}",
               manufacturer = "manufacturer in {sql_c(manufacturer)}",
               model = "model in {sql_c(model)}")
  filters <- sql_filter_select(filters)
  q <- glue::glue(glue::collapse(c("with D as (SELECT LOWER(OD.Manufacturer) as manufacturer, LOWER(OD.Model) as model, ODC.ObjectCategoryID as category_id, FCV.BaseCategoryID as base_category_id,
                                   CONCAT(LOWER(OD.Manufacturer), ' ', LOWER(OD.MODEL)) as make_model,
                                   LOWER(OD.ModelGroup) as model_group,
                                   CONCAT(LOWER(OD.Manufacturer), ' ', LOWER(OD.ModelGroup)) as make_model_group,
                                   lower(odc.status) as odc_status,
                                   lower(od.status) as od_status
                                   FROM dbo.ObjectDefaults OD(NOLOCK)
                                   INNER JOIN dbo.ObjectDefaultCats ODC(NOLOCK) ON ODC.ObjectDefaultID = OD.ObjectDefaultID
                                   INNER JOIN dbo.FullCategoryView FCV(NOLOCK) ON FCV.ObjectCategoryID = ODC.ObjectCategoryID
                                   WHERE 1=1
                                   --AND OD.Status = 'ACTIVE'
                                   --AND ODC.Status = 'ACTIVE'
                                   and FCV.BaseCategoryID IN (13, 464, 27, 4))
                                   select * from D WHERE 1=1 ", filters ), sep = and_or))
  mmt <- setDT(sqlQuery(con, q, stringsAsFactors = FALSE))
  mm_counts <- mmt[odc_status == 'active', list(n_categories = .N), make_model]
  result <- mm_counts[mmt, on = "make_model"][is.na(n_categories), n_categories := 0]
  result
}

#' Review Status ID table for PostSale
#'
#' The review status ID table for PostSale (aftersale),
#' which links bits to statuses. [expand_review_status_id()]
#' makes sense of this field in R. Pulls from `dbPostSale.dbo.ReviewStatus`.
#' @param con An `RODBC` connection from [create_server_connection()].
#' @return A `data.table` with columns "review_status_id", "name", and "status".
#' The output is not formatted, aside from the names.
#' @importFrom data.table setDT
#' @importFrom RODBC sqlQuery
#' @export
#' @family SQL table functions
review_status_table <- function(con) {
  setDT(sqlQuery(con,"SELECT ReviewStatusID as review_status_id,
                 Name as name, Status as status from dbPostSale.dbo.ReviewStatus
                 ", stringsAsFactors = FALSE))

}

#' Event Categories table for ObjectHistory
#'
#' The event categories table for ObjectHistory. This table may
#' differ slightly between industries. For machinery, pulls from
#' `dbMachinery.dbo.EventCategories`.
#' @param con An `RODBC`  connection from [create_server_connection()
#' @param industry An industry abbreviation.
#' @return A `data.table` with columns "event_category_id" and "category".
#' @include querying.R
#' @export
event_category_table <- function(con, industry) {
  db <- base_db(industry)
  setDT(sqlQuery(con, glue("SELECT EventCategoryID as event_category_id,
                           category from {db}.dbo.EventCategories"), stringsAsFactors = FALSE))
}

#' Event Type table for ObjectHistory
#'
#' The event type table for ObjectHistory. This table may differ
#' slightly between industries. For machinery, pulls from
#' `dbMachinery.dbo.EventTypes`.
#' @param con An `RODBC`  connection from [create_server_connection()
#' @param industry An industry abbreviation.
#' @return A `data.table` with columns "event_type_id" and "event_type".
#' @export
event_type_table <- function(con, industry) {
  db <- base_db(industry)
 setDT(sqlQuery(con, glue("SELECT EventType as event_type_id,
                           EventType as event_type from {db}.dbo.EventTypes"), stringsAsFactors = FALSE))
}


#' Select a subset of filters from a named vector
#'
#' @param x A named character vector, where the names correspond to the arguments
#' used for filtering *in the function calling `sql_filter_select()`*.
#' @return A subset of x which corresponds to the non-`NULL` arguments in the calling
#' function.
#' @keywords internal
sql_filter_select <- function(x) {
  stopifnot(all(names(x) != ""))
  stopifnot(!is.list(x))
  ind <- seq_along(x)
  x[vapply(ind, function(y) !is.null(get(names(x)[y], pos = parent.frame(3))), FUN.VALUE = logical(1L), USE.NAMES = FALSE)]
}
#' @keywords internal
sql_c <- function(x) {
  if (!is.numeric(x)) {
    paste0("(", glue::collapse(glue::glue("'{x}'"), sep = ", "), ")")
  } else {
    paste0("(", glue::collapse(x, sep = ", "), ")")
  }
}

