#' Adds a statistic by group
#'
#' `add_summary` is a *specification* of a recipe step
#' which will compute a given function by group and merge
#' to the results.
#' @inheritParams step_basic
#' @param col Column or set of columns to apply `fun` to.
#' @param by A list of column names.
#' @param fun Any function which takes in a vector and outputs a single number.
#' @param options Named list of options to use in `fun`
#' @param new_col Generated in [prep()] if not provided.
#' @param ref_summary table of summary statistics.
#' @details
#'
#' * Step: Captures `by` as an expression.
#' * Prep: Creates `new_col` if necessary. Generates `ref_summary`
#' * Bake: Merges to `newdata` to `ref_summary` on `by`.
#' @export
add_summary <- function(recipe, col, by, fun, options = NULL, new_col = NULL, ref_summary = NULL, trained = FALSE) {
  fun <- deparse(substitute(fun))
  by <- substitute(by)
  add_step(recipe,
           add_summary_new(
             col = col,
             by = by,
             fun = fun,
             options = options,
             new_col = new_col,
             ref_summary = ref_summary,
             trained = trained
           ))
}

add_summary_new <- function(col, by, fun, options = NULL, new_col = NULL, ref_summary = NULL, trained = FALSE) {
  add(subclass = "summary",
       col = col,
       by = by,
       fun = fun,
       options = options,
       new_col = new_col,
       ref_summary = ref_summary,
       trained = trained)
}



prep.add_summary <- function(x, training, ...) {
  if (is.null(x$new_col)) {
    new_col <- paste0(x$fun,"_",  x$col)
  } else {
    new_col <- x$new_col}
   f <- match.fun(x$fun)
  ref <- training[,lapply(.SD, function(y) do.call(f, args = c(list(y), x$options))), by = eval(x$by),
                  .SDcols = x$col]
  by_cols <- length(as.character(x$by)[-1])
  setnames(ref, seq(from = length(x$by), to = ncol(ref), by = 1) , new = new_col)
  for (k in new_col) {
    set(x = ref,
        i = which(is.nan(unlist(ref[[k]], use.names = FALSE))),
        j = k,
        value = NA_real_)
  }
  add_summary_new(col = x$col,
                by = x$by,
                fun = x$fun,
                new_col = x$new_col,
                ref_summary = ref,
                trained = TRUE)
}

bake.add_summary <- function(object, newdata, ...) {
  merge(newdata, object$ref_summary, by = as.character(object$by)[-1], all.x = TRUE)
}

summary.add_summary <- function(x, ...) {
if (is_trained(x)) {
x$ref_summary
} else {
data.table(summary_of = x$col,
           grouped_by = x$by,
           statistic = as.character(x$fun),
           new_col = ifelse(is.null(x$new_col), paste0(as.character(x$fun), x$col), x$new_col))
}
}
