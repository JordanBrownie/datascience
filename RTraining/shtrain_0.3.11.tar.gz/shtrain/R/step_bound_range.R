#' Bound numeric variables
#'
#' `step_bound` creates a *specification* of a recipe step that will
#'   set evaluations exceeding the bounds to the closest bound.
#' @inheritParams step_basic
#' @param cutoffs A named list with the structure `list(spec = c(floor, ceiling))`.
#' @inherit step_basic return
#' @export
#' @seealso step_bound_evaluations bound_range
#' @family step functions
#' @details
#'
#'  Step: Nothing
#'  Prep: Nothing
#'  Bake: Sets exceeding values to the closest bound. Sets message in `r_message`
#'    indicating change.
step_bound <- function(recipe, cutoffs, trained = FALSE) {
  add_step(recipe,
           step_bound_new(
             cutoffs = cutoffs,
             trained = trained))
}

step_bound_new <- function(cutoffs, trained = FALSE) {
  step(subclass = "bound",
       cutoffs = cutoffs,
       trained = trained)
}

prep.step_bound <- function(x, training, ...) {
  step_bound_new(cutoffs = x$cutoffs,
                 trained = TRUE)
}
#' @importFrom stringr str_c
bake.step_bound <- function(object, newdata, ...) {
  specs <- names(object$cutoffs)
  cutoffs <- matrix(unlist(object$cutoffs, use.names = FALSE), ncol = 2, byrow = TRUE)
  for (k in seq_along(specs)) {

    over_max <- which(newdata[[specs[k]]] > cutoffs[k, 2])
    set(x = newdata,
        i = over_max,
        j = specs[k],
        value = cutoffs[k, 2])
    dt_add_message(newdata, over_max, str_c(" Upper Bound:", specs[k], sep = " "))

    under_min <- which(newdata[[specs[k]]] < cutoffs[k, 1])
    set(x = newdata,
        i = under_min,
        j = specs[k],
        value = cutoffs[k, 1])
    dt_add_message(newdata, under_min, str_c(" Lower Bound:", specs[k], sep = " "))

  }

  newdata
}

summary.step_bound <- function(x, ...) {
  data.table(spec = names(x$cutoffs),
             minimum = vapply(x$cutoffs, FUN = function(x){x[1]}, FUN.VALUE = double(1), USE.NAMES = FALSE),
             maximum = vapply(x$cutoffs, FUN = function(x){x[2]}, FUN.VALUE = double(1), USE.NAMES = FALSE))
}

#' @export
bound_range <- function(data, cutoffs) {
  specs <- names(cutoffs)
  cutoffs <- matrix(unlist(cutoffs, use.names = FALSE), ncol = 2, byrow = TRUE)
  for (k in seq_along(specs)) {

    over_max <- which(data[[specs[k]]] > cutoffs[k, 2])
    set(x = data,
        i = over_max,
        j = specs[k],
        value = cutoffs[k, 2])
    dt_add_message(data, over_max, str_c(" Upper Bound:", specs[k], sep = " "))

    under_min <- which(data[[specs[k]]] < cutoffs[k, 1])
    set(x = data,
        i = under_min,
        j = specs[k],
        value = cutoffs[k, 1])
    dt_add_message(data, under_min, str_c(" Lower Bound:", specs[k], sep = " "))

  }

  data
}