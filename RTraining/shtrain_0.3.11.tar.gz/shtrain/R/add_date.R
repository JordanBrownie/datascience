#' Adds sale date columns
#'
#' Adds `date` as `sale_date` in ISO8601 format to listings missing a `sale_date`.
#' Adds `date` to current asking listings, and any auction or aftersale listings
#' missing `sale_date` - This is needed to support FE scoring. Historical asking
#' receives the associated `web_end_date`. Listings missing `data_type` will receive
#' the date passed to `add_date()` as `sale_date`.
#' @inheritParams step_basic
#' @param date `NULL` or date in "YYYY-mm-dd" format. `NULL` sets it to `Sys.Date()`.
#' See details
#' @param month Logical scalar. Add decimal `sale_month`?
#' @param week Logical scalar. Add decimal `sale_week`?
#' @inherit step_basic return
#' @details
#' * Step: Nothing.
#' * Prep: If `date == NULL`, `date <- Sys.Date()`. Check date is in correct format.
#' * Bake: Adds date columns specified above. Format all to be of class `IDate`.
#' @export
add_date <- function(recipe, date = NULL, month = TRUE, week = TRUE, trained = FALSE) {
  add_step(recipe, add_date_new(
    date = date,
    month = month,
    week = week,
    trained = trained
  ))
}

add_date_new <- function(date = NULL, month = TRUE, week = TRUE, trained = FALSE) {
  add(subclass = "date",
       date = date,
       month = month,
       week = week,
       trained = trained)
}


prep.add_date <- function(x, training, ...) {
  date <- add_default(x$date, as.IDate(Sys.Date(), origin = '1753-01-01'))
  valid_date <- str_detect(date, "[0-9]{4}-[0-9]{2}-[0-9]{2}") & month(date) <= 12
  if (!valid_date) {
    stop(glue::glue("The date {date} does not appear to be valid. Please enter in yyyy-mm-dd format."),
         call. = FALSE)
  }
  add_date_new(date = date,
               month = x$month,
                week = x$week,
                trained = TRUE)
}

#' @importFrom data.table %chin% set copy as.IDate year month week
bake.add_date <- function(object, newdata, ...) {
  asking <- newdata[["data_type"]] == "asking"
  # Sets column to correct type
  set(x = newdata,
      i = NULL,
      j = "sale_date",
      value = as.IDate(newdata[["sale_date"]], origin = "1753-01-01"))
  # Sets sale date to provided date for non-asking points missing sale date.
  # This is necessary on scoring.
  set(x = newdata,
      i = which(is.na(newdata[["sale_date"]]) & !asking),
      j = "sale_date",
      value = as.IDate(object$date, origin = "1753-01-01"))
  # format web end date
   if ("web_end_date" %in% names(newdata)) {
  set(x = newdata,
      i = NULL,
      j = "web_end_date",
      value = as.IDate(newdata[["web_end_date"]], origin = "1753-01-01"))
}
  # Assign future_end_date while checking whether we need to assign these dates.
  # If statements are TRUE if the condition is any non-zero number.
  if (length(past_end_date <-
            which(newdata[["web_end_date"]] < object$date & asking))) {
    # If the web_end_date is in the past, assign the web end date as sale date for asking only.
  set(x = newdata,
      i = past_end_date,
      j = "sale_date",
      value = newdata[["web_end_date"]][past_end_date])
  }
  # format web start date
  if ("web_start_date" %in% names(newdata)) {
    set(x = newdata,
        i = NULL,
        j = "web_start_date",
        value = as.IDate(newdata[["web_start_date"]], origin = "1753-01-01"))
  }
  # assign object$date to asking listings where object$date falls between
  # web start/end dates.
  if (all(c("web_start_date", "web_end_date") %in% names(newdata))) {
    current_asking <- which(newdata[["web_end_date"]] >= object$date &
                              newdata[["web_start_date"]] <= object$date &
                              asking)
    set(x = newdata,
        i = current_asking,
        j = "sale_date",
        value = object$date)
  } else {
    asking <- which(is.na(newdata[["sale_date"]]) & asking)
    set(x = newdata,
        i = asking,
        j = "sale_date",
        value = object$date)
  }
  # Create sale_month/sale_week columns if requested.
  missing_data_type <- which(is.na(newdata[["data_type"]]))
  set(x = newdata,
      i = missing_data_type,
      j = "sale_date",
      value = object$date)
  if (object$month == TRUE) {
    set(x = newdata,
        i = NULL,
        j = "sale_month",
        value = year(newdata[["sale_date"]]) + (month(newdata[["sale_date"]]) - 1)/12)
  }
  if (object$week == TRUE) {
    set(x = newdata,
        i = NULL,
        j = "sale_week",
        value = year(newdata[["sale_date"]]) + (week(newdata[["sale_date"]]) - 1)/52)
  }


  newdata
}


#' @describeIn add_date Non-recipe version.
#' @export
#' @importFrom data.table  as.IDate week month year %chin%
.add_date <- function(data, date = NULL, month = TRUE, week = TRUE) {
  data <- copy(data)
  asking <- data[["data_type"]] == "asking"
  # Sets column to correct type
  set(x = data,
      i = NULL,
      j = "sale_date",
      value = as.IDate(data[["sale_date"]], origin = "1753-01-01"))
  # Sets sale date to provided date for non-asking points missing sale date.
  # This is necessary on scoring.
  set(x = data,
      i = which(is.na(data[["sale_date"]]) & !asking),
      j = "sale_date",
      value = as.IDate(date, origin = "1753-01-01"))
  # format web end date
  if ("web_end_date" %in% names(data)) {
    set(x = data,
        i = NULL,
        j = "web_end_date",
        value = as.IDate(data[["web_end_date"]], origin = "1753-01-01"))
  }
  # Assign future_end_date while checking whether we need to assign these dates.
  # If statements are TRUE if the condition is any non-zero number.
  if (length(past_end_date <-
             which(data[["web_end_date"]] < date & asking))) {
    # If the web_end_date is in the past, assign the web end date as sale date for asking only.
    set(x = data,
        i = past_end_date,
        j = "sale_date",
        value = data[["web_end_date"]][past_end_date])
  }
  # format web start date
  if ("web_start_date" %in% names(data)) {
    set(x = data,
        i = NULL,
        j = "web_start_date",
        value = as.IDate(data[["web_start_date"]], origin = "1753-01-01"))
  }
  # assign object$date to asking listings where object$date falls between
  # web start/end dates.
  if (all(c("web_start_date", "web_end_date") %in% names(data))) {
    current_asking <- which(data[["web_end_date"]] >= date &
                              data[["web_start_date"]] <= date &
                              asking)
    set(x = data,
        i = current_asking,
        j = "sale_date",
        value = date)
  } else {
    asking <- which(is.na(data[["sale_date"]]) & asking)
    set(x = data,
        i = asking,
        j = "sale_date",
        value = date)
  }

  # Create sale_month/sale_week columns if requested.
  missing_data_type <- which(is.na(data[["data_type"]]))
  set(x = data,
      i = missing_data_type,
      j = "sale_date",
      value = date)
  if (month == TRUE) {
    set(x = data,
        i = NULL,
        j = "sale_month",
        value = year(data[["sale_date"]]) + (month(data[["sale_date"]]) - 1)/12)
  }
  if (week == TRUE) {
    set(x = data,
        i = NULL,
        j = "sale_week",
        value = year(data[["sale_date"]]) + (week(data[["sale_date"]]) - 1)/52)
  }
  data
}