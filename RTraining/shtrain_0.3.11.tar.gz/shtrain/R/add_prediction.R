#' Add predictions in a recipe
#'
#' `add_prediction()` is a *specification* of a recipe step which takes a model and
#' adds predictions, preventing errors from unknown factor levels.
#'
#' @inheritParams step_basic
#' @param model An object of class "glm", "rpart", or an rx model which inherits class "mlModel".
#' Other model objects may be passed, but are not tested.
#' @param new_col Optional. Defaults to model response prefixed with "pred_".
#' @param type Populated on [prep()]. Captures class of model.
#' @inherit step_basic return
#' @family step functions
#' @details
#'
#' * Step: Nothing
#' * Prep: Check `class` of the model, warn if not "glm", "rpart", or "mlModel". Generate default
#' `new_col` name if not provided.
#' * Bake: Add predictions, using [batch_to_na()] to guarantee no errors due to unknown levels.
#' @include internal-get.R
#' @include utils.R
#' @export
add_prediction <- function(recipe, model, trained = FALSE, new_col = NULL, type = NULL) {
  add_step(recipe,
           add_prediction_new(model = model,
                              trained = trained,
                              new_col = new_col,
                              type = type))
}


add_prediction_new <- function(model, trained = FALSE, new_col = NULL, type = NULL) {
  add(subclass = "prediction",
      model = model,
      new_col = new_col,
      trained = trained,
      type = type)
}


prep.add_prediction <- function(x, training, ...) {
  if ((!any(c("glm", "rpart") %in% class(x$model)) && !any(inherits(x$model, "mlModel"))) && interactive()) {
    warning("`add_prediction()` only tested with objects of  modelling functions \"rx*\", \"rpart\" or \"glm\".",
            " Inspect output carefully.", call. = FALSE)
  }
  new_col <- x$new_col %||% paste0("pred_", get_response(x$model))
add_prediction_new(
  minimize(x$model),
  trained = TRUE,
  new_col = new_col,
  type = class(x$model)
)
}

#' @importFrom RevoScaleR rxPredict
bake.add_prediction <- function(object, newdata, ...) {
  if (!inherits(object$model, "mlModel")) {
  set(x = newdata,
      i = NULL,
      j = object$new_col,
      value = predict(object = object$model, newdata = batch_to_na(newdata, object$model)))
  } else {
    set(x = newdata,
        i = NULL,
        j = object$new_col,
        value = rxPredict(modelObject = object$model, data = newdata, verbose = 0)$Score)
  }
  newdata
}

