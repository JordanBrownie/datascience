#' Model metrics by evaluation type
#'
#' Provides various metrics to measure model performance
#' @param data A data.table
#' @param pred Character string of the column name containing evaluations.
#' @param value Character string of the column name containing target variable.
#' @param by Any valid `by` expression for a `data.table`. Defaults to providing
#' metrics by `eval_type`. To get metrics relying on non-simulated sales,
#' use `by = list(eval_type, is_real = data_type != 'simulated')`.
#'
#'
#' @export
metrics <- function(data, pred = "evaluation", value = "usd_sale_price", by = list(eval_type)) {
  by <- substitute(by)
  .value <- value
  .pred <- pred
  data[, .(weighted = dt_we(get(.pred), get(.value)),
           fleet = dt_fe(get(.pred), get(.value)),
           mean_absolute = dt_mae(get(.pred), get(.value)),
           median_absolute = dt_qae(get(.pred), get(.value), 0.5),
           absolute_05 = dt_qae(get(.pred), get(.value), 0.05),
           absolute_25 = dt_qae(get(.pred), get(.value), 0.25),
           absolute_75 = dt_qae(get(.pred), get(.value), 0.75),
           absolute_95 = dt_qae(get(.pred), get(.value),  0.95),
           evaluated = sum(!is.na(get(.pred))),
           total = length(get(.pred))),by = eval(by)]
}