
#' Bounds evaluations
#'
#' `step_bound_evaluations` creates a *specification* of a recipe step that will set an indicator for bad evaluations,
#' and add acceptable price ranges to aftersale evaluations.
#' @inheritParams step_basic
#' @param bounds Length 2 vector containing floor and ceiling.
#' @param percent Acceptable percent variation.
#' @param amount Acceptable dollar variation.
#' @inherit step_basic return
#' @export
#' @details
#'  Step: Nothing
#'  Prep: Nothing
#'  Bake: Calculates acceptable range for aftersale evaluations, sets an
#'   indicator for whether floor or ceiling was hit.
#'
#'  __One Model__
#'  Categories using only one model should provide bounds for aftersale evaluations,
#'  in which case they will be calculated from the `evaluation_aftersale` column.
#' @importFrom data.table set
step_bound_evaluations <- function(recipe,
                                   bounds,
                                   percent = NA,
                                   amount = NA,
                                   trained = FALSE) {
  add_step(recipe,
           step_bound_evaluations_new(
             trained = trained,
             bounds = bounds,
             percent = percent,
             amount = amount
           ))
}


step_bound_evaluations_new <- function(bounds, percent = NA, amount = NA,  trained = FALSE) {
  step(subclass = "bound_evaluations",
       bounds = bounds,
       percents = percent,
       amounts = amount,
       trained = trained)
}

prep.step_bound_evaluations <- function(x, training, ...) {
  step_bound_evaluations_new(trained = TRUE,
                         bounds = x$bounds,
                         percent = x$percent,
                         amount = x$amount)
}

bake.step_bound_evaluations <- function(object, newdata, ...) {
if ("evaluation" %chin% names(newdata) && !"evaluation_aftersale" %chin% names(newdata)) {
evals <- newdata[["evaluation"]]
} else {
  evals <- newdata[["evaluation_aftersale"]]
}
if (is.null(evals) && interactive()) {
  warning("No evaluation/evaluation_aftersale column found to bound. Please check",
          " your recipe.",
          call. = FALSE)
}

if (!is.na(object$percents) & !is.na(object$amounts)) {
  floor <- retail_floor()
  ceiling <- retail_ceiling()
  set(x = newdata,
      i = NULL,
      j = "lower_eval_bound",
      value = pmax(floor, pmin( evals * (1 - (object$percents/100)), evals - object$amounts)))
  set(x = newdata,
      i = NULL,
      j = "upper_eval_bound",
      value = pmin(ceiling, pmax(evals * (1 + (object$percents/100)), evals + object$amounts)))

}
above_upper <- which(evals > object$bounds[2])
below_lower <- which(evals < object$bounds[1])
set(x = newdata,
    i = NULL,
    j = "exceed_eval",
    value = NA_character_)
set(x = newdata,
    i = above_upper,
    j = "exceed_eval",
    value = "ceiling")
set(x = newdata,
    i = below_lower,
    j = "exceed_eval",
    value = "floor")
newdata
}

summary.step_bound_evaluations <- function(x, ...) {
  percent <- ifelse(is.na(x$percent), "Retail only", x$percent)
  amount <- ifelse(is.na(x$amount), "Retail only", x$amount)
  data.table(floor = x$bounds[1],
             ceiling = x$bounds[2],
             percent = percent,
             amount = amount)
}

