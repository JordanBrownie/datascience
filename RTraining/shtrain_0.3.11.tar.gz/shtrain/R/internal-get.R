# get from data ----------------------------------------------------------------

ind2bc <- function(x) {
  list('mat' = 4,
       'trk' = 27,
       'trl' = 28,
       'cnt' = 13,
       'tho' = 464)[[x]]
}
bc2ind <- function(x) {
df <- data.frame(ind = c("mat", "trk", "trl", "cnt", "tho"), bcat = c(4, 27, 28, 13, 464),
                 stringsAsFactors = FALSE)
df[df$bcat == x,]$ind
}
# This should not be used unless there is a reasonable expectation that
# `set_base_category_id` has not already been called.
#' @keywords internal
get_base_category_id <- function(category_id = NULL, data = NULL) {
  .cat <- category_id
  if (is.null(category_id) & is.null(data)) {
    # This should never happen - remove when it can be verified as safe.
    if (!is.null(shref$base_category_id)) {
    return(shref$base_category_id)
    }
  }
  if (is.null(category_id)) {
    if (!is.null(data) && "category_id" %in% names(data)) {
      .cat <- data$category_id[!is.na(data$category_id)][1]
    } else {
      .cat <- shref$category_id
    }
  }  else {
    .cat <- if (!is.character(category_id)) {
      category_id
    } else {
      ind2bc(category_id)
    }
  }
  base_category_id <-  unique(shdata$category_reference[shdata$category_reference$category_id %in% .cat,]$base_category_id)
  if (length(base_category_id) > 1) {
    stop("Category IDs do not correspond to same BaseCategoryID.")
  } else if (length(base_category_id) == 0) {
    base_category_id <- -999
    if (interactive()) {
      warning("Base category ID could not be determined for the data.", call. = TRUE)
    }
  }
  if (is.null(shref$base_category_id)) {
    shref$base_category_id
  }

  base_category_id
}

#' @keywords internal
get_industry <- function(category_id = NULL, data = NULL) {
  if (is.character(category_id) && nchar(category_id) == 3) {
    return(category_id)
  }
  .cat <- category_id
  if (is.null(category_id) && is.null(data) && !is.null(shref$industry)) {
    return(shref$industry)
  }
  if (!is.null(data) && "category_id" %in% names(data)) {
    .cat <- data$category_id[!is.na(data$category_id)][1]
  } else if (!is.null(data)) {

    return(shref$industry)
  }
  industry <- unique(shdata$category_reference[shdata$category_reference$category_id %in% .cat,]$industry)
  if (length(industry) > 1) {
    stop("Category IDs do not belong to same industry.")
  }
  if (is.null(shref$industry)) {
    set_industry(manual = industry)
  }
  industry
}

# This should not be used unless there is a reasonable expectation that
# `set_category_id` has not been set.
#' @keywords internal
get_category_id <- function(data) {
  if ("category_id" %in% names(data)) {
    if (is.null(shref$category_id)) {
    shref$category_id <- data$category_id[!is.na(data$category_id)][1]
    }
  unique(data$category_id[!is.na(data$category_id)])
  } else {
    shref$category_id
  }
}


# get from 'glm' model ---------------------------------------------------------
#' @keywords internal
get_response <- function(model) {
  if ('glm' %in% class(model) || (!is.null(names(model)) && "formula" %in% names(model))) {
    formula <- model$formula
  } else if (length(model) == 3) {
    response <- gsub("log\\(|\\)", "", as.character(model[[2]]))
    return(response)
  } else if (length(model) == 1 & is.character(model)) {
    response <- as.character(as.formula(model))[2]
    return(response)
  }
  if (inherits(model, "rpart")) {
    response <- model$terms[[2]]
  }
  # else nothing
  response <- all.vars(update.formula(formula, . ~ 1))
  response <- gsub("log\\(|\\)", "", response)
  return(response)
}

#' @importFrom stats update.formula
#' @keywords internal
 get_formula <- function(model) {
   if (is.character(model) || (any(class(model) == "formula"))) {
    formula <- model
   } else if ('glm' %in% class(model)) {
     formula <- model$formula
   } else{
     stop("The input model is not of a recognized type.")
   }
    formula
 }

# get from column name ---------------------------------------------------------
#' @keywords internal
get_spec_name <- function(group) {
  name <- vector("character", length = length(group))

  for (i in 1:length(group)) {
    if (group[i] == "age_group") {
      name[i] <- "age_at_sale"
    } else if (group[i] == "mm_group") {
      name[i] <- "make_model"
    } else {
      name[i] <- gsub("_group", "", group[i])
    }
  }
  name
}

#' @keywords internal
get_group_name <- function(spec) {
  name <- vector("character", length = length(spec))
  for (i in 1:length(spec)) {
    if (spec[i] == "age_at_sale") {
      name[i] <- "age_group"
    } else if (spec[i] == "make_model") {
      name[i] <- "mm_group"
    }  else {
      name[i] <- paste0(spec[i], "_group")
    }
  }
  name
}



# get from global environment --------------------------------------------------
#'
#' Get corresponding view name
#'
#' Takes a category ID (or industry abbreviation), type (asking, aftersale, auction,
#' dynamic, supplemental, default), and archive flag to construct the appropriate view
#' name
#' @param category_id A vector of category IDs or a single industry abbreviation.
#' @param type asking, aftersale, auction, dynamic, supplemental, default
#' @param archive `TRUE` or `FALSE`.
#'
get_table_name <- function(category_id, type, archive = FALSE) {
  if (!is.character(category_id)) {
    ind <-  get_industry(category_id = category_id)
  } else {
    ind <- category_id
  }
  if (type %in% c("auction", "aftersale", "asking")) {
   res <- paste0("vw_",ind,"_", type)

   if (archive == TRUE) {
   res <- paste0(res, "_archive")
   }
   res
  } else if (type %in% c("supplemental", "dynamic", "default")) {
    paste0("vw_", ind, type, "specs_", category_id)
  } else{
    stop('Invalid type.')
  }
}

#' @keywords internal
eval_type <- function(data) {
  unique(data$eval_type)
}