
step <- function(subclass, ..., prefix = "step_") {
  structure(list(...), class = sclass(prefix, subclass))
}

check <- function(subclass, ..., prefix = "check_") {
  structure(list(...), class = sclass(prefix, subclass))
}

filterat <- function(subclass, ..., prefix = "filter_") {
  structure(list(...), class = sclass(prefix, subclass))
}

validate <- function(subclass, ..., prefix = "validate_") {
  structure(list(...), class = sclass(prefix, subclass))
}

add <- function(subclass, ..., prefix = "add_") {
  structure(list(...), class = sclass(prefix, subclass))
}

mergeto <- function(subclass, ..., prefix = "merge_") {
  structure(list(...), class = sclass(prefix, subclass))
}

format <- function(subclass, ..., prefix = "format_") {
  structure(list(...), class = sclass(prefix, subclass))
}


#' documentation placeholder
#' @param recipe A recipe object. The step will be appended to the recipe.
#'  Steps occur in the order they are appended.
#' @param trained A logical to indicate if the step has been run through [prep()].
#' @return An updated version of `recipe` with the new step added.
step_basic <- function(recipe, trained) {

}


is_trained <- function(x) {
  x$trained
}

sclass <- function(prefix, sub) {
  c(paste0(prefix, sub), sub("_", "", prefix))
}


#' @export
#' @importFrom glue glue collapse
summary.step <- function(x, ...) {
  cat(glue("No `summary` method for a step with classes: {collapse(class(x))}."))
}

summary.filter <- function(x, ...) {
  cat(glue("No `summary` method for a filter with classes: {collapse(class(x))}."))
}

summary.check <- function(x, ...) {
  cat(glue("No `summary` method for a check with classes: {collapse(class(x))}."))
}

summary.validate <- function(x, ...) {
  cat(glue("No `summary` method for a validate step with classes: {collapse(class(x))}."))
}

summary.add <- function(x, ...) {
  cat(glue("No `summary` method for an add step with classes: {collapse(class(x))}."))
}

summary.merge <- function(x, ...) {
  cat(glue("No `summary` method for a merge step with classes: {collapse(class(x))}."))
}

summary.format <- function(x, ...) {
  cat(glue("No `summary` method for a format step with classes: {collapse(class(x))}."))
}

#' summary the steps in a recipe
#'
#' Loops through a recipe and applies [summary()] to each.
#' Results are returned in a list.
#' @export
summary_steps <- function(recipe, ...) {
  if (is.null(names(recipe$steps))) {
    names(recipe$steps) <- unlist(lapply(recipe$steps, function(x) class(x)[1]), recursive = FALSE, use.names = FALSE)
    names(recipe$steps) <- make.unique(names(recipe$steps), sep = "_")
  }
  tidied <- vector(mode = "list", length = length(recipe$steps))
  names(tidied) <- names(recipe$steps)
  for (k in seq_along(recipe$steps)) {
    tided[[k]] <- summary(recipe$steps[[k]])
  }
  tidied
}