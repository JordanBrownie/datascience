#' Adds a factor group based on numeric variable
#'
#' `add_continuous_group` will discretize each variable in a  list based on the
#' provided `cutoffs`. It is a simple wrapper around [cut()].
#' @inheritParams step_basic
#' @param cutoffs Named list of cutoffs of the form `list(spec = c(1, 2, 3, 4)), spec2...)`
#' @param labels A list of the same length as `cutoffs`, with each element having
#' one more element than the corresponding one in `cutoffs`.
#' @param new Names of new columns. Defaults to `paste0(names(cutoffs), "_group")`.
#' @inherit step_basic return
#' @export
#' @details
#' * Step: Performs checks on the validity of cutoffs and labels.
#' * Prep: Generates group name if not provided. Calls [cache_dependency()] to register variables.
#' * Bake: Adds `new` columns based on the cutoffs provided. New variables include the
#' right cutoff for the group.
#' @examples \dontrun{
#' dt <- data.table(x = 1:10, y = rnorm(10))
#' # Providing custom labels
#' recipe(dt) %>% add_continuous_group(cutoffs = list(x = 5), labels = list(c("at most 5", "greater than 5")))
#'  %>% trained()
#' # Multiple variables
#' recipe(dt) %>% add_continuous_group(cutoffs = list(x = c(3, 5), y = 0))
#'  %>% trained()
#' # Specifying a name for new variable
#' recipe(dt) %>% add_continuous_group(cutoffs = list(x = 5), new = "how_big")
#' %>% trained()
#' }
add_continuous_group <- function(recipe, cutoffs, labels = NULL, new = NA, trained = FALSE) {
  stopifnot(
    length(cutoffs) == length(labels) || is.null(labels),
    is.null(labels) ||
      (is.list(labels) &&
       all(lengths(cutoffs) + 1 == lengths(labels))),
    is.list(cutoffs)
  )
  add_step(recipe, add_continuous_group_new(
    cutoffs = cutoffs,
    labels = labels,
    new = new,
    trained = trained
  ))
}


add_continuous_group_new <- function(cutoffs, labels = NULL, new = NA, trained = FALSE) {
  add(subclass = "continuous_group",
       cutoffs = cutoffs,
       labels = labels,
       new = new,
       trained = trained)
}


prep.add_continuous_group <- function(x, training, ...) {
  if (all(is.na(x$new))) {
    new <- get_group_name(names(x$cutoffs))
  } else {
    new <- x$new
  }
  cache_dependency(source = names(x$cutoffs), derived = new)
add_continuous_group_new(cutoffs = x$cutoffs,
                          labels = x$labels,
                          new = new,
                          trained = TRUE)
}

bake.add_continuous_group <- function(object, newdata, ...) {
  name <- names(object$cutoffs)
  group_name <- object$new
  cutoffs <- object$cutoffs
  if (length(missing_vars <- setdiff(names(object$cutoffs), names(newdata)))) {
    stop("Missing variables to be discretized:", str_c(missing_vars, collapse = ","),
         call. = FALSE)
  }
  for (i in seq_along(cutoffs)) {
    set(
      x = newdata,
      i = NULL,
      j = group_name[i],
      value = as.character(cut(
        x = newdata[[name[i]]],
        breaks = c(-Inf, cutoffs[[i]], Inf),
        labels = object$labels[[i]],
        dig.lab = 15
      ))
    )

    set(
      x = newdata,
      i = NULL,
      j = group_name[i],
      value = str_replace_all(newdata[[group_name[i]]], "\\sInf\\]", "Inf\\)")
    )
  }
  newdata
}

summary.add_continuous_group <- function(x, ...) {
  n_cols <- max(lengths(x$cutoffs))
  groups <- paste0("group_", seq_along(n_cols), "_max")
  for (k in seq_along(n_cols)) {
    length(x$cutoffs[[k]]) <- n_cols
  }
  dt <- data.table(source = names(x$cutoffs),
             derived = x$new)
  dt[, (groups) := x$cutoffs]
  dt
}

#' @describeIn add_continuous_group Non-recipe version.
#' @include internal-get.R
#' @export
.add_continuous_group <- function(data, nl_cutoffs = NULL, nl_labels = NULL) {
  stopifnot(is.data.table(data),
            length(nl_cutoffs) == length(nl_labels) ||
              is.null(nl_labels) || is.list(nl_labels),
            is.list(nl_cutoffs))
  if (!is.null(nl_labels) && names(nl_labels) != names(nl_cutoffs)) {
    stop("Your label vector names do not match your cutoff vector names.")
  }
  data <- copy(data)
  name <- names(nl_cutoffs)
  group_name <- get_group_name(name)

  for (i in seq_along(nl_cutoffs)) {
    set(
      x = data,
      i = NULL,
      j = group_name[i],
      value = as.character(cut(
        x = data[[name[i]]],
        breaks = c(-Inf, nl_cutoffs[[i]], Inf),
        labels = nl_labels[[i]],
        dig.lab = 15
      ))
    )

    set(
      x = data,
      i = NULL,
      j = group_name[i],
      value = str_replace_all(data[[group_name[i]]], "\\sInf\\]", "Inf\\)")
    )
  }
  data
}

