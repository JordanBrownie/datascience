
#' Alternative to NULL values
#'
#' In-fix operator to provide default
#' value if the value provided is `NULL`.
#'
#' @param x The possibly `NULL` variable.
#' @param y The replacement value to use if `is.null(x)`.
#' @rdname null_else
#' @name  null_else
#' @export
#' @examples
#' x <- NULL
#' y <- 35
#' z <- x %||% y
#' z
`%||%` <- function(x, y) {
  if (is.null(x)) {
    y
  } else {
    x
  }
}

#' Identifies replacement specs
#'
#' Identifies pairings of base and extended specs based on the provided prefix;
#' def_, sup_, or imp_.
#' @param names The vector of data names.
#' @param prefix 'sup_', 'def_', or 'imp_'
#' @return A named vector. The names correspond to the base spec, and the
#' elements are the matching extended spec.
find_replacement <- function(names, prefix) {
  stopifnot(length(prefix) == 1)
  base <- no_prefix(names, prefix)
  prefixed <- has_prefix(names, prefix)
  names(names)[prefixed] <- rm_prefix(names[prefixed], prefix)
  final <- names[prefixed][intersect(names(names), names[base])]
  final

}
#' Determine whether a column is prefixed
#'
#' Determines whether a column starts with a pre-defined prefix --
#' def_, sup_, or imp_
#' @param names character vector of names.
#' @return Integer vector corresponding to indices of names with no prefix.
#' @importFrom stringr str_which
no_prefix <- function(names, prefix) {
  which(!startsWith(names, prefix))
}

#' Strips away the specified prefix
#'
#' @param names A character vector.
#' @param prefix A single prefix.
#' @return `names` with `prefix` removed from the front.
#' @importFrom stringr str_replace_all
rm_prefix <- function(names, prefix) {
  str_replace_all(names, prefix, "")
}
#' Determine whether a column has a specific prefix
#'
#' @param names A character vector of names.
#' @param prefix A single prefix.
#' @return Integer vector corresponding to indices of names which have the specified
#' prefix.
#' @importFrom stringr str_which
has_prefix <- function(names, prefix) {
  str_which(names, prefix)
}






#' Changes the response variable given a formula
#' @export
#' @importFrom stats update.formula
update_response <- function(formula, response) {
  paste0(response,"~", update.formula(formula, .~.)[3])
}

#' Continuous groups formula representation
#'
#' From a named list of cutoff values, generate a
#' string that represents the continuous groups
#' within a formula.
#' @param x A named list, such as `list(age = c(1, 4, 8))`
#' @return A string to be pasted into a formula.
#' @export
#'
piece_formula <- function(x) {
  names <- names(x)
  pieces <- list()
  for (i in 1:length(x)) {
    formulaSign <- rep("-", length(x[[i]]))
    formulaSign[x[[i]] < 0] <- "+"
    pieces[[i]] <- paste0(names[i], "+", paste0("I(pmax(",
                                                names[[i]], formulaSign, abs(x[[i]]), ", 0))",
                                                collapse = "+"))
  }
  if (length(x) > 1) {
    for (i in 2:length(x)) {
      pieces[[1]] <- paste(pieces[[1]], pieces[[i]], sep = "+")
    }
  }
  return(pieces[[1]])
}




check_row_id <-
  function(data,
           unique = TRUE,
           name = "row_id",
           fn) {
    if (!is.data.table(data)) {
      stop("`data` must be a data.table.", call. = FALSE)
    }
    if (!name %in% names(data)) {
      warning(
        "Adding \"",
        name,
        "\" column to data by reference to complete operation. ",
        "Add logic to create this column before this function, e.g., ",
        "`data[,row_id := .I]"
      )
    }
    if (unique && anyDuplicated(data, by = name)) {
      stop("Function \"", fn, "\" requires that the `row_id` be unique.")
    }
    if (anyNA(data[[name]])) {
      stop("No missing values allowed in a row_id.", call. = FALSE)
    }
  }
