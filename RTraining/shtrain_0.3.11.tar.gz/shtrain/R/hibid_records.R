
#' Creates a .csv report of HiBid "asking" records
#'
#' Queries dbShared.dbo.ProviderMap to find all HiBid records which exist in
#' dbMachinery "asking" data. Creates a report containing the ObjectHistoryID
#' (oh_id) for these records. These reports will be used in [remove_hibid_records()].
#'
#' @return Reports containing only "oh_id" are written to the appropriate
#' directory, based on the current environment.
#'
#' @family hibid records
#' @export
#' @include odbc.R
create_hibid_report <- function() {

  con <- create_odbc_connection()
  on.exit(odbc::dbDisconnect(con))

  hibid_oh_ids <- setDT(
    odbc::dbGetQuery(
      con,
      "SELECT OH.ObjectHistoryID as oh_id
      FROM dbShared.dbo.ProviderMap PM(NOLOCK)
      INNER JOIN dbShared.dbo.MapType MT(NOLOCK) ON MT.MapTypeID = PM.MapTypeID
      INNER JOIN dbMachinery.dbo.ObjectHistory OH(NOLOCK) ON OH.ObjectHistoryID = PM.LocalValue
      WHERE 1=1
      AND PM.ProviderID = 13
      AND MT.MapType = 'Listing Redirect';"
    )
  )

  setkey(hibid_oh_ids, oh_id)

  file_path <-
    file.path(
      stringr::str_extract(command_arguments()$base_dir, ".*/file/DataScience(/Lab)?"),
      "PreImportScripts/hibid_record_removal/hibid_record_reports"
    )
  dir.create(file_path, showWarnings = FALSE)
  final_path <- file.path(file_path, glue::glue("{Sys.Date()}_hibid_report.csv"))
  fwrite(hibid_oh_ids, final_path)
  if (file.exists(final_path) == FALSE) {
    stop(glue::glue("{final_path} was not successfully written by `create_hibid_report()`."), call. = FALSE)
  }
  read_data <- fread(final_path, na.strings = "", showProgress = FALSE)
  setkey(read_data, oh_id)
  if (fsetequal(hibid_oh_ids, read_data) == FALSE) {
    stop(glue::glue("Data from {final_path} does not match original data prior to file write."))
  }

}



#' Reads and formats a .csv HiBid record report for the given date
#'
#' Checks hat a HiBid record report matching the given date exists. If the .csv
#' file exists, it reads the file in for use.
#'
#' @param date a character string supplying a certain date to match in the .csv
#' file name. Should be supplied in the form "YYYY-MM-DD". Defaults to the current
#' date using [Sys.Date()].
#' @return Data table of HiBid records containing only "oh_id".
#' See __Details__.
#'
#' @details
#'
#' Returns data formatted as if it were being used within [remove_hibid_records()].
#'
#'
#' @family hibid records
#' @export
read_hibid_report <- function(date = Sys.Date()) {

  file_path <-
    file.path(
      stringr::str_extract(command_arguments()$base_dir, ".*/file/DataScience(/Lab)?"),
      "PreImportScripts/hibid_record_removal/hibid_record_reports",
      glue::glue("{date}_hibid_report.csv")
    )

  if (file.exists(file_path) == FALSE) {
    stop(glue::glue("{file_path} does not exist."), call. = FALSE)
  }
  report <- fread(file_path, na.string = "", showProgress = FALSE)
  report

}



#' Removes HiBid "asking" records from data
#'
#' Removes HiBid records incorrectly stored in dbMachinery "asking" data
#' by comparing ObjectHistoryIDs (oh_id) between the data supplied and
#' the appropriate HiBid record report.
#'
#' @param data Category data potentially containing HiBid records.
#' @return Subset of the original data, with rows identified as HiBid
#' records removed.
#' See __Details__.
#'
#' @details
#'
#' This function is called within [get_data()] in order to remove HiBid
#' records before the category data is returned to the user.
#'
#' Using the appropriate HiBid record report created by [create_hibid_report()],
#' rows are removed based on the `oh_id` field. If a row is the data has an
#' `oh_id` found in the HiBid record report, that row is removed before returning
#' the data to the user.
#'
#' @family hibid records
#' @export
remove_hibid_records <- function(data) {
  report <- read_hibid_report()
  newdata <- data[!oh_id %in% report$oh_id]
  count <- data[,.N] - newdata[,.N]
  name <-
    dplyr::if_else(
      unique(newdata$archive) == TRUE,
      stringr::str_c("archive", unique(newdata$data_type), sep = " "),
      unique(newdata$data_type)
    )
  if (interactive() || getOption("shtrain.verbose", FALSE)) {
    message(
      glue::glue(
        "{count} HiBid records removed from {name} data.\n"
      )
    )
  }

  newdata

}
