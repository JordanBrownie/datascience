#' Add imputed spec values``
#'
#' `add_imputations` creates a *specification* of a recipe step that will
#'   add imputed values by `by` for each of `specs` using `method`.
#' @inheritParams step_basic
#' @param specs Vector of spec names.
#' @param by column name as a character by which to impute.
#' @param options named list to pass for `method` 'ratio'. See details.
#' @param ref_imputed Generated automatically.
#' @inherit step_basic return
#' @export
#' @seealso step_replace step_replace_na
#' @details
#' * Step: Nothing.
#' * Prep: Generate table containing imputed `specs` values by `by`.
#' * Bake: Left join to `step$ref_imputed.`
add_imputations <- function(recipe, specs, by, ref_imputed = NULL, method = "mode", options = NULL, trained = FALSE) {
  add_step(recipe,
           add_imputations_new(
             specs = specs,
             by = by,
             ref_imputed = ref_imputed,
             method = method,
             options = options,
             trained = trained
           ))
}

add_imputations_new <- function(specs, by, ref_imputed = NULL, method = "mode", options = NULL, trained = FALSE) {
  add(subclass = "imputations",
      specs = specs,
      by = by,
      ref_imputed = ref_imputed,
      method = method,
      options = options,
      trained = trained)
}

#' @importFrom data.table copy
prep.add_imputations <- function(x, training, ...) {
  if (x$method == "mode") {
  dt <- copy(training)
  imp_specs <- paste0("imp_", x$specs)
  types <- vapply(dt[, x$specs, with = FALSE], typeof, character(1L), USE.NAMES  = FALSE)
  na_types <- list(double = NA_real_, character = NA_character_, logical = NA)
  values <- na_types[match(types, names(na_types))]
  for (k in seq_along(x$specs)) {
    set(x = dt,
        i = NULL,
        j = imp_specs[k],
        value = values[[k]])
  }

  dt[,(imp_specs) := lapply(.SD, function(x) {if (.N > 0) get_mode(x) else NA}), by = eval(x$by),
     .SDcols = x$specs]

  cols <- c(x$by, imp_specs)
  ref <- unique(dt[, cols, with = FALSE], by = x$by)
  } else if (x$method == "ratio") {

  } else {stop("Please provide a valid `mode` to `step_add_imputations`.", call. = FALSE)}
  add_imputations_new(specs = x$specs,
                        by = x$by,
                        ref_imputed = ref,
                        method = x$method,
                        options = x$options,
                        trained = TRUE)
}

bake.add_imputations <- function(object, newdata, ...) {
  results <- merge(newdata, object$ref_imputed, all.x = TRUE, by = object$by)
  results
}

summary.add_imputations <- function(x, ...) {
  if (is_trained(x)) {
    x$ref
  } else {
    dt <- data.table(impute = x$specs,
                     by = x$by,
                     method = x$method)
    dt
  }
}
#' @export
get_mode <- function(x) {
  UseMethod("get_mode", x)
}
#' @export
get_mode.character <- function(x) {
  if (sum(!is.na(x)) > 0) {
    return(rownames(table(x))[which.max(table(x))])
  } else {
    return(NA_character_)
  }
}
#' @export
get_mode.numeric <- function(x) {
  x <- x[!is.na(x)]
  if (length(x) == 0) {
    return(NA_real_)
  }
  ux <- unique(x)
  ux[which.max(table(match(x, ux)))]
}
#' @export
get_mode.logical <- function(x) {
  stop("Your column is completely empty. please remove from `add_imputations`.")
}
#' @export
get_mode.factor <- function(x) {
  x <- x[!is.na(x)]
  if (length(x) == 0) {
    return(NA_real_)
  }
  ux <- unique(x)
  ux[which.max(table(match(x, ux)))]
}