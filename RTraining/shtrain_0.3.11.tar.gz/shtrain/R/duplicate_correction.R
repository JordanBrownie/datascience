
#' Retrieves and formats provider data for use in creating duplicate reports
#'
#' Opens the connection, queries DataExchange.vw_Provider_ListingLookup, and
#' performs the proper formatting to produce the information necessary for
#' [create_duplicate_report()] to work properly.
#'
#' @return Data containing "ds_lookup_id", "provider_id", "provider_listing_id".
#' See __Details__.
#'
#' @details
#'
#' Excludes ProviderID = 1 (DealerServices).
#'
#' Performs the following Provider mappings: CGT (20) to CAT (5),
#' DIS (43) to DIS API (85), and Locator (73) to Locator2 (80).
#'
#' Check that all DSLookupIDs belong to only one ProviderID.
#'
#' If a single DSLookupID is tied to multiple ProviderListingIDs, a new
#' 'custom' ProviderID is created to tie all relevant record together.
#'
#'
#'
#' @family duplicate correction
#' @export
#' @include odbc.R
create_provider_info <- function() {
  con <- create_odbc_connection()
  on.exit(odbc::dbDisconnect(con))
  pl_ids <- setDT(odbc::dbGetQuery(con, "SELECT DSLookupID, ProviderListingID, ProviderID FROM DataExchange.vw_Provider_ListingLookup;"))
  setnames(pl_ids, c("ds_lookup_id", "provider_listing_id", "provider_id"))
  pl_ids <- pl_ids[provider_id != 1
                   ][provider_id == 20, provider_id := 5
                     ][provider_id == 43, provider_id := 85
                       ][provider_id == 73, provider_id := 80]
  ### double check that all ds_lookup_ids belong to only 1 provider_id
  if (nrow(pl_ids[, .N, list(ds_lookup_id, provider_id)]) != uniqueN(pl_ids$ds_lookup_id))
    stop("At least one DSLookupID exists for multiple ProviderIDs.")
  ### identify odd-ball situations where ds_lookup_id exists for multiple provider_listing_ids
  pl_ids[, provider_id_listing_id := stringr::str_c(provider_id, provider_listing_id, sep = "_")]
  dupe_ds <- pl_ids[, .N, ds_lookup_id][N > 1]
  dupe_pl <- pl_ids[ds_lookup_id %in% dupe_ds$ds_lookup_id]
  dupe_ds2 <- pl_ids[provider_id_listing_id %in% unique(dupe_pl$provider_id_listing_id)]
  dupe_pl2 <- pl_ids[ds_lookup_id %in% unique(dupe_ds2$ds_lookup_id)]
  ### loop through and look for matches on ds_lookup_id OR provider_listing_id
  setkey(dupe_pl2, ds_lookup_id, provider_listing_id)
  value <- 1
  dupe_pl2[1, third_id := value]
  repeat {
    repeat {
      num_max_third1 <- dupe_pl2[third_id == value, .N]
      dsid <- dupe_pl2[third_id == value, ds_lookup_id]
      plid <- dupe_pl2[third_id == value, provider_listing_id]
      pid <- unique(dupe_pl2[third_id == value, provider_id])
      dupe_pl2[ds_lookup_id %in% dsid | (provider_listing_id %in% plid & provider_id == pid), third_id := value]
      num_max_third2 <- dupe_pl2[third_id == value, .N]
      if (num_max_third1 == num_max_third2) {
        break
      }
    }
    value <- value + 1
    dupe_pl2 <- dupe_pl2[order(third_id)]
    start_row <- dupe_pl2[, .N, is.na(third_id)][is.na == FALSE, N] + 1
    if (start_row == dupe_pl2[, .N] + 1) {
      break
    }
    dupe_pl2[start_row, third_id := value]
  }
  custom_ids <- unique(dupe_pl2[,third_id := stringr::str_c("custom_", third_id)][,c("ds_lookup_id", "third_id", "provider_id")])
  pl_ids[,provider_id_listing_id := NULL]
  provider_info <- unique(custom_ids[pl_ids, on = .(ds_lookup_id, provider_id)
                                     ][!is.na(third_id), provider_listing_id := third_id
                                       ][,third_id := NULL])
}



#' **DEPRECATED** Do not use this function. Please use `update_duplicate_table()`.
#' Creates a .csv report on duplicate listings for given industries
#'
#' Opens the connection and queries all asking data for the supplied industries
#' using dbDataScientist.dbo.Pr_GetAskingDataFor{industry}. Analyzes ProviderID
#' DSLookupID, and WebEndDate to determine which rows to mark to keep, and which
#' rows to mark for removal. These reports will be used in [correct_duplicates()].
#'
#' @param industry a character vector of lower-cased industry abbreviations.
#' Specifies which industries the new reports should be generated for. If NULL,
#' reports will be generated for all industries: 'mat', 'tho', 'trk', 'trl', 'cnt'.
#' @return Reports containing "oh_id, "web_start_date_updated", and "row_action"
#' are written to the appropriate directory, based on the current environment.
#' See __Details__.
#'
#' @details
#'
#' For each industry supplied, a duplicate report .csv will be generated, and
#' saved in the appropriate PreImportScripts/duplicate_record_reports/duplicate_reports
#' directory based on the current environment. Each report will be named with the
#' current date and the industry (Ex. 2019-01-01_duplicate_report_mat.csv).
#'
#' Any ObjectHistoryID which is tied to a duplicate DSLookupID or ProviderListingID
#' will be marked with a `row_action` of either `keep` or `remove`. The row with the
#' greatest WebEndDate will be marked as `keep`, while all other rows with matching
#' DSLookupIDs or ProviderListingIDs will be marked as `remove`.
#'
#' Any rows marked `keep` will also have `web_start_date_updated` filled in. This is
#' defined as the least WebStartDate from all of the corresponding duplciates marked
#' `remove`.
#'
#' If any DSLookupID and ProviderListingID tied to an ObjectHistoryID is unique
#' (not duplicated), then `row_action` and `web_start_date_updated` will both
#' remain NA, and these rows will not be affected in the duplicate correction.
#'
#' After creating the appropriate reports, this function also confirms that
#' the new report .csv files exist, and that they contain the expected data.
#'
#'
#'
#' @family duplicate correction
#' @export
#' @include odbc.R
create_duplicate_report <- function(industry = NULL) {
  ind <- industry
  if (is.null(ind)) {
    ind <- c("mat", "tho", "trk", "trl", "cnt")
  }
  if (!all(ind %in% c("mat", "tho", "trk", "trl", "cnt"))) {
    stop("`industry` vector supplied can only contain the following: 'mat', 'tho', 'trk', 'trl', 'cnt'.")
  }
  provider_info <- create_provider_info()
  con <- create_odbc_connection()
  on.exit(odbc::dbDisconnect(con))
  invisible({
    data.table(industry = ind)[,{
      ### sps for getting all industry asking data
      all_industry_data <- shtrain:::execute_sp(name = stringr::str_c("dbDataScientist.dbo.Pr_GetAskingDataFor", toupper(.BY$industry), sep = ""), con = con)
      if (.BY$industry == "cnt") {
        all_industry_data <- all_industry_data[,list(ds_lookup_id = DSInventoryLookupID, oh_id = ObjectHistoryID, base_category_id = BaseCategoryID,
                                                     category_id = ObjectCategoryID, web_start_date = WebStartDate, web_end_date = WebEndDate,
                                                     sub_event_type = SubEventType, creation_date = CreationDateTime, entry_date = EntryDateTime)]
      } else {
        all_industry_data <- all_industry_data[,list(ds_lookup_id = DSInventoryLookupID, oh_id = ObjectHistoryID, base_category_id = BaseCategoryID,
                                                     category_id = ObjectCategoryID, web_start_date = WebStartDate, web_end_date = WebEndDate,
                                                     creation_date = CreationDateTime, entry_date = EntryDateTime)]
      }
      all_industry_data[web_start_date < "2008-01-01", web_start_date := creation_date
                        ][,`:=`(creation_date = NULL, entry_date = NULL)]
      ### Using provider_listing_id, determine whether to 'keep' (and update) or 'remove' each row by OHID
      ### Need to group by both provider_id and provider_listing_id
      pl_id_fix <- merge(all_industry_data, provider_info, by = "ds_lookup_id", all.x = TRUE)
      pl_id_fix <- pl_id_fix[!is.na(provider_listing_id)
                             ][,pl_id_count := .N, by = list(provider_id, provider_listing_id)
                               ][pl_id_count > 1]
      setorder(pl_id_fix, provider_id, provider_listing_id, -web_end_date)
      if (.BY$industry == "cnt" && pl_id_fix[,.N] == 0) {
        pl_id_fix <- data.table(oh_id = as.integer(NA), base_category_id = as.integer(NA), web_start_date_new_pl = as.POSIXct(NA), row_action_pl = NA_character_)
      }else{
        pl_id_fix[,`:=`(max_date = max(web_end_date), min_date = min(web_start_date)), by = list(provider_id, provider_listing_id)
                  ][web_end_date == max_date, `:=`(row_action_pl = "keep", web_start_date_new_pl = min_date)
                    ][is.na(row_action_pl), row_action_pl := "remove"
                      ][,pl_end_date_count := .N, by = list(provider_id, provider_listing_id, web_end_date)
                        ][,max_oh_id := max(oh_id, na.rm = TRUE), by = list(provider_id, provider_listing_id, pl_end_date_count)
                          ][pl_end_date_count > 1 & oh_id != max_oh_id, `:=`(row_action_pl = "remove", web_start_date_new_pl = NA)]
        pl_id_fix <- pl_id_fix[,c("oh_id", "base_category_id", "web_start_date_new_pl", "row_action_pl")]
      }
      ### Using the table created above, update or remove all possible rows by oh_id
      all_industry_data2 <- merge(all_industry_data, pl_id_fix, by = c("oh_id", "base_category_id"), all.x = TRUE)
      all_industry_data2 <- all_industry_data2[is.na(row_action_pl) | row_action_pl == "keep"
                                               ][row_action_pl == "keep", web_start_date := web_start_date_new_pl
                                                 ][,-c("web_start_date_new_pl", "row_action_pl")]
      ### Using the updated data, determine whether to update or remove the remaining data using ds_lookup_id
      ds_id_fix <- copy(all_industry_data2)[ds_lookup_id %between% c(150000000000, 159999999999), ds_id_count := .N, by = ds_lookup_id][ds_id_count > 1]
      setorder(ds_id_fix, ds_lookup_id, -web_end_date)
      ds_id_fix[,`:=`(max_date = max(web_end_date), min_date = min(web_start_date)), by = ds_lookup_id
                ][web_end_date == max_date, `:=`(row_action_ds = "keep", web_start_date_new_ds = min_date)
                  ][is.na(row_action_ds), row_action_ds := "remove"
                    ][,ds_end_date_count := .N, by = list(ds_lookup_id, web_end_date)
                      ][,max_oh_id := max(oh_id, na.rm = TRUE), by = list(ds_lookup_id, ds_end_date_count)
                        ][ds_end_date_count > 1 & oh_id != max_oh_id, `:=`(row_action_ds = "remove", web_start_date_new_ds = NA)]
      ds_id_fix <- ds_id_fix[,c("oh_id", "base_category_id", "web_start_date_new_ds", "row_action_ds")]
      ### Combine the two tables determining 'row_action' (by provider_listing_id and ds_lookup_id)
      master_fix <- merge(ds_id_fix, pl_id_fix, by = c("oh_id", "base_category_id"), all = TRUE)
      master_fix[,`:=`(web_start_date_updated = web_start_date_new_ds, row_action = row_action_ds)
                 ][!is.na(web_start_date_new_pl), web_start_date_updated := web_start_date_new_pl
                   ][!is.na(row_action_pl), row_action := row_action_pl]
      master_fix <- master_fix[,c("oh_id", "web_start_date_updated", "row_action")
                               ][!is.na(oh_id)]
      setkey(master_fix, oh_id)
      file_path <- file.path(stringr::str_extract(command_arguments()$base_dir, ".*/file/DataScience(/Lab)?"),
                             "PreImportScripts/duplicate_record_reports/duplicate_reports")
      dir.create(file_path, showWarnings = FALSE)
      final_path <- file.path(file_path, glue::glue("{Sys.Date()}_duplicate_report_{.BY$industry}.csv"))
      fwrite(master_fix, final_path)
      if (file.exists(final_path) == FALSE) {
        stop(glue::glue("{final_path} was not successfully written by `create_duplicate_report()`."), call. = FALSE)
      }
      read_data <- fread(final_path, na.strings = "", showProgress = FALSE)
      read_data[,web_start_date_updated := as.Date(web_start_date_updated, tz = "America/Chicago")]
      setkey(read_data, oh_id)
      read_data2 <- master_fix[,web_start_date_updated := as.Date(web_start_date_updated)]
      if (fsetequal(read_data, read_data2) == FALSE) {
        stop(glue::glue("data from {final_path} does not match original data prior to file write."))
      }
    }, by = industry]
  })
}


#' **DEPRECATED** Do not use this function. Please use `get_duplicate_listing_records()`.
#' Reads and formats a .csv duplicate report for the given date and industry
#'
#' Checks the industry supplied is a valid industry, and that a duplicate report
#' matching the given date and industry exists. If the .csv file exists, it reads
#' the file in and formats the date to POSIXct.
#'
#' @param industry a lower-cased character string industry abbreviation. Valid
#' industry entries are: "mat", "tho", "trk", "trl", "cnt".
#' @param date a character string supplying a certain date to match in the .csv
#' file name. Should be supplied in the form "YYYY-MM-DD". Defaults to the current
#' date using [Sys.Date()].
#' @return Data table containing "oh_id, "web_start_date_updated", and "row_action".
#' See __Details__.
#'
#' @details
#'
#' Returns data formatted as if it were being used within [correct_duplicates()].
#'
#'
#' @family duplicate correction
#' @export
read_duplicate_report <- function(industry, date = Sys.Date()) {
  if (!industry %in% c("mat", "tho", "trk", "trl", "cnt")) {
    stop("`industry` must be one of the following: 'mat', 'tho', 'trk', 'trl', 'cnt'.")
  }
  file_path <- file.path(stringr::str_extract(command_arguments()$base_dir, ".*/file/DataScience(/Lab)?"),
                         "PreImportScripts/duplicate_record_reports/duplicate_reports",
                         glue::glue("{date}_duplicate_report_{industry}.csv"))
  if (file.exists(file_path) == FALSE) {
    stop(glue::glue("{file_path} does not exist."), call. = FALSE)
  }
  report <- fread(file_path, na.string = "", showProgress = FALSE)
  report[,web_start_date_updated := as.POSIXct(web_start_date_updated)]
  report
}




#' **DEPRECATED** Do not use this function. Please use `correct_duplicate_listings()`.
#' Removes or updates duplicate asking records
#'
#' Identifies which duplicate report to read in based on industry and date in
#' the file name. Merges this report to the category data by `oh_id`, and
#' performs the appropirate updates/removals as supplied in the `row_action`
#' and `web_start_date_updated` fields.
#'
#' @param data Category data containing possible duplicate data.
#' @return Subset of the original data, with rows identified as duplicates
#' removed, and WebEndDates updated if necessary.
#' See __Details__.
#'
#' @details
#'
#' This function is called within [get_data()] in order to remove duplicate
#' records before the category data is returned to the user.
#'
#' Using the duplciate reports created by [create_duplicate_report()], rows
#' are updated or removed based on the `row_action` field. If a row is marked
#' as `remove`, that row is removed from the data returned. If a row is marked
#' as `keep`, the row is kept, and the WebStartDate is updated using the
#' `web_start_date_updated` field. If no `row_action` is supplied (`row_action`
#' is NA), that row is left as-is when returned.
#'
#'
#'
#' @family duplicate correction
#' @export
correct_duplicates <- function(data) {
  ind <- shtrain:::get_industry(data = data)
  report <- read_duplicate_report(industry = ind, date = Sys.Date())
  newdata <- merge(data, report, by = "oh_id", all.x = TRUE)
  counts <- newdata[, .N, row_action]
  name <-
    dplyr::if_else(
      unique(newdata$archive) == TRUE,
      stringr::str_c("archive", unique(newdata$data_type), sep = " "),
      unique(newdata$data_type)
    )
  if (interactive() || getOption("shtrain.verbose", FALSE)) {
    message(
      glue::glue(
        "{counts[row_action == 'remove', N]} duplicate rows removed from {name} data.\n{counts[row_action == 'keep', N]} {name} rows received updated WebStartDate.\n"
      )
    )
  }
  newdata <- newdata[is.na(row_action) | row_action == "keep"
                     ][row_action == "keep", web_start_date := web_start_date_updated
                       ][,`:=`(row_action = NULL, web_start_date_updated = NULL)]
  newdata

}



#' Identifies duplicate listing records to be updated for given BaseCategoryIDs
#'
#' Opens the connection and queries all asking data for the supplied industries
#' using dbDataScientist.dbo.Pr_GetAskingDataFor{industry}. Analyzes ProviderID
#' DSLookupID, and WebEndDate to determine which rows should be kept, with an
#' updated WebStartDate, and which rows should be removed. This "report" is then
#' compared to the contents of `dbo.DuplicateListingRecord`. The
#' difference between these datasets is POSTed, allowing code to handle updating
#' the records in `dbo.DuplicateListingRecord` and `dbo.DuplicateListingRecordArchive`.
#' This data will be used in [correct_duplicate_listings()].
#'
#' @param base_category_id a numeric vector of BaseCategoryIDs. Specifies which
#' industries should receive updated duplicate listing records. If NULL, records
#' will be updated for all BaseCategoryIDs: 4, 464, 27, 28, 13.
#'
#' @details
#'
#' For each BaseCategoryID supplied, a duplicate "report" is created internally and
#' used to identify which duplicate listing records in `dbo.DuplicateListingRecord`
#' need to be updated.
#'
#'
#' @family duplicate correction
#' @export
#' @include odbc.R
update_duplicate_table <- function(base_category_id = NULL) {
  base_cat <- base_category_id
  if (is.null(base_cat)) {
    base_cat <- c(4, 464, 27, 28, 13)
  }
  if (!all(base_cat %in% c(4, 464, 27, 28, 13))) {
    stop("`base_category_id` vector supplied can only contain the following BaseCategoryIDs: 4, 464, 27, 28, 13.")
  }
  ind <- vector(mode = "character", length = length(base_cat))
  for (j in seq_along(ind)) {
    ind[j] <- shtrain:::get_industry(base_cat[j])
  }
  provider_info <- create_provider_info()
  con <- create_odbc_connection()
  on.exit(odbc::dbDisconnect(con))
  dupe_env <- environment()
  invisible({
    data.table(industry = ind)[,{
      ### sps for getting all industry asking data
      all_industry_data <- shtrain:::execute_sp(name = stringr::str_c("dbDataScientist.dbo.Pr_GetAskingDataFor", toupper(.BY$industry), sep = ""), con = con)
      if (.BY$industry == "cnt") {
        all_industry_data <- all_industry_data[,list(ds_lookup_id = DSInventoryLookupID, oh_id = ObjectHistoryID, base_category_id = BaseCategoryID,
                                                     category_id = ObjectCategoryID, web_start_date = WebStartDate, web_end_date = WebEndDate,
                                                     sub_event_type = SubEventType, creation_date = CreationDateTime, entry_date = EntryDateTime)]
      } else {
        all_industry_data <- all_industry_data[,list(ds_lookup_id = DSInventoryLookupID, oh_id = ObjectHistoryID, base_category_id = BaseCategoryID,
                                                     category_id = ObjectCategoryID, web_start_date = WebStartDate, web_end_date = WebEndDate,
                                                     creation_date = CreationDateTime, entry_date = EntryDateTime)]
      }
      all_industry_data[web_start_date < "2008-01-01", web_start_date := creation_date
                        ][,`:=`(creation_date = NULL, entry_date = NULL)]
      ### Using provider_listing_id, determine whether to 'keep' (and update) or 'remove' each row by OHID
      ### Need to group by both provider_id and provider_listing_id
      pl_id_report <- merge(all_industry_data, provider_info, by = "ds_lookup_id", all.x = TRUE)
      pl_id_report <- pl_id_report[!is.na(provider_listing_id)
                             ][,pl_id_count := .N, by = list(provider_id, provider_listing_id)
                               ][pl_id_count > 1]
      setorder(pl_id_report, provider_id, provider_listing_id, -web_end_date)
      if (.BY$industry == "cnt" && pl_id_report[,.N] == 0) {
        pl_id_report <- data.table(oh_id = as.integer(NA), base_category_id = as.integer(NA), web_start_date_new_pl = as.POSIXct(NA), row_action_pl = NA_character_)
      }else{
        pl_id_report[,`:=`(max_date = max(web_end_date), min_date = min(web_start_date)), by = list(provider_id, provider_listing_id)
                     ][web_end_date == max_date, `:=`(row_action_pl = "keep", web_start_date_new_pl = min_date)
                       ][is.na(row_action_pl), row_action_pl := "remove"
                         ][,pl_end_date_count := .N, by = list(provider_id, provider_listing_id, web_end_date)
                           ][,max_oh_id := max(oh_id, na.rm = TRUE), by = list(provider_id, provider_listing_id, pl_end_date_count)
                             ][pl_end_date_count > 1 & oh_id != max_oh_id, `:=`(row_action_pl = "remove", web_start_date_new_pl = NA)]
        pl_id_report <- pl_id_report[,c("oh_id", "base_category_id", "web_start_date_new_pl", "row_action_pl")]
      }
      ### Using the table created above, update or remove all possible rows by oh_id
      all_industry_data2 <- merge(all_industry_data, pl_id_report, by = c("oh_id", "base_category_id"), all.x = TRUE)
      all_industry_data2 <- all_industry_data2[is.na(row_action_pl) | row_action_pl == "keep"
                                               ][row_action_pl == "keep", web_start_date := web_start_date_new_pl
                                                 ][,-c("web_start_date_new_pl", "row_action_pl")]
      ### Using the updated data, determine whether to update or remove the remaining data using ds_lookup_id
      ds_id_report <- copy(all_industry_data2)[ds_lookup_id %between% c(150000000000, 159999999999), ds_id_count := .N, by = ds_lookup_id][ds_id_count > 1]
      setorder(ds_id_report, ds_lookup_id, -web_end_date)
      ds_id_report[,`:=`(max_date = max(web_end_date), min_date = min(web_start_date)), by = ds_lookup_id
                   ][web_end_date == max_date, `:=`(row_action_ds = "keep", web_start_date_new_ds = min_date)
                     ][is.na(row_action_ds), row_action_ds := "remove"
                       ][,ds_end_date_count := .N, by = list(ds_lookup_id, web_end_date)
                         ][,max_oh_id := max(oh_id, na.rm = TRUE), by = list(ds_lookup_id, ds_end_date_count)
                           ][ds_end_date_count > 1 & oh_id != max_oh_id, `:=`(row_action_ds = "remove", web_start_date_new_ds = NA)]
      ds_id_report <- ds_id_report[,c("oh_id", "base_category_id", "web_start_date_new_ds", "row_action_ds")]
      ### Combine the two tables determining 'row_action' (by provider_listing_id and ds_lookup_id)
      master_report <- merge(ds_id_report, pl_id_report, by = c("oh_id", "base_category_id"), all = TRUE)
      master_report[,`:=`(web_start_date_updated = web_start_date_new_ds, row_action = row_action_ds)
                    ][!is.na(web_start_date_new_pl), web_start_date_updated := web_start_date_new_pl
                      ][!is.na(row_action_pl), row_action := row_action_pl]
      master_report <-
        master_report[!is.na(oh_id), list(
          ReferenceID = oh_id,
          ReferenceTypeID = 1L,
          BaseCategoryID = base_category_id,
          WebStartDateTime = web_start_date_updated
        )]
      setkey(master_report, ReferenceID)
      master_report2 <- copy(master_report)[,WebStartDateTime := as.Date(WebStartDateTime)]

      bc <- unique(master_report$BaseCategoryID)
      current_duplicate_report <- shtrain:::execute_sp(name = "dbDataScientist.dbo.Pr_GetDuplicateListingRecord", BaseCategoryID = bc, con = con)
      current_duplicate_report <-
        current_duplicate_report[BaseCategoryID == bc, list(
          ReferenceID = as.integer(ReferenceID),
          ReferenceTypeID,
          BaseCategoryID,
          WebStartDateTime = as.Date(WebStartDateTime)
        )]
      setkey(current_duplicate_report, ReferenceID)

      report_difference_temp <- fsetdiff(master_report2, current_duplicate_report)
      report_difference <- master_report[ReferenceID %in% report_difference_temp$ReferenceID]
      json_object <- toJSON(report_difference)
      assign(stringr::str_c("json_object_", bc), json_object, envir = dupe_env)

    }, by = industry]
  })

  for (k in seq_along(base_cat)) {

    response <-
      httr::POST(
        url = str_c(
          "http://ApiDS.DealerServices.dmz/DataScience/B45DE5615B1AE7B6172D85BF2C3B91CD/api/DuplicateListings/SaveRange?BaseCategoryID=",
          base_cat[k]
        ),
        body = get(stringr::str_c("json_object_", base_cat[k])),
        config = httr::content_type_json()
      )
    code <- httr::status_code(response)
    if (code != 200) {
      stop(glue::glue("Duplicate Listings POST for BaseCategoryID {base_cat[k]} failed with Status Code: {code}."))
    }

  }

}



#' Reads and formats duplicate listing records for the given date and BaseCategoryID
#'
#' Checks the BaseCategoryID supplied is valid, then calls
#' `dbDataScientist.dbo.Pr_GetDuplicateListingRecord` to return all relevant duplicate
#' lising records. Finally, it formats these records for the user, including formatting
#' the WebStartDate to POSIXct.
#'
#' @param base_category_id a numeric vector of length-1 containing a BaseCategoryID.
#' Valid entries are: 4, 464, 27, 28, or 13.
#'
#' @param date a character string supplying a certain date to match in the .csv
#' file name. Should be supplied in the form "YYYY-MM-DD". Defaults to the current
#' date using [Sys.Date()].
#' @return Data table containing "reference_id", "reference_type_id", "base_category_id",
#' and "web_start_date".
#' See __Details__.
#'
#' @details
#'
#' Returns data formatted as if it were being used within [correct_duplicate_listings()].
#'
#'
#' @family duplicate correction
#' @export
get_duplicate_listing_records <- function(base_category_id, date = NULL) {
  if (!base_category_id %in% c(4, 464, 27, 28, 13)) {
    stop("`base_category_id` must be one of the following: 4, 464, 27, 28, 13.")
  }
  con <- create_odbc_connection()
  on.exit(odbc::dbDisconnect(con))
  data <- shtrain:::execute_sp(name = "dbDataScientist.dbo.Pr_GetDuplicateListingRecord", BaseCategoryID = base_category_id, Date = date, con = con)
  data <- data[,list(reference_id = ReferenceID, reference_type_id = ReferenceTypeID, base_category_id = BaseCategoryID, web_start_date = as.POSIXct(WebStartDateTime))]
  data <- .format_numeric(data)
  data
}




#' Remove or update duplicate asking records
#'
#' Calls [get_duplicate_listing_records()] to get duplicate listing records
#' for the appropriate BaseCategoryID. Depending on whether the
#' "web_start_date_updated" field is populated in the duplicate listing record
#' data, rows in the category data with corresponding "oh_id" are either removed,
#' or receive an updated web_start_date.
#'
#' @param data Category data containing possible duplicate data.
#' @return Subset of the original data, with rows identified as duplicates
#' removed, and WebStartDate updated if necessary.
#' See __Details__.
#'
#' @details
#'
#' This function is called within [get_data()] in order to remove duplicate
#' records, and update WebStartDate when necessary, before the category data
#' is returned to the user.
#'
#' @family duplicate correction
#' @export
correct_duplicate_listings <- function(data) {
  base_cat <- shtrain:::get_base_category_id(data = data)
  dupe_data <- get_duplicate_listing_records(base_category_id = base_cat)
  dupe_data <- dupe_data[reference_type_id == 1, list(oh_id = reference_id, web_start_date_updated = web_start_date, row_action = "remove")
                         ][!is.na(web_start_date_updated), row_action := "keep"]
  newdata <-
    merge(data,
          dupe_data,
          by = "oh_id",
          all.x = TRUE)
  counts <- newdata[, .N, row_action]
  name <-
    dplyr::if_else(
      unique(newdata$archive) == TRUE,
      stringr::str_c("archive", unique(newdata$data_type), sep = " "),
      unique(newdata$data_type)
    )
  if (interactive() || getOption("shtrain.verbose", FALSE)) {
    message(
      glue::glue(
        "{counts[row_action == 'remove', N]} duplicate rows removed from {name} data.\n{counts[row_action == 'keep', N]} {name} rows received updated WebStartDate.\n"
      )
    )
  }
  newdata <- newdata[is.na(row_action) | row_action == "keep"
                     ][row_action == "keep", web_start_date := web_start_date_updated
                       ][,`:=`(row_action = NULL, web_start_date_updated = NULL)]
  newdata

}

