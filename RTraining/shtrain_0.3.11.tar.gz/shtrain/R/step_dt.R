step_dt_new <- function(i, j, by, trained = FALSE, col = NULL, ref = NULL) {
  step(subclass = 'dt',
                 i = i,
                 j = j,
                 by = by,
                 trained = trained,
                 col = col,
                 ref = ref)

}


#' data.table expressions in recipes
#'
#' This step is meant to mimic data.table's `[` functionality. You can provide
#' any combination of  `i, j, by`, and it will execute them on the data provided
#' to [bake()]. See [data.table::data.table()] for more details on usage of each slot.
#' See details for restrictions.
#' @inheritParams step_basic
#' @param i A logical predicate to subset the data, looking up names in the `data.table`
#' first. Set to `NULL` if you want to apply to all rows.
#' @param j Assignment to a column or columns. Must include the `:=` operator for
#' scoring recipes, since  the whole data set needs to be returned.
#' @param by How to group the data. This won't serve much use on scoring, but
#' is useful in training recipes.
#' @section Assignment safety:
#' For calls where `i == integer(0)`, i.e. no row matches, a `j` such as
#' `colA :="a"` will not be evaluated. Any further steps relying on the presence
#' of `colA` will have unexpected results. To be safe, either ensure the `i` slot
#' will always result in a value, or set one with all rows first.
#' @section Global variables:
#' Variables are always checked for in the data prior to the calling environment
#' and it's parents. Any variable not in the data will be stored to use upon
#' evaluation.
#'
#'
#' @export
#' @include internal-utils.R
#' @importFrom rlang expr enexpr is_named
step_dt <- function(recipe, i, j, by, trained = FALSE, col = NULL, ref = NULL) {
  if (missing(j) & missing(by)) {
    exprs <- expr(!!i)
    stopifnot(is_named(exprs))
    iv <- exprs$i
    j <- eval(exprs$j)
    byv <- exprs$by
  } else {
    iv <- if (!missing(i)) rlang::enexpr(i) else NULL
    byv <- if (!missing(by)) rlang::enexpr(by) else NULL
    j <- rlang::enexpr(j)
  }

  add_step(recipe, step_dt_new(
    i = iv,
    j = j,
    by = byv,
    trained = trained,
    col = col,
    ref = ref))
}
#' @include internal-utils.R
prep.step_dt <- function(x, training, ...) {
  allnames <- NULL
  if (!is.null(x$i)) {
    inames <- all.vars(x$i)
    allnames <- inames
  }
  if (!is.null(x$by)) {
    bynames <- all.vars(x$by)
    allnames <- c(allnames, bynames)
  }
  jnames <- all.vars(x$j)
  allnames <- unique(c(allnames, jnames))
  in_dt <- unlist(sapply(allnames, function(x) name_check(training, x)), use.names = FALSE)
  out_dt <- setdiff(allnames, in_dt)
  if (length(intersect(names(training), ls(envir = globalenv())))) {
    in_common <- intersect(names(training), ls(envir = globalenv()))
    msg <- glue("step_dt: {lc(in_common)} present in the data and the global environment. \\
                Rename your global environment variable for safety.")
    if (interactive()) {
    warning(msg, call. = FALSE)
    }
  }
  if (length(out_dt) > 0) {
    ref_objects <- vector(mode = 'list', length = length(out_dt))
    for (k in seq_along(out_dt)) {
      ref_objects[[k]] <- if (exists(out_dt[k])) get(out_dt[k]) else NULL
      if (exists(out_dt[k])) {
        names(ref_objects)[k] <- out_dt[k]
      }
    }
    if (sum(lengths(ref_objects)) == 0) {
      ref_objects <- list()
    }
    ref_objects <- ref_objects[names(ref_objects) != ""]
  } else {
    ref_objects <- list()
  }
  step_dt_new(i = x$i,
              j = x$j,
              by = x$by,
              trained = TRUE,
              col = in_dt,
              ref = ref_objects)
}

bake.step_dt <- function(object, newdata, ...) {
  list2env(object$ref, envir = environment())
  if (is.null(object$i) & is.null(object$by)) {
    newdata[, eval(object$j)]
  } else if (!is.null(object$i) & is.null(object$by)) {
    newdata[eval(object$i), eval(object$j)]
  } else if (!is.null(object$i) & !is.null(object$by)) {
    newdata[eval(object$i), eval(object$j), by = eval(object$by)]
  } else {
    stop("Invalid call for `step_dt`.", " `j` must have `:=`",
         "`i` and `by` be one of: both missing, neither missing, `i` only.",
         call. = FALSE)
  }

  invisible(newdata)
}
