# Function which takes in a vector of spec 'types', and returns a vector of prefixes.
type_to_prefix <- function(type) {
  prefix <- str_c(type, "_")
  prefix <- str_replace(prefix, "dlr_", "")
  prefix
}


#' Validates numeric specs
#'
#' `step_validate` is a *specification* of a recipe step which validates that relevant numeric
#' specs fall between supplied bounds, and categorical specs are within defined levels. In the
#' case the bounds or valid level set is violated, the value is set to `NA_real_` or `NA_character_`,
#' respectively.
#'
#' @inheritParams step_basic
#' @param validate A named list of length-2 numeric and variable-length character vectors named with the
#' appropriate base (dealer-entered) specs. For numeric specs, the numbers represent inclusive bounds.
#' For character specs, the character vector represents allowed levels.
#' @param spec_type A vector of spec 'type(s)' ('def', 'sup', etc.) on which to apply the spec
#' bound validation. If validation is desired for the base spec itself, 'dlr' must be supplied
#' within this vector.
#' @param specs A named list, with the names corresponding to variables in the data.
#' For numeric variables, a length-2 numeric vector defining valid bounds. If a row
#' has a value outside the bounds, it will be set to `NA_real_`. For character variables,
#' a character vector giving valid values. If a row has a value outside the defined values,
#' it will be set to `NA_character_`.
#' @family step functions
#' @export
#' @details
#'
#' * Step: Nothing
#' * Prep: Generates a list of specs and their respective bounds/values by pasting prefixes with the spec
#' names provided in validate, and matching these specs with the appropriate validation bounds.
#' * Bake: Desired numeric specs which are outside of the given bounds are replaced with `NA_real_`.
#' Specs which are within the bounds are left unchanged. Adds message to `r_message` where necessary.
#'
step_validate <-
  function(recipe,
           validate,
           spec_type,
           trained = FALSE,
           specs = NULL) {
    add_step(
      recipe,
      step_validate_new(
        validate = validate,
        spec_type = spec_type,
        trained = trained,
        specs = specs
      )
    )
  }

step_validate_new <-
  function(validate,
           spec_type,
           trained = FALSE,
           specs = NULL) {
    step(
      subclass = "validate",
      validate = validate,
      spec_type = spec_type,
      trained = trained,
      specs = specs
    )
  }





prep.step_validate <- function(x, training, ...) {
  prefixes <- type_to_prefix(x$spec_type)
  spec_names <-
    as.vector(outer(prefixes, names(x$validate), paste, sep = ""))
  prefix_str <- paste(prefixes[!prefixes %chin% ""], collapse = "|")

  used_names <- intersect(spec_names, names(training))
  specs <- vector("list", length(used_names))
  names(specs) <- used_names

  for (j in seq_along(used_names)) {
    specs[[j]] <- x$validate[[gsub(prefix_str, "", used_names[j])]]
  }

  step_validate_new(
    validate = x$validate,
    spec_type = x$spec_type,
    trained = TRUE,
    specs
  )

}


bake.step_validate <- function(object, newdata, ...) {
  list_names <- names(object$specs)

  for (k in seq_along(list_names)) {
    col <- list_names[k]
    if (is.numeric(newdata[[col]])) {
      ind <- which(!(newdata[[col]]) %between% object$specs[[col]])
      set(
        x = newdata,
        i = ind,
        j = col,
        value = NA_real_
        )
      dt_add_message(newdata, ind, str_c(" Validated:", col, sep = " "))
    } else {
      ind <- which(!(newdata[[col]]) %in% object$specs[[col]])
      set(
        x = newdata,
        i = ind,
        j = col,
        value = NA_character_
        )
      dt_add_message(newdata, ind, str_c(" Validated:", col, sep = " "))
    }
  }

  newdata
}
