
 #' Update rows by successively more permissive joins
 #'
 #' Adds or updates columns in the data by joining multiple times on a
 #' shrinking set of non-`NA` join columns.
 #' @param data A data.table which contains columns in `on`.
 #' @param lookup A data.table which contains columns in `on` and additional
 #' columns whose values will be given to matching rows in `data`. They should go
 #' from most general to least general. See examples.
 #' @param on Columns on which to join `lookup` and `data`. They should be ordered
 #' from most general to least general.
 #' @param limit The lower limit on join variables. If `limit == 1`, the most general
 #' row update is by joining on `on[1]`. If `limit == 2`, the most general row update
 #' is by joining on `on[1:2]`. The special case of `limit == 0` allows you to supply
 #' a row in `lookup` missing values for all join columns, to provide a general fallback
 #' value. See examples.
 #' @return
 #' `data` will be returned, with new columns corresponding to `new_cols = setdiff(names(lookup), on)`.
 #' Each row will have received values for `new_cols` based upon the most specific join possible for that observation.
 #' @details
 #' `data` is joined to `lookup` multiple times. Rows which match `lookup` for all `on` columns
 #' will receive corresponding values for the rest of the columns in `lookup`. Next, it will join on
 #' all but the last column in `on`, with rows receiving corresponding values for the rest of the columns
 #' in `lookup`. This will continue, dropping columns from the end of the `on` vector each iteration. It will
 #' stop *after* it hits the limit. So if `limit == 1`, it will join on the first `on` column, then terminate.
 #' @importFrom data.table copy uniqueN setkeyv
 #' @export
 #' @family join functions
 #' @seealso step_rolling_join
 #' @include internal-utils.R
 #' @examples \dontrun{
 #' library(data.table)
 #' set.seed(725)
 #' listings <-
 #'   data.table(
 #'     year = sample(c(1:8, rep(NA, 5)), size = 25, replace = TRUE),
 #'     make_model = sample(letters[1:3], size = 25, replace = TRUE),
 #'    t2 = sample(c(TRUE, FALSE, NA), size = 25, replace = TRUE),
 #'     val = rnorm(25)
 #'   )
 #' listings
 #' lookup <- unique(data.table(year = sample(c(1:3, rep(NA, 5)), size = 25, replace = TRUE),
 #'                  make_model = sample(letters[1:3], size = 25, replace = TRUE),
 #'                  in_lookup = TRUE, rval = runif(25),  t2 = sample(c(TRUE, FALSE, NA),
 #'                  size = 25, replace = TRUE)), by = c('year', 'make_model', 't2'))
 #'
 #'  lookup <- rbind(lookup, data.table(make_model = NA, rval = 700), use.names = TRUE, fill = TRUE)
 #'  listings <- rbind(listings, data.table(make_model = "f"), use.names = TRUE, fill = TRUE)
 #'  test <- cascade_join(listings, lookup, c("make_model", "t2", "year"), limit = 0)
 #'  test[order(make_model, t2, year)]
 #'  }
 cascade_join <- function(data, lookup, on, limit = 1) {
   stopifnot(limit < length(on),
             limit >= 0,
             on %in% names(data),
             on %in% names(lookup))


   new_cols <- setdiff(names(lookup), on)
   if (interactive() && length(overwritten <- intersect(new_cols, names(data)))) {
     message(glue::glue("Values in {brackify(overwritten)} will be overwritten in `cascade_join()`."))
   }
   data <- copy(data)
   missing_join_vals <- is.na(lookup[,on, with = FALSE])
   has_no_value <- length(on) - 1
   unique_join_vals <- unique(data, by = on)
   setkeyv(unique_join_vals, on)

   missing_new_vals <- is.na(lookup[,new_cols, with = FALSE])
   # Iterate through the columns in `lookup` which aren't in `on`
   for (j in seq_along(new_cols)) {
     k <- initial_join_length <-  length(on)
     missing_val <- is.na(lookup[[new_cols[j]]])
     # Start with the most specific join on n-columns from `on`, then match on the n-1 columns from `on`,
     # with the nth column being `NA`.
     while (k > 1) {
       cols <- k:initial_join_length
       # Provides a logical index of which rows are the "fall-back" join for # of join columns.
       missing_join <- rowSums(missing_join_vals[,on[cols], drop = FALSE]) == length(cols)

    # `cascade_join()` is used within `bake.step_cascade_join()`, so we cannot use
    # rlang to build the expression.
    # Updates `lookup` so that rows with a missing value for a new column, `new_cols[j]`, receive
    # the fallback value for that join.
       expr <- paste0("lookup[missing_val,", new_cols[j], " := lookup[!missing_val & missing_join, ", new_cols[j], ", by = c(on[-cols])][.SD, ", new_cols[j], ", on = c(on[-cols])]]")
       eval(parse(text = expr))
       k <- k - 1
       missing_val <- is.na(lookup[[new_cols[j]]])
       if (sum(missing_val) == 0) {
         break
       }
     }
 }
   # # If a value is missing when grouped by x, y, z; fill in with value when grouped by x, y
   # lookup[, (.SDcols) := lapply(.SDcols, function(x) max(x)), by = on[-(k:init)]]
   if (limit == 0) {
     fallback_ind <- which(rowSums(missing_join_vals) == ncol(missing_join_vals))
     data[, (new_cols) := lookup[fallback_ind,new_cols, with = FALSE]]
   }
   join_cols <- NULL
   # We go from least-specified to most-specified because we'll be overwriting for every row
   # which has a match. i.e. same value may be overwritten 4 times, with the last value corresponding
   # to the most precisely specified join.
   for (k in seq_along(on)) {
     # grow the join column vector
     join_cols <- c(join_cols, on[k])
     # if it isn't the most specified join, use `rowSums()` on a subset of the columns in `missing_join_vals`.
     if (k != length(on)) {
       group_set <- which(rowSums(missing_join_vals[,setdiff(on, join_cols), drop = FALSE]) == has_no_value, useNames = FALSE)} else {
         # Otherwise use the full `missing_join_vals`
         group_set <- which(rowSums(missing_join_vals) == has_no_value, useNames = FALSE)
       }
     # If the subset of `lookup` is not unique by `join_cols`, fail.
     if (uniqueN(lookup[group_set], by = join_cols) != nrow(lookup[group_set])) {
       diff <- nrow(lookup) - uniqueN(lookup, by = join_cols)
       stop(diff, " duplicate rows detected for join column(s) ", brackify(join_cols) ,
               ".", call. = FALSE)
     }
   # If the subset of `lookup` has 0 rows, begin next iteration of loop after decrementing specification of join.
     if (!length(group_set)) {
       has_no_value <- has_no_value - 1
       next
     }
     # wow.
     # take the subset of `lookup` corresponding to `group_set`. Reorder (by joining) based on `unique_join_vals`, which
     # is ordered by `join_cols`. Select only current `join_cols` and `new_cols` from this monster of an i-slot.
     # Join to the `data` based on current `join_cols`, and update `new_cols` by reference with their
     # values in the i-slot row which matches.
     data[lookup[group_set][unique(unique_join_vals, by = join_cols), on = join_cols, nomatch = 0L, mult = "first"][,c(join_cols, new_cols), with = FALSE], (new_cols) := mget(paste0("i.", new_cols)), on = join_cols]
     # Break the loop if we've completed the least specified join allowed by `limit`.
     if (limit == has_no_value + 1) {
       break
     }
     has_no_value <- has_no_value - 1
   }
   data[]
 }


#' @describeIn cascade_join Use `cascade_join()` as a step.
#' @export
#' @family step functions
#' @family join functions
#' @include steps.R
#' @include recipes.R
step_cascade_join <- function(recipe, lookup, on, limit = 1, trained = FALSE) {
  add_step(recipe, step_cascade_join_new(
    lookup = lookup,
    on = on,
    limit = limit,
    trained = trained
  ))
}

step_cascade_join_new <- function(lookup, on, limit = 1, trained = FALSE) {
  step(subclass = "cascade_join",
       lookup = lookup,
       on = on,
       limit = limit,
       trained = trained)
}

prep.step_cascade_join <- function(x, training, ...) {
  stopifnot(all(x$on %in% names(x$lookup)),
            all(x$on %in% names(training)))
  if (length(x$on) == 1) {
    stop("Only one join column specified in `on`. If this is correct, ",
         "use step_merge() instead.", call. = FALSE)
  }

step_cascade_join_new(lookup = x$lookup,
                      on = x$on,
                      limit = x$limit,
                      trained = TRUE)
}

bake.step_cascade_join <- function(object, newdata, ...) {
  cascade_join(data = newdata, lookup = object$lookup, on = object$on, limit = object$limit)
}