#' @include tables.R


mmt <- function(data) {
  con <- create_server_connection()
  on.exit(RODBC::odbcClose(con))
  mm_results <- mm_table(con, base_category_id = get_base_category_id(category_id = unique(data$category_id)))
  mm_results
}

#' Identify validity of make models in data
#'
#' Adds 3 indicators to `data` to determine which
#' listings are active for *its* category in MMM, and which are active
#' for *a* category belonging to the same base category in MMM. Trailer
#' data is returned unaffected. See [here](file://sandhills.int/file/Data/DTA/R/Resources/articles/invalidmms.html) for more information.
#' @param data `data.table` with `make_model` and `category_id`
#' @return Trailer data will be returned unmodified. Otherwise,
#' `data` with new columns `odc_status`, `od_status`, and `n_categories`.
#' @details
#' * odc_status: dbMMM.dbo.ObjectDefaultsCategory.Status, `NA` if not present in that table.
#' * od_status: dbMMM.dbo.ObjectDefaults.Status, `NA` if not present in that table.
#' * n_categories: Count of how many categories the make model is active for in
#' dbMMM.dbo.ObjectDefaultsCategory
#' @export
#' @family MMM functions
mm_check <- function(data) {
  if (get_base_category_id(data = data) != 28) {
  cat_mms <- mmt(data)
  data <- cat_mms[,list(make_model, category_id, odc_status)][
    data, on = c("make_model", "category_id")]
  data <- cat_mms[,list(make_model, od_status, n_categories)][
    data, on = "make_model", mult = "first"]
  }
  data
}

#' Determine missing active make models
#'
#' Provides information about which appropriate category/make model combinations
#' are present in the data, restricted by the categories present in `data`. Does
#' not work with trailer data.
#' @param data Data with `category_id` and `make_model`.
#' @return A `data.table` with `category_id`, `make_model`, and the logical indicator
#' `mm_in_data`.
#' @export
#' @family MMM functions
mm_missing <- function(data) {
  if (get_base_category_id(data = data) != 28) {
  present_cat_mm <- unique(data[,list(category_id, make_model)])[,mm_in_data := TRUE]
  mm_table <- mmt(data)[,list(category_id, manufacturer, make_model, make_model_group)]
  present_cat_mm[mm_table, on = c("category_id", "make_model")][is.na(mm_in_data), mm_in_data := FALSE][
    category_id %in% present_cat_mm$category_id
    ][,list(category_id, manufacturer, make_model, make_model_group, mm_in_data)]
  } else {
    if (interactive()) {
    message("Trailers are not differentiated by model, so `mm_missing()` cannot ",
            "work. Returning `NULL` invisibly.")
    }
    invisible(NULL)
  }
}

