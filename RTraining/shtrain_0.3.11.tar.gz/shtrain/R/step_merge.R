
#' Merge to data
#'
#' `step_merge` creates a *specification* of a recipe step that will
#' join the data to the `ref` given based on `by` vector.
#' @inheritParams step_basic
#' @param y Table to merge to
#' @param by columns to merge by.
#' @param all.x Logical.`TRUE`` is equivalent to SQL's left join.
#' @param options All additional arguments to `data.table:::merge.data.table`.
#' @export
#' @details
#'  Step:  Nothing
#'  Prep:  Nothing
#'  Bake:  Merges data.
step_merge <- function(recipe, y, by, all.x = TRUE,  options = NULL, trained = FALSE) {
  add_step(recipe,
           step_merge_new(
             y = y,
             by = by,
             all.x = all.x,
             options = options,
             trained = trained))
}


step_merge_new <- function(y, by = NULL, all.x = all, options = NULL, trained = FALSE) {
  step(subclass = "merge",
       y = y,
       by = by,
       all.x = all.x,
       options = options,
       trained = trained)
}

prep.step_merge <- function(x, training,  ...) {

  step_merge_new(y = x$y,
                  by = x$by,
                  all.x = x$all.x,
                  options = x$options,
                 trained = TRUE)
}
bake.step_merge <- function(object, newdata, ...) {
  new_cols <- setdiff(names(object$y), object$by)
  if (any(new_cols %in% names(newdata))) {
    cols <- intersect(new_cols, names(newdata))
    set(x = newdata,
        i = NULL,
        j = cols,
        value = NULL)
    if (interactive()) {
      message(paste0(cols, collapse = ", "), " already in `newdata`. ",
              "Dropping these columns from `newdata` and merging.")
    }
  }
  do.call(merge, args = c(
    list(
      x = newdata,
      y = object$y,
      by = object$by,
      all.x = object$all.x
    ),
    object$options
  ))

}

summary.step_merge <- function(x, ...) {
  data.table(columns_added = setdiff(names(x$y), x$by))
}

