#' Retrieves data corresponding to the provided IDs and data type
#'
#' Given a connection, it queries the correct view, and returns a `data.table`
#' containing `selections`, `shtrain:::shdata$filter_selections`, and
#' `shtrain:::shdata$default_selections`.
#'
#' @param con A connection generated with [create_server_connection()].
#' @param data_type 'auction', 'asking', or 'aftersale'.
#' @param category_id A vector of category IDs belonging to a single industry,
#' or an industry abbreviation - "mat", "trk", "trl", "tho", "cnt".
#' @param selections A character vector of selections or comma separated string
#'   of selections. Also accepts "*" to select all columns from the view. This
#'   should always be pared back to only the columns you need after an exploratory
#'   analysis.
#' @param print_query Should the query be printed to the console?
#' @param archive Logical. Indicates whether the archive data should be returned in
#' lieu of "current" data.
#' @param invalid_aftersale Logical. `FALSE` corresponds to views prior to TO#26195177.
#' `TRUE` allows listings with now-inactive cat make models into the data. Inactive cat
#' make models are always present in auction/asking data.
#' @param correct_duplicates Logical. `TRUE` means that duplicate records should be
#' removed via [correct_duplicates()].
#'
#'
#' @family querying functions
#' @importFrom data.table  setnames ':=' setDT
#' @importFrom RODBC sqlQuery
#' @export
get_data <- function(con, data_type, category_id, selections, print_query = FALSE, archive = FALSE,
                     invalid_aftersale = FALSE, correct_duplicates = TRUE, remove_hibid_records = TRUE) {
  if (get_industry(category_id) == "cnt" && data_type == "auction") {
    return(data.table(NULL))
  }
  data <- setDT(sqlQuery(con, base_query(data_type = data_type,
                                   selections = selections,
                                   category_id = category_id,
                                   print_query = print_query,
                                   archive = archive,
                                   con = con),
                   stringsAsFactors = FALSE))
  cache <- shdata$name_table[[data_type]] %in% names(data)
  cache_names(r = shdata$name_table[cache, "r"], sql = shdata$name_table[cache, data_type])
  setnames(data, names(data), translate_names(names = names(data), from = data_type, to = "r"))
  data[,archive := archive]
  data[, data_type := data_type]
  data[,ref_id := as.double(ref_id)]
  data[,ds_lookup_id := as.double(ds_lookup_id)]
  if (data_type == 'asking') {
  data[asking() & as.Date(web_end_date, origin = '1753-01-01') <
         as.Date(Sys.Date(), origin = '1753-01-01'),
       historical_asking := TRUE]
     data[is.na(historical_asking), historical_asking := FALSE]
  }
   data[asking() | auction(), oh_id := as.double(ref_id)]
   data[aftersale(), ps_id := as.double(ref_id)]


  eval_type <- switch(data_type,
         auction = "auction",
         aftersale = "retail",
         asking = NA_character_,
         NA_character_)
  data[,eval_type := eval_type]
  cache_names(r = "eval_type", sql = "EvaluationType")

  bcat <- get_base_category_id(category_id = category_id)
  if (data_type == "aftersale" & bcat != 28) {
    data[,make_model := str_to_lower(str_c(str_trim(manufacturer), str_trim(model), sep = " "))]
    mmt <- mm_table(con,base_category_id = get_base_category_id(category_id = category_id))

    if (invalid_aftersale) {
      data <- mmt[,list(make_model, model_group)][data, on = "make_model", mult = "first", nomatch = NA]
    } else {
      data <-
        data[mmt[odc_status == "active" &
                   od_status == "active", list(category_id, make_model, model_group)
             ],on = c("category_id", "make_model"), nomatch = 0L]
    }
  }
  data <- .add_make_model(data)
  if (bcat != 28) {
    cache_dependency(source = "make_model", derived = "manufacturer")
  }
  if (nrow(data) == 0 && interactive()) {
    type <- if (archive) paste0(data_type, "_archive") else data_type
    warning("No ", type, " data for your category selection.", call. = FALSE)
    data <- data.table(NULL)
  }

  if (data_type == "asking" && correct_duplicates == TRUE) {
    con2 <- create_odbc_connection()
    on.exit(odbc::dbDisconnect(con2))
    import_date_time <- shtrain:::execute_sp(name = "dbDataScientist.dbo.Pr_GetDuplicateListingImportDate", BaseCategoryID = bcat, con = con2)
    import_date <- as.IDate(import_date_time$LastImportedOnUTCDateTime, tz = "America/Chicago")
    if (import_date != Sys.Date()) {
      update_duplicate_table(base_category_id = bcat)
    }
    data <- correct_duplicate_listings(data = data)
  }

  if (data_type == "asking" && remove_hibid_records == TRUE && bcat == 4) {
    if (!file.exists(file.path(stringr::str_extract(command_arguments()$base_dir, ".*/file/DataScience(/Lab)?"),
                               "PreImportScripts/hibid_record_removal/hibid_record_reports",
                               glue::glue("{Sys.Date()}_hibid_report.csv")))) {
      create_hibid_report()
    }
    data <- remove_hibid_records(data = data)
  }

  data
}

#' Retrieves all data corresponding to the provided category IDs
#'
#' Opens the connection, queries the five appropriate views, and returns a
#' data frame containing `selections`, `shtrain::shdata$filter_selections`,
#' `shtrain:::shdata$default_selections`; along with `eval_type`, `historical_asking`,
#' `data_type`, `archive`, `active_mm`, and `active_cat_mm`.
#'
#' @inheritParams get_data
#' @param archive Logical. Indicates whether to also retrieve data from archived tables.
#' Set to `FALSE` by default for backwards-compatibility.
#' @return The three datasets merged together.  See __Details__.
#'
#' @details
#'
#' For each data type available for the given industry, the following is done.
#'
#' 1. Default selections, user-entered selections, and filtered selections are
#' combined and validated against an internal list.
#' 2. Data is retrieved from relevant views and archived views.
#' 3. The SQL-R name relationship is cached for each variable retrieved.
#' 4. The data type is assigned as a column, `data_type`.
#' 5. Auction and aftersale data receive a matching `eval_type`.
#'
#' The data is then combined. Asking with a `web_end_date`
#' before today's date receive a flag, `historical_asking`, indicating them as such.
#'
#'
#'
#' @family querying functions
#' @export
#'
#' @importFrom data.table rbindlist ':='
get_all_data <- function(con, category_id, selections, print_query = FALSE, archive = FALSE,
                         invalid_aftersale = FALSE, correct_duplicates = TRUE, remove_hibid_records = TRUE) {
    auction <- get_data(con, "auction", category_id, selections, print_query = print_query, archive = FALSE)
    aftersale <- get_data(con, "aftersale", category_id, selections, print_query = print_query, archive = FALSE,
                          invalid_aftersale = invalid_aftersale)
    asking <- get_data(con, "asking", category_id, selections, print_query = print_query, archive = FALSE,
                       correct_duplicates = correct_duplicates, remove_hibid_records = remove_hibid_records)
    sets <- list(auction, aftersale, asking)
    if (isTRUE(archive)) {
      auction_archive <- get_data(con, "auction", category_id, selections, print_query = print_query, archive = archive)
      asking_archive <- get_data(con, "asking", category_id, selections, print_query = print_query, archive = archive,
                                 correct_duplicates = correct_duplicates, remove_hibid_records = remove_hibid_records)
      sets <- c(sets, list(auction_archive, asking_archive))
    }
    all_data <- rbindlist(sets, use.names = TRUE, fill = TRUE)
    if (get_base_category_id(unique(all_data$category_id)) == 28) {
      options(shtrain.industry = 28)
    }
    all_data
}

#' Copies asking listings
#'
#' Copies asking listings so there is a copy for each `eval_type`: "auction" and "retail".
#' @param data data with `data_type` column..
#' @return The input `data` with `data_type` "asking" doubled, one copy of the listing
#' for each `eval_type`.
#' @export
double_asking <- function(data) {
  data <- copy(data)
  asking_data <- data[asking()]
  data[asking(), eval_type := "retail"]
  asking_data[, eval_type := "auction"]
  rbindlist(list(data, asking_data), use.names = TRUE, fill = TRUE)
}

#' Removes asking listings which have since sold
#'
#' Removes asking listings which have either an `oh_id` or a `ds_lookup_id` in
#' the auction data. Removes asking listings which have a `ds_lookup_id` in
#' the aftersale data. This filter should really only affect asking listings which
#' have since sold
#' @param data Data with `oh_id` and `ds_lookup_id` columns.
#' @export
rm_duplicates <- function(data) {
  asking <- data[asking()]
  auction <- data[auction()]
  aftersale <- data[aftersale()]
  in_auction_oh_id <- asking[oh_id %in% na.omit(auction$oh_id), which = TRUE]
  in_auction_dslu_id <- asking[ds_lookup_id %in% na.omit(auction$ds_lookup_id), which = TRUE]
  in_aftersale_dslu_id <- asking[ds_lookup_id %in% na.omit(aftersale$ds_lookup_id), which = TRUE]
  duplicated_asking <- asking[c(in_auction_dslu_id, in_auction_oh_id, in_aftersale_dslu_id),]
  fsetdiff(data, duplicated_asking, all = TRUE)
}

#' Removes certain asking listings with a corresponding auction or aftersale record
#'
#' Removes asking listings which have a `ds_lookup_id` in the auction data.
#' Removes asking listings which have an `oh_id` or `ds_lookup_id` in the
#' "not sold" aftersale data. When parameter remove_all = TRUE, removes asking
#' listings which have an `oh_id` or `ds_lookup_id` in the "sold" aftersale data.
#' @param data Data with `oh_id` and `ds_lookup_id` columns.
#' @param remove_all Locigal indicating whether asking listings which have a
#' ds_lookup_id in the "sold" aftersale data should be removed.
#' @export
rm_duplicates2 <- function(data, remove_all = FALSE) {
  asking <- data[asking()]
  auction <- data[auction()]
  aftersale_sold <- data[aftersale() & tolower(str_trim(sale_status)) == "sold"]
  aftersale_not_sold <- data[aftersale() & tolower(str_trim(sale_status)) == "not sold"]
  auction_ds_id <- asking[ds_lookup_id %in% na.omit(auction$ds_lookup_id), which = TRUE]
  aftersale_sold_oh_id <- asking[oh_id %in% na.omit(aftersale_sold$oh_id), which = TRUE]
  aftersale_sold_ds_id <- asking[ds_lookup_id %in% na.omit(aftersale_sold$ds_lookup_id), which = TRUE]
  aftersale_not_sold_oh_id <- asking[oh_id %in% na.omit(aftersale_not_sold$oh_id), which = TRUE]
  aftersale_not_sold_ds_id <- asking[ds_lookup_id %in% na.omit(aftersale_not_sold$ds_lookup_id), which = TRUE]
  if (remove_all == TRUE) {
    duplicated_asking <- asking[c(auction_ds_id, aftersale_sold_oh_id, aftersale_sold_ds_id, aftersale_not_sold_oh_id, aftersale_not_sold_ds_id),]
  }
  if (remove_all == FALSE) {
    duplicated_asking <- asking[c(auction_ds_id, aftersale_not_sold_oh_id, aftersale_not_sold_ds_id),]
  }
  fsetdiff(data, duplicated_asking, all = TRUE)
}

#' Retrieves default data
#'
#' Identifies, queries, and formats valid default spec data based on the parameters supplied.
#'
#' @param category_id A numeric vector of ObjectCategoryIDs.
#' @param selections A character vector of default spec names in "snake_case", including
#' the "def_" prefix.
#' @return A data.table of default spec data, including the columns: make_model, year,
#' category_id, object_default_id.
#' @details This function should be used whenever attempting to obtain default spec data
#' for numerous categories, specifically when there are overlapping MakeModel names within
#' those categories.
#'
#' All ObjectCategoryIDs supplied in `category_id` must be in the same industry.
#'
#' When using this function to obtain default spec data, do not supply default spec "selections"
#' within `add_specs()`.
#' @examples
#' default_data <- get_default_data(category_id = c(1032, 1073), selections = c("def_capacity"))
get_default_data <- function(category_id, selections) {

  ind <- shtrain:::get_industry(category_id)
  default_data <- data.table()

  con <- create_server_connection()
  on.exit(odbcClose(con))

  for (i in seq_along(category_id)){
    final_selections_r <- intersect(selections, sql_columns(con, category_id[[i]])[["default"]])
    final_selections_sql <- shtrain:::translate_names(names = final_selections_r, from = "r", to = "default")
    cache_names(r = final_selections_r, sql = final_selections_sql)
    temp_specs <-
      setDT(sqlQuery(
        con,
        glue("SELECT ObjectDefaultID, MakeModel, Year, {str_c(final_selections_sql, collapse = ', ')}
             FROM dbo.vw_{ind}DefaultSpecsWithYear_{category_id[[i]]}"),
        stringsAsFactors = FALSE
      ))
    temp_specs <- temp_specs[,category_id := as.numeric(category_id[i])]
    default_data <- rbind(default_data, temp_specs, fill = TRUE)
    rm(temp_specs)
  }

  setnames(
    default_data,
    old = c("ObjectDefaultID", "MakeModel", "Year"),
    new = c("object_default_id", "make_model", "year")
  )
  set_r_names(default_data)
  default_data <- .format_character(.format_numeric(default_data))

  cols <- c("object_default_id", "category_id", "make_model", "year")
  setcolorder(default_data, c(cols, setdiff(names(default_data), cols)))

  default_data

}
