#' Scale evaluations by an index centered at 1
#'
#' `step_scale_index` creates a *specification* of a recipe step
#' that will multiply or divide a column by a vector or scalar.
#' @inheritParams step_basic
#' @param index Either a scalar or a single column name.
#' @param op "multiply" or "divide"
#' @param col Column to scale. Defaults to "evaluation".
#' @param new_col Column where the calculation is put.
#' Defaults to `col` if not provided.
#' @export
#' @details
#' * Step: Nothing
#' * Prep: Argument checking.
#' * Bake: Multiply or divide `col` by `index` based on `op`, assign to `new_col`.
#'   Sets correction for simulated points to 1.
step_scale_index <- function(recipe, index, op = "multiply", col = "evaluation", new_col = NULL, trained = FALSE) {
  add_step(recipe,
           step_scale_index_new(
             index = index,
             op = op,
             col = col,
             new_col = new_col,
             trained = trained
           ))
}

step_scale_index_new <- function(index, op = "multiply", col = "evaluation", new_col = NULL, trained = FALSE) {
  step(subclass = "scale_index",
       index = index,
       op = op,
       col = col,
       new_col = new_col,
       trained = trained)
}


prep.step_scale_index <- function(x, training, ...) {
  stopifnot(length(x$index) == 1,
            is.numeric(x$index) ||
              is.character(x$index),
            x$op %in% c("multiply", "divide"))
  if (is.null(x$new_col)) {
    x$new_col <- x$col
  }
  step_scale_index_new(
    index = x$index,
    op = x$op,
    col = x$col,
    new_col = x$new_col,
    trained = TRUE
  )
}

bake.step_scale_index <- function(object, newdata, ...) {
  if (is.character(object$index)) {
    stopifnot(object$index %in% names(newdata))
    correction <- newdata[[object$index]]
  } else {
    correction <- object$index
  }

  if (object$op == "multiply") {
    set(x = newdata,
        i = NULL,
        j = object$new_col,
        value = newdata[[object$col]]*correction)
  } else if (object$op == "divide") {
    set(x = newdata,
        i = NULL,
        j = object$new_col,
        value = newdata[[object$col]]/correction)
  } else {
    stop("Please set `op` to 'divide' or 'multiply'.")
  }
  newdata
}


