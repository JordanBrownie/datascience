# Used to initialize static data files stored within the package.
# Filename is aaa.R to guarantee it is loaded first.
# zzz.R creates some additional objects internal to the package upon loading.
shdata <- new.env(parent = emptyenv())
shref <- new.env(parent = emptyenv())
load(file.path(getwd(), "/R/sysdata.rda"), envir = shdata)

