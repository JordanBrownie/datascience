#' Adds hyperlink to auction data
#' @inheritParams step_basic
#' @param ref_industry Generated on [prep()].
#' @export
#' @details
#' * Step: Nothing.
#' * Prep: Populate `ref_industry` using [get_industry()].
#' * Bake: Construct hyperlinks.
add_link <- function(recipe, ref_industry = NULL, trained = FALSE) {
  add_step(recipe,
           add_link_new(ref_industry = ref_industry,
                        trained = trained))
}



add_link_new <- function(ref_industry = NULL, trained = FALSE) {
  add(subclass = "link",
      ref_industry = ref_industry,
      trained = trained)
}
prep.add_link <- function(x, training, ...) {
  add_link_new(ref_industry = get_industry(data = training),
               trained = TRUE)
}
#' @importFrom stringr str_c
bake.add_link <- function(object, newdata, ...) {
  url <- list(mat = "http://www.machinerytrader.com/listings/construction-equipment/auction-results/",
              trk = "http://www.truckpaper.com/listings/trucks/auction-results/",
              trl = "http://www.truckpaper.com/listings/trailers/auction-results/",
              tho = "http://www.tractorhouse.com/listings/farm-equipment/auction-results/")
  auction <- newdata[auction(), which = TRUE]
  set(x = newdata,
      i = auction,
      j = "link",
      value = str_c(url[[object$ref_industry]], newdata[["ref_id"]][auction]))
  newdata
}


