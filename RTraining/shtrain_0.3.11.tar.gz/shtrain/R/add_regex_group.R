
#' Adds group based on regular expressions
#'
#' `add_regex_group` creates a *specification* of a recipe step that will
#'   add a new column populated based on named regular expressions.
#' @inheritParams step_basic
#' @param spec Column name to apply the `regex` to.
#' @param new New column name. Defaults to `paste0(spec, "_group")`.
#' @param regex Named list of the form `list(newname = "regex1", newname2 = "regex2",...)`.
#' @param catch_all Either `FALSE`, for no catch all group, or a character value for the
#' catch all group.
#' @inherit step_basic return
#' @export
#' @details
#' * Step: Nothing
#' * Prep: Computes `new` if not given.
#' * Bake: Adds a column `new` with the resulting groups. `r_message` is populated
#'   if there are any listings which receive multiple matches.
add_regex_group <- function(recipe, spec, regex, catch_all = FALSE,  new = NA, trained = FALSE) {
  add_step(recipe,
           add_regex_group_new(
             spec = spec,
             new = new,
             regex = regex,
             catch_all = catch_all,
             trained = trained)
  )
}

add_regex_group_new <- function(spec, regex, catch_all = FALSE, new = NA, trained = FALSE) {
  add(subclass = "regex_group",
      spec = spec,
      new = new,
      regex = regex,
      catch_all = catch_all,
      trained = trained)
}

prep.add_regex_group <- function(x, training, ...) {
  if (is.na(x$new)) {
    x$new <- paste0(x$spec, "_group")
  }
  cache_dependency(source = x$spec, derived = x$new)
  add_regex_group_new(spec = x$spec,
                       regex = x$regex,
                       catch_all = x$catch_all,
                       new = x$new,
                       trained = TRUE)
}

bake.add_regex_group <- function(object, newdata, ...) {
  regex <- object$regex
  spec <- object$spec
  spec_group <- object$new
  values <- names(regex)
  set(x = newdata,
      i = NULL,
      j = spec_group,
      value = NA_character_)
  detected <- lapply(regex, str_detect, string = newdata[[spec]])
  compare <-
    matrix(unlist(detected, use.names = FALSE),
           ncol = length(regex),
           byrow = FALSE)
  num_matches <- rowSums(compare)
  ind <- lapply(detected, which)
  multiples <- num_matches > 1 & !is.na(num_matches)
  multiples_ind <- which(multiples)
  if (any(multiples)) {
    if (interactive()) {
      message("At least one element has multiple matches. Check r_message field.")
    }
    # newdata[multiples, r_message := paste0(r_message, "regex:", num_matches[multiples])]
    dt_add_message(newdata, multiples, str_c(" Regex:", num_matches[multiples], sep = " "))
    needs_message <- lapply(ind, intersect, y = multiples_ind)
    for (k in seq_along(regex)) {
      # set(
      #   x = newdata,
      #   i = needs_message[[k]],
      #   j = "r_message",
      #   value = paste(newdata[["r_message"]][needs_message[[k]]], values[k])
      # )
      dt_add_message(newdata, needs_message[[k]], str_c(" ", values[k]))
    }
  }
  for (k in seq_along(regex)) {
    set(
      x = newdata,
      i = ind[[k]],
      j = spec_group,
      value = values[k]
    )
  }
!is.na(object$catch_all)
  if (object$catch_all == TRUE) {
    not_missing <- !is.na(newdata[[spec]])
    no_match <- is.na(newdata[[spec_group]])
    newdata[not_missing & no_match, (spec_group) := "other"]
  }
  newdata
}

summary.add_regex_group <- function(x, ...) {
  data.table(source = x$spec,
             derived = x$new,
             new_levels = c(names(x$regex), ifelse(isTRUE(x$catch_all), "other", NULL)),
             regex = c(x$regex, ifelse(isTRUE(x$catch_all), "", NULL))
  )
}

#' @describeIn add_regex_group Non-recipe version.
#' @export
.create_regex_group <-
  function(data, spec, regex, catch_all = FALSE, new = NA) {
      data <- copy(data)
      regex <- regex
      spec <- spec
      spec_group <- new
      values <- names(regex)
      set(x = data,
          i = NULL,
          j = spec_group,
          value = NA_character_)
      detected <- lapply(regex, str_detect, string = data[[spec]])
      compare <-
        matrix(unlist(detected, use.names = FALSE),
               ncol = length(regex),
               byrow = FALSE)
      num_matches <- rowSums(compare)
      ind <- lapply(detected, which)
      multiples <- num_matches > 1 & !is.na(num_matches)
      multiples_ind <- which(multiples)
      if (any(multiples)) {
        if (interactive()) {
          message("At least one element has multiple matches. Check r_message field.")
        }
        # data[multiples, r_message := paste0(r_message, "regex:", num_matches[multiples])]
        dt_add_message(data, multiples, str_c(" Regex:", num_matches[multiples], sep = " "))
        needs_message <- lapply(ind, intersect, y = multiples_ind)
        for (k in seq_along(regex)) {
          # set(
          #   x = data,
          #   i = needs_message[[k]],
          #   j = "r_message",
          #   value = paste(data[["r_message"]][needs_message[[k]]], values[k])
          # )
          dt_add_message(data, needs_message[[k]], str_c(" ", values[k]))
        }
      }
      for (k in seq_along(regex)) {
        set(
          x = data,
          i = ind[[k]],
          j = spec_group,
          value = values[k]
        )
      }
      !is.na(catch_all)
      if (catch_all == TRUE) {
        not_missing <- !is.na(data[[spec]])
        no_match <- is.na(data[[spec_group]])
        data[not_missing & no_match, (spec_group) := "other"]
      }
      data
    }

