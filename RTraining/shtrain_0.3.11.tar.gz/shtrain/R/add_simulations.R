#' Simulates sale points using asking data
#'
#' `add_simulations` creates a specification of a recipe step which will
#' simulate sale points to use in training. See details.
#' @inheritParams step_basic
#' @param quantiles A vector of length 2 specifying the quantiles to use in
#' subsetting observations with both a list and sale price. So if the percentage (or absolute)
#' difference is above the .95 quantile and that is the upper bound you specified,
#' it will be removed.
#' @param knots Number of knots to pass onto [stats::smooth_spline()], which is fit
#' during [prep()]
#' @param min_listings Minimum number of listings to use in computing markdown by
#' age group during [prep()].
#' @param response The variable to use in calculating the list/sale price differences.
#' Also, the column which receives the simulated prices.
#' @param ref_dt A data.table populated on [prep()].
#' @export
#' @details
#' * Requirements: `sale_type` column with values "sold at auction" and "retail", at least.
#' * Step: Nothing.
#' * Prep: Generates `ref_dt` Creates an index based on the sum of absolute errors
#'   divided by sum of sale prices. The index is tied age, rounded to the nearest
#'   year, and computed by data type.
#' * Bake: Adds simulated sales to `newdata`. They will be differentiated from other
#' listings by `data_type == "simulated"`and the appropriate `eval_type`.
add_simulations <- function(recipe, quantiles, knots, min_listings, response =  "usd_sale_price", ref_dt = NULL, trained = FALSE) {
  add_step(recipe,
           add_simulations_new(quantiles = quantiles,
                                 knots = knots,
                                 min_listings = min_listings,
                               response = response,
                                 ref_dt = ref_dt,
                                 trained = trained))
}

add_simulations_new <- function(quantiles, knots, min_listings, response = "usd_sale_price", ref_dt = NULL, trained = FALSE) {
  add(subclass = "simulations",
       quantiles = quantiles,
       knots = knots,
       min_listings = min_listings,
       response = response,
       ref_dt = ref_dt,
       trained = trained)
}

#' @importFrom data.table := set %between%
#' @importFrom stats quantile smooth.spline predict
prep.add_simulations <- function(x, training, ...) {
  stopifnot(all(c("sale_type", x$response) %in% names(training)))
  # Only need listings with both a list and sale price
  temp_full <- copy(training[!is.na(usd_list_price) & !is.na(get(x$response))])
  refs <- list()
  types_available <- c("auction", "aftersale")
  if (nrow(temp_full[sale_type == "sold at auction"]) == 0 && interactive()) {

    message("No aftersale listings with sale_type 'sold at auction'. Remove",
         " `filter_sale_type()` from your recipe (or a preceding one) if present.",
         " Adding aftersale simulations only.")
    types_available <- "aftersale"
  }
  # Create one temp table for each sale type.
  temp <- list("auction" = temp_full[aftersale() & sale_type == "sold at auction"],
               "aftersale" = temp_full[aftersale() & sale_type == "retail"])
  stopifnot("usd_list_price" %in% names(training))

  for (type in types_available) {
    temp[[type]][, `:=`(list_diff = usd_list_price - get(x$response),
                        perc_diff = usd_list_price/get(x$response))]
    # Subset to observations whose list is not equal to sale and abs/perc
    # differences aren't outliers.
    temp[[type]] <- temp[[type]][list_diff != 0 &
                                   (list_diff %between%
                                      quantile(list_diff,
                                               probs = x$quantiles)) |
                                   (perc_diff %between%
                                      quantile(perc_diff,
                                               probs = x$quantiles))]
    temp[[type]][, rounded_age := round(age, 0)]
    age_range <- range(temp[[type]][["rounded_age"]], na.rm = TRUE)
    ages <- seq(from = age_range[1], to = age_range[2], by = 1L)
    ref <- data.table(data_type = type,
                      rounded_age = ages,
                      error = NA_real_,
                      matches_age = NA_real_,
                      total = NA_real_,
                      age_range = NA_real_,
                      markdown = NA_real_)
    for (i in seq_along(ages)) {
      incl_ages <- ages[i]
      j = 1
      while (sum(temp[[type]][["rounded_age"]] %in% incl_ages) < x$min_listings && j < length(ages)) {
        incl_ages <- c(incl_ages, ages[max(1, i - j)], ages[min(length(ages), i + j)])
        j <- j + 1
      }
    incl_dt <- temp[[type]][rounded_age %in% incl_ages]
    set(x = ref,
        i = i,
        j = "error",
        value = incl_dt[, sum(list_diff)/sum(get(x$response))])
    set(x = ref,
        i = i,
        j = "matches_age",
        value = incl_dt[rounded_age == ages[i], .N])
    set(x = ref,
        i = i,
        j = "total",
        value = nrow(incl_dt))
    set(x = ref,
        i = i,
        j = "age_range",
        value = length(unique(incl_ages)))
    }
    set(x = ref,
        i = NULL,
        j = "markdown",
        value = 1 - predict(smooth.spline(ref[["rounded_age"]], ref[["error"]], nknots = x$knots))$y)
    refs[[i]] <- ref
  }
  final_ref <- rbindlist(refs)
  add_simulations_new(
    quantiles = x$quantiles,
    knots = x$knots,
    min_listings = x$min_listings,
    response = x$response,
    ref_dt = final_ref,
    trained = TRUE
  )
}

bake.add_simulations <- function(object, newdata, ...) {
asking_copy <- newdata[asking()]
asking_copy[, rounded_age := round(age, 0)]
asking_copy[asking() & eval_type == "auction", `:=`(data_type = "auction")]
asking_copy[asking() & eval_type == "retail", `:=`(data_type = "aftersale")]
asking_copy <- merge(asking_copy, object$ref_dt[, c("data_type", "rounded_age", "markdown")],
                 by = c("data_type", "rounded_age"))
asking_copy[, rounded_age := NULL]
asking_copy[, data_type := "simulated"]
asking_copy[, (object$response) := usd_list_price * markdown]
asking_copy[,`:=`(.count = .N), by = c("eval_type", "make_model")]
asking_copy <- asking_copy[.count > 5 |
                             (make_model %in% newdata[auction(), "make_model", with = FALSE]$make_model &
                                eval_type == 'auction') |
                             (make_model %in% newdata[aftersale(), "make_model", with = FALSE]$make_model &
                                eval_type == "retail")]
if (interactive()) {
message(glue("Added {nrow(asking_copy[eval_type == 'auction'])} to auction, and {nrow(asking_copy[eval_type == 'retail'])} to aftersale."))
}
asking_copy[, .count := NULL]
rbind(newdata, asking_copy, fill = TRUE, use.names = TRUE)
}