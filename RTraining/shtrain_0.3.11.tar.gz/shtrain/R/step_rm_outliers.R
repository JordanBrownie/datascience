#' Remove outliers by absolute error
#'
#' `step_rm_outliers` creates a *specification* of a recipe step that will remove
#' listings whose evaluations are outliers.
#' @inheritParams step_basic
#' @param formula A formula.
#' @param iter Number of times to fit the model and remove outliers.
#' @param by Character column name to group the model fit by.
#' @export
#' @details
#' * Step: Nothing.
#' * Prep: Nothing
#' * Bake: Fit model and remove outliers by group based on `by`.
step_rm_outliers <- function(recipe, formula, iter = 1, by = NULL, trained = FALSE) {
  add_step(recipe,
           step_rm_outliers_new(
             formula = formula,
             iter = iter,
             by = by,
             trained = trained
           ))
}
#' Removes outliers based on predicted values
#'
#' Removes outliers by fitting model to data and removing those whose predictions
#'  are too far off.
#'
#' @param data The data to be reduced.
#' @param model A \code{glm} model.
#' @param iter Defaults to 1 if not supplied. Enter 0 to skip.
#' @param by Column name as `character` to group the model fit by.
#'
#' @return Returns reduced \code{dframe}.
#' @export
#'
#' @include internal-get.R
#' @importFrom stats quantile glm IQR

rm_outliers <- function(data, model, iter = 1, by = NULL) {
  if (iter > 0) {
    formula <- get_formula(model)
    response <- get_response(model)
  }
  if (!is.null(by)) {
    grps <- data[, list(.I, .GRP), by = by]
    subsets <- lapply(seq_len(max(grps[["GRP"]])), function(x) grps[GRP == x, I])
  } else {
    subsets <- list(seq_len(nrow(data)))
  }
  data_list <- lapply(subsets, function(x) data[x,])
  for (k in seq_along(data_list)) {
      for (i in seq_len(iter)) {
    fit <- glm(formula = formula, data = data_list[[k]], family = "gaussian")
    pred <- predict_safely(fit, data_list[[k]])
    diff <- pred - data_list[[k]][[response]]
    data_list[[k]] <- data_list[[k]][(diff > quantile(diff, probs = 0.25, na.rm = TRUE) - 1.5 *
                         IQR(diff, na.rm = TRUE) &
                         diff < quantile(diff, probs = 0.75, na.rm = TRUE) + 1.5 *
                         IQR(diff, na.rm = TRUE)) | is.na(pred)]
      }
    data <- rbindlist(data_list)
  }
data
}

step_rm_outliers_new <- function(formula, iter = 1, by = NULL, trained = FALSE) {
  step(subclass = "rm_outliers",
       formula = formula,
       iter = iter,
       by = by,
       trained = trained)
}


prep.step_rm_outliers <- function(x, training, ...) {
  step_rm_outliers_new(
    formula = x$formula,
    iter = x$iter,
    by = x$by,
    trained = TRUE
  )
}

#' @include internal-get.R
#' @importFrom stats quantile glm IQR
bake.step_rm_outliers <- function(object, newdata, ...) {
  if (object$iter > 0) {
    formula <- get_formula(object$formula)
    response <- get_response(object$formula)
  }
  if (!is.null(object$by)) {
    grps <- newdata[, list(.I, .GRP), by = eval(object$by)]
    subsets <- lapply(seq_len(max(grps[["GRP"]])), function(x) grps[GRP == x, I])
  } else {
    subsets <- list(seq_len(nrow(newdata)))
  }
  newdata_list <- lapply(subsets, function(x) newdata[x,])
  for (k in seq_along(newdata_list)) {
    for (i in seq_len(object$iter)) {
      fit <- glm(formula = formula, data = newdata_list[[k]], family = "gaussian")
      pred <- predict_safely(fit, newdata_list[[k]])
      diff <- pred - newdata_list[[k]][[response]]
      newdata_list[[k]] <- newdata_list[[k]][(diff > quantile(diff, probs = 0.25, na.rm = TRUE) - 1.5 *
                                          IQR(diff, na.rm = TRUE) &
                                          diff < quantile(diff, probs = 0.75, na.rm = TRUE) + 1.5 *
                                          IQR(diff, na.rm = TRUE)) | is.na(pred)]
    }
    newdata <- rbindlist(newdata_list)
  }
  newdata
}