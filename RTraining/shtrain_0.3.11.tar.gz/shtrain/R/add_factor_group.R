#' Create factor group based on a factor
#'
#' `add_factor_group` creates a *specification* of a recipe step that will
#'   add a new column by grouping values of a variable together.
#' @inheritParams step_basic
#' @param factor Factor to group by. Despite name of the argument, generally represented
#' as a character column.
#' @param groupings Named list of the form `list(lname = c(oldlevel1, oldlevel2), lname2...)`
#' @param other Logical. Add an 'other' group, where all listings with `factor` filled in but lacking a
#'   `factor_group` will receive `factor_group = "other"`
#' @param new Name of new column. Defaults to `paste0(factor, "_group")`.
#' @inherit step_basic return
#' @export
#' @details
#' * Step: None
#' * Prep: Computes `new` if not set. Calls [cache_dependency()], which ensures
#' error messages refer to the "source" (`factor` argument) variable.
#' * Bake: Adds `factor_group` column based on groupings provided.
add_factor_group <- function(recipe, factor, groupings, other, new = NA, trained = FALSE) {
  add_step(recipe,
           add_factor_group_new(
             factor = factor,
             groupings = groupings,
             other = other,
             new = new,
             trained = trained
           ))
}

add_factor_group_new <- function(factor, groupings, other, new = NA, trained = FALSE) {
  add(subclass = "factor_group",
      factor = factor,
      groupings = groupings,
      other = other,
      new = new,
      trained = trained
  )
}

prep.add_factor_group <- function(x, training, ...) {
  if (is.na(x$new)) {
    x$new <- paste0(x$factor, "_group")
  }
  cache_dependency(source = x$factor, derived = x$new)
add_factor_group_new(factor = x$factor,
                      groupings = x$groupings,
                      other = x$other,
                      new = x$new,
                      trained = TRUE)
}

bake.add_factor_group <- function(object, newdata, ...) {
  .create_factor_group(data = newdata, factor = object$factor, groupings = object$groupings, other = object$other, new = object$new)
}

summary.add_factor_group <- function(x, ...) {
  old <- x$factor
  new <- x$new
  groups <- c(names(x$groupings), ifelse(isTRUE(x$other), "other", NULL))
  n_levels <- c(lengths(x$groupings), ifelse(isTRUE(x$other), NA_real_, NULL))
  data.table(source = old,
             derived = new,
             new_level = groups,
             old_levels = n_levels)
}

#' @describeIn add_factor_group Non-recipe version.
#' @export
#'
#' @include internal-get.R
#' @importFrom data.table is.data.table
#' @importFrom stringr str_detect str_c
.create_factor_group <- function(data, factor, groupings, other, new = NA) {
  stopifnot(is.data.table(data),
            is.character(factor),
            is.list(groupings)
  )
  data <- copy(data)
  new_levels <- names(groupings)
  old_levels <- groupings
  if (is.na(new)) {
    new_factor <- get_group_name(factor)
  } else {
    new_factor <- new
  }
  set(x = data,
      i = NULL,
      j = new_factor,
      value = NA_character_)
  index <- vector(mode = "list", length = length(new_levels))
  names(index) <- new_levels
  old_factor <- data[[factor]]
  for (i in new_levels) {
    matches <- str_c("(^", str_c(old_levels[[i]], sep = "$)|(^"), "$)", collapse = "")
    index[[i]] <- str_which(matches, old_factor)
    set(x = data,
        i = index[[i]],
        j = new_factor,
        value = i)
  }
  unassigned_levels <- unique(data[is.na(new_factor), factor, with = FALSE])
  if (other == TRUE) {
    other <- which(!is.na(old_factor) & is.na(data[[new_factor]]))
    set(x = data,
        i = other,
        j = new_factor,
        value = "other")
  }
  data
}