#' Change names between R and SQL
#'
#' Changes names between R and SQL, according to the values
#' cached using [cache_names()]. Names not cached are left untouched.
#' @param names Character vector of names. If `length(names) == 0`, `character(0L)`
#' is returned.
#' @param from Current state of the names.
#' @param ref Defaults to `shref$name_cache`. Can pass a separate table
#' with columns "r" and "sql" to use instead.
#' @export
#' @family naming functions
#' @importFrom stats na.omit
change_names <- function(names = NULL, from = NULL, ref = NULL){
  # Return early if no names are passed in. Prevents annoying warnings.
  if (length(names) == 0) {
    return(character(0L))
  }
  if (is.null(ref)) {
    ref <- shref$name_cache
  }

  to <- setdiff(c("r", "sql"), from)
  current_names <- names
  current_names <- current_names[!is.na(current_names)]
  new_names <- current_names
  from_matched <- match(new_names, ref[[from]])
  has_to_match <- which(!is.na(from_matched) & !is.na(ref[[to]][from_matched]))
  new_names[has_to_match] <- na.omit(ref[[to]][from_matched])

  new_names[!is.na(new_names)]

}

#' Change names to R format
#'
#' Updates the names of a `data.table` by reference. This means you __DO NOT__ need
#' to assign the results back.
#' @param data A [data.table::data.table()].
#' @return Returns the input data invisibly.
#' @family naming functions
#' @export
set_r_names <- function(data) {
  onames <- names(data)
  setnames(data, old = onames, new = change_names(onames, from = "sql"))
  invisible(data)
}

#' Change names to SQL format
#'
#' Updates the names of a `data.table` by reference. This means you __DO NOT__ need
#' to assign the results back.
#' @param data A [data.table::data.table()].
#' @return Returns the input data invisibly.
#' @export
set_sql_names <- function(data) {
  onames <- names(data)
  setnames(data, old = onames, new = change_names(onames, from = "r"))
  invisible(data)
}


#' Updates name cache
#'
#' Writes to a table which links R and SQL names together. R and SQL names
#'   cannot be cached if they are the same.
#'   This table is referenced in `change_names`. If a name isn't present in the cache,
#'   the column name will not be changed. If a name is cached multiple times, only the
#'   last cache is retained.
#' @param r Vector of R names.
#' @param sql Vector of SQL names.
#'
#' @export
#' @examples
#' \dontrun{
#' # Reset the name cache
#' shtrain:::shref$name_cache <- data.frame(r = character(), sql = character(),
#' stringsAsFactors = FALSE)
#' }
#' @importFrom data.table data.table
cache_names <- function(r, sql) {
  stopifnot(length(r) == length(sql))
  has_sql <- which(r != sql)
  r <- r[has_sql]
  sql <- sql[has_sql]
  dt <- data.table(r = r, sql = sql)
  shref$name_cache <- rbind(shref$name_cache,
                            dt)
  shref$name_cache <- shref$name_cache[!duplicated(shref$name_cache[,"r"], fromLast = TRUE),]
  invisible(shref$name_cache)
}

#' Fixes dynamically populated view spec names
#'
#' By "fix", we mean reconciling the snake case representation
#' sans prefix to match the static view name or dynamic name if it exists.
#' A message will inform you if anything is changed, and the
#' change will be cached in the name table.
#' @param data A `data.table`. Updated by reference, does not
#' need to be assigned back to a variable name.
#' @return Returns `data` invisibly.
#' @export
#' @importFrom stringr str_replace_all str_c
#' @importFrom data.table setnames
#' @importFrom glue glue
reconcile_names <- function(data) {
  x <- names(data)
  start_sup <- x[startsWith(x, "sup_")]
  names(start_sup) <- str_replace_all(start_sup, "sup_", "")
  start_def <- x[startsWith(x, "def_")]
  names(start_def) <- str_replace_all(start_def, "def_", "")
  sup <- rm_prefix(start_sup, "sup_")
  def <- rm_prefix(start_def, "def_")
  fixed <- x[!startsWith(x, "def_") & !startsWith(x, "sup_")]
  names(fixed) <- str_replace_all(fixed, "_", "")
  if (length(sup) > 0) {
    names(sup) <- str_replace_all(sup, "_", "")
    sup_overlap <- intersect(names(sup), names(fixed))
    start_sup <- start_sup[sup_overlap]
    sup_fixed <- fixed[sup_overlap]
    sup <- sup[sup_overlap]
    not_matched <- names(sup)[sup != sup_fixed]
    start_sup <- start_sup[not_matched]
    sup[not_matched] <- sup_fixed[not_matched]
    if (length(sup[not_matched]) > 0) {
      end_sup <- str_c("sup_", sup[not_matched])
      if (interactive()) {
      message(glue("Correcting {start_sup} to {end_sup}.", .sep = "\n"))
      }
      setnames(data, old = start_sup , new = end_sup)
      cache_names(r = end_sup, sql = str_c("SUP_", name_table[name_table$r == sup[not_matched], "sql", drop = TRUE]))
    }
  }
  if (length(def) > 0) {
    names(def) <- str_replace_all(def, "_", "")
    def_overlap <- intersect(names(def), names(fixed))
    def_fixed <- fixed[def_overlap]
    def <- def[def_overlap]
    start_def <- start_def[def_overlap]
    not_matched <- names(def)[def != def_fixed]
    start_def <- start_def[not_matched]
    def[not_matched] <- def_fixed[not_matched]
    if (length(def[not_matched]) > 0) {
      end_def <- str_c("def_", def_fixed[not_matched])
      if (interactive()) {
      message(glue("Correcting {start_def} to {end_def}.", .sep = "\n"))
      }
      setnames(data, old = start_def, new = end_def)
      cache_names(r = end_def, sql = str_c("DEF_", name_table[name_table$r == def[not_matched], "sql", drop = TRUE]))
    }
  }
  invisible(data)
}

