#' Scales and/or reformats dimension specs to be numeric and in the correct base unit.
#'
#' `step_dimensions` is a *specification* of a recipe step
#' which will reformat if necessary and scale to the correct base unit any dimension specs that should be numeric.
#' @inheritParams step_basic
#' @inheritParams cleanse_numerics
#' @details
#'
#' Uses different regex calls to parse out the relevant numerics and remove any
#' labeling or bad entry. Currently only reformats for feet and inches.  The
#' regex can handle labels like ft in \' \" or combinations of the two.  The
#' regex will pull the first set of numbers within a range and will clear out
#' bad entry such as words or actual dimensions (4X2).  The function will handle
#' decimals and commas but could have issues with fractions (1/2).  Any values
#' that are already in the correct numeric format will be scaled to the correct
#' base unit using the `cleanse_numerics` function.
#'
#' For values that must be reformatted, the unit numerics and base unit numerics
#' are parsed out with regex and any unit value that is strictly lower than the
#' unit bound value are subsetted and any unit values that are greater than or
#' equal to the unit bound are added to the subset of base unit values.  Then
#' the unit subset is scaled using the measurement table and added to the
#' corresponding base unit subset. For correctly formatted values, any value
#' strictly lower than the bound for the unit value supplied will be scaled to
#' the base unit. Any value strictly higher than the bound for the base unit
#' value supplied will be scaled down, as the entered value was most likely
#' scaled correctly initially but given the wrong unit label and scaled again.
#'
#' * Step: Captures relevant information in order to reformat and/or scale the
#' column appropriately.
#' * Prep: Queries and stores the measurement table
#' * Bake: Reformats if necessary and scales column to the base unit that is stored in database for the spec.
#' @export
#' @import stringr
#' @importFrom data.table copy set
#' @importFrom RODBC odbcClose sqlQuery
#' @importFrom data.table is.data.table
#' @importFrom rlang is_named
#' @include helper_numerics.R
step_dimensions <- function(recipe, col, unit = c(label = NA), base_unit = c(label = NA), trained = FALSE, measurements =  NULL) {
  add_step(recipe, step_dimensions_new(
    col = col,
    unit = unit,
    base_unit = base_unit,
    trained = trained,
    measurements = measurements
  ))
}

step_dimensions_new <- function(col, unit = c(label = NA), base_unit = c(label = NA), trained = FALSE, measurements = NULL) {
  step(subclass = 'dimensions',
       col = col,
       unit = unit,
       base_unit = base_unit,
       trained = trained,
       measurements = measurements)
}

prep.step_dimensions <- function(x, training, ...) {
  nu <- tolower(names(x$unit))
  nbu <- tolower(names(x$base_unit))
  dbhandle <- shtrain:::create_server_connection()
  on.exit(odbcClose(dbhandle))
  stopifnot(is.data.table(training), is_named(x$unit), is_named(x$base_unit))
  measurements <- sqlQuery(dbhandle,"SELECT Unit AS unit, BaseUnit AS base_unit, MultiplyBy AS multiply_by, UnitGroup AS unit_group
                           FROM dbMMM.dbo.MeasurementUnit MU(NOLOCK)
                           WHERE UnitGroup = 'Length';",
                           stringsAsFactors = FALSE)
  measurements <- measurements[measurements$base_unit == nbu & measurements$unit == nu,]
  step_dimensions_new(col = x$col,
                          unit = x$unit,
                          base_unit = x$base_unit,
                          trained = TRUE,
                          measurements = measurements)
}

bake.step_dimensions <- function(object, newdata, ... ) {
  if (!can_be_numeric(newdata[[object$col]]) ) {
    # Create these as vectors instead of columns of the dataframe. This way we do not have to remove them.
    ##Specifically for UnitGroup of Length
    #creates vector for numeric unit values
    num <- suppressWarnings(as.numeric(str_extract(newdata[[object$col]], "^[0-9]{1,4}\\.?\\d{1,2}?|^\\d{1}\\.?\\d{0,2}")))
    #Pulls out the next 3 relevant digits as BaseUnit value
    bu <-  suppressWarnings(as.numeric(str_extract(newdata[[object$col]], "(?<!\\-\\d{1,2}')(\\d{1,3})(?=\")")))
    lt_lower <- which(num < object$unit)
    # Creates vector of 0's
    u <- double(length = length(newdata[[object$col]]))
    u[lt_lower] <- num[lt_lower]
    #Places values that are greater than first cutoff in baseUnit column
    gt_lower <- which(num >= object$unit)
    bu[gt_lower] <- num[gt_lower]
    bu[is.na(bu)] <- 0
    #Converts value to relevant BaseUnit
    set(x = newdata,
        i = NULL,
        j = object$col,
        value = u*object$measurements[, "multiply_by"] + bu)
    set(x = newdata,
        i = which(newdata[[object$col]] == 0),
        j = object$col,
        value = NA_real_)
}
cleanse_numerics(data = newdata, col = object$col, unit = object$unit, base_unit = object$base_unit, measurements = object$measurements)

}

