#' Retrieve preliminary variable counts from SQL
#'
#' Provides counts for the top five most frequent values for each variable in the table,
#' or for the selections provided.
#'
#' @param con  Connection.
#' @param category_id Single category ID.
#' @param type 'auction', 'asking', 'aftersale', 'supplemental', 'dynamic', 'default'.
#' @export
#' @family querying functions
#' @include internal-get.R
#' @importFrom glue glue
#' @importFrom RODBC sqlQuery sqlColumns
sql_counts <- function(con, type, category_id, selections = NULL) {
  tbl <- get_table_name(category_id = category_id, type = type)
  base_type <- ifelse(type %in% c("auction", "asking", "aftersale"), TRUE, FALSE)
  if (is.null(selections)) {
    column_names <- sqlColumns(con, sqtable = tbl)$COLUMN_NAME
  } else {
  selections <- expand_selections(selections, type = type)
  }
  cat_statement <- ""
  if (base_type == TRUE) {
    cat_statement <- glue(" where {if(type == 'aftersale') 'CategoryID' else 'ObjectCategoryID'} = {category_id} ")
    if (!is.null(selections)) {
    column_names <- translate_names(names = selections, from = "r", to = type)
    column_names <- intersect(column_names, shdata$name_table[[type]])
    }
  } else {
    if (!is.null(selections)) {
      if (selections != "*") {
      column_names <- translate_names(names = selections, from = "r", to = type)
      } else {
        column_names <- sqlColumns(con, sqtable = tbl)$COLUMN_NAME
      }
    }
  }
counts <- sqlQuery(con, paste0("SELECT '' as variable, 'Listings' as value, COUNT(*) as frequency from ", tbl, " (NOLOCK) ", cat_statement, "UNION ", collapse(glue("
                                      (SELECT TOP 5 '{column_names}' as variable, CAST({column_names} AS NVARCHAR(50)) as value, COUNT(*) as frequency from {tbl} (NOLOCK)
                                      {cat_statement}
                                       GROUP BY {column_names})
                                      "), sep = ' UNION  '), " order by variable, frequency desc"),
                            stringsAsFactors = FALSE)

counts[["variable"]] <- translate_names(names = counts[["variable"]], from = type, to = "r")
counts
}

