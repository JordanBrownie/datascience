#' Adds make_model and make_model_group
#'
#' `add_make_model` creates a *specification* of a recipe step that will
#' construct the make_model and make_model_group columns.
#'
#' @inheritParams step_basic

#' @inherit step_basic return
#' @export
#' @details
#' * Step: Nothing
#' * Prep: Nothing
#' * Bake: Adds `make_model` and `make_model_group`
add_make_model <- function(recipe, trained = FALSE) {
  add_step(recipe,
           add_make_model_new(
             trained = trained))
}


add_make_model_new <- function(trained = FALSE) {
  add(subclass = "make_model",
      trained = trained)
}

prep.add_make_model <- function(x, training, ...) {
      # cache_dependency("make_model" = "make_model")
  cache_names(r = "make_model", sql = "MakeModel")
  cache_names(r = "make_model_group", sql = "MakeModelGroup")
    cache_dependency("make_model_group" = "make_model")
add_make_model_new(trained = TRUE)

}

#' @importFrom stringr str_to_lower str_c str_trim
bake.add_make_model <- function(object, newdata, ...) {
    mm_val <- str_c(newdata$manufacturer, " ", newdata$model)
    mmg_val <- str_c(newdata$manufacturer, " ", newdata$model_group)
    set(newdata, j = "make_model", value = mm_val)
    set(newdata, j = "make_model_group", value = mmg_val)

  newdata
}


#' @describeIn add_make_model Non-recipe version.
#' @importFrom data.table set
#' @importFrom stringr str_trim str_to_lower str_c
#' @export
.add_make_model <- function(data) {
  data <- copy(data)
  if (get_base_category_id(data = data) != 28) {
    manufacturer <- str_trim(data$manufacturer)
    mm_val <- str_to_lower(str_c(manufacturer, " ", str_trim(data$model)))
    mmg_val <- str_to_lower(str_c(manufacturer, " ", str_trim(data$model_group)))
    set(data, j = "make_model", value = mm_val)
    set(data, j = "make_model_group", value = mmg_val)
    # cache_dependency("make_model" = "make_model")
    cache_dependency("make_model_group" = "make_model")

  }
  data
}