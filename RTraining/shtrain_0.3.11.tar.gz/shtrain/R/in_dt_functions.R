#' Metrics for use in data.table
#'
#' These functions are meant to be used inside
#' the `[.data.table` operator in the `j`-slot.
#' Note they also work if given 2 numeric vectors.
#' See examples.
#' @param pred Name containing the predictions or a numeric vector.
#' @param value Name containing the actual value or a numeric vector.
#' @name dt_functions
#' @examples
#' dt_we(1:5, 1:5+0.1)
#' dt_fe(5:1, 1:5)
#' dt_mae(1:5, 2:6)
#' \dontrun{
#' library(data.table)
#' set.seed(702)
#' dt <- data.table(usd_sale_price = 25000+rnorm(10, 0, 500),
#'                  evaluation = 25000+rnorm(10, 0, 500))
#' dt[, dt_we(evaluation, usd_sale_price)]
#' dt[, .(weighted_error = dt_we(evaluation, usd_sale_price),
#'        fleet_error = dt_fe(evaluation, usd_sale_price))]
#' }
NULL

#' @export
#' @rdname dt_functions
dt_we <- function(pred, value) {
  stopifnot(length(pred) == length(value))
  both <- !is.na(pred) & !is.na(value)
  pred <- pred[both]
  value <- value[both]
  sum(abs(pred - value))/sum(value)

}
#' @export
#' @rdname dt_functions
dt_fe <- function(pred, value) {
  stopifnot(length(pred) == length(value))
  both <- !is.na(pred) & !is.na(value)
  pred <- pred[both]
  value <- value[both]
  1 - sum(pred)/sum(value)
}
#' @export
#' @rdname dt_functions
dt_mae <- function(pred, value) {
  stopifnot(length(pred) == length(value))
  both <- !is.na(pred) & !is.na(value)
  pred <- pred[both]
  value <- value[both]
  mean(abs(pred - value))
}
#' @export
#' @rdname dt_functions
dt_qae <- function(pred, value, probs = c(0.05, 0.25, 0.5, 0.75, 0.95)) {
  stopifnot(length(pred) == length(value))
  both <- !is.na(pred) & !is.na(value)
  pred <- pred[both]
  value <- value[both]
  quantile(abs(pred - value), probs = probs)
}