
#' Apply custom function to data
#'
#'   __Deprecated__ Do not use this function. Use [step_dt()], or write your own
#'   step to export using [copy_package()].
#' This function will be removed in future versions.
#' @inheritParams step_basic
#' @param fun string giving function name. Must have `data` as an argument and return the data.
#' @param options named list of arguments.
#' @inherit step_basic return
#' @export
#' @seealso step_transform
#' @details
#'  Step: None
#'  Prep: Capture function definition
#'  Bake: Apply function.
step_raw <- function(recipe, fun, options, trained = FALSE) {
  add_step(recipe,
           step_raw_new(
             trained = trained,
             fun = fun,
             options = options)
  )
}


step_raw_new <- function(fun, options, trained = FALSE) {
  step(subclass = "raw",
       fun = fun,
       options = options,
       trained = trained)
}

#' @export
prep.step_raw <- function(x, training, ...) {
  fun <- match.fun(x$fun)
  attr(fun, "srcref") <- NULL
  step_raw_new(
    trained = TRUE,
    fun = fun,
    options = x$options
  )

}
#' @export
bake.step_raw <- function(object, newdata, ...) {
  options <- c(list(data = newdata), object$options)
  newdata <- do.call(object$fun, args = options)
  invisible(newdata)
}
