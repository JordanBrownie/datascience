step_replace_na_new <- function(replace = NULL, with, trained = FALSE) {
  step(subclass = "replace_na",
       replace = replace,
       with = with,
       trained = trained)
}
#' Replace NA values in one column with non-NA in another.
#'
#' `step_replace_na` creates a *specification* of a recipe step that will
#'   will replace NA values in one column with non-NA values in another.
#' @inheritParams step_basic
#' @param replace A vector of specs to replace. If not provided, strips away 'sup_' or 'def_' from `with`.
#' @param with A vector of specs to use for replacement. Alternatively, a prefix: "def_", "sup_", or "imp_".
#' If a prefix, it will replace all corresponding NA base specs with the prefix value.
#' @inherit step_basic return
#' @export
#' @seealso step_replace
#' @family training steps
#' @family testing steps
#' @family steps
#' @details
#'  Step:  Nothing
#'  Prep:  Populates `with` and `replace` according to above.
#'  Bake:  Replaces NA values in `replace` with non-NA values in `with`.
step_replace_na <- function(recipe, replace = NULL, with, trained = FALSE) {
  add_step(recipe,
           step_replace_na_new(
             replace = replace,
             with = with,
             trained = trained
           ))
}


prep.step_replace_na <- function(x, training, ...) {
  if (all(x$with %in% c("def_", "sup_", "imp_"))) {
    if (!is.null(x$replace)) stop("You provided a prefix in `with`. You must not provide `replace`.")
    replacements <- find_replacement(names(training), x$with)
    if (length(replacements) > 0) {
    replace <- names(replacements)
    with <- unname(replacements)
    } else {
      replace <- NA_character_
      with <- x$with
    }
  } else {
    if (is.null(x$replace)) {
      replace <- gsub("def_|sup_|imp_", "", x$with)
    } else {
      replace <- x$replace
    }
    with <- x$with
    }
  step_replace_na_new(
    replace = replace,
    with = with,
    trained = TRUE
  )
  }

bake.step_replace_na <- function(object, newdata, ...) {
  if (all(!is.na(object$replace))) {
    replace_na(data = newdata, with = object$with, replace = object$replace)
  } else {
    if (interactive()) message("No replacements for ", paste0(object$with, "specs."), call. = FALSE)
    newdata
  }
}

summary.step_replace_na <- function(x, ...) {
  if (is.null(x$replace)) {
    x$replace <- gsub("def_|sup_|imp_", "", x$with)
  }
  data.table(replace_missing = x$replace, with = x$with)
}

#' Replace a column with another's values
#'
#' `step_replace` creates a *specification* of a recipe step that will
#'   replace values in one column with non-NA values in another.
#' @inheritParams step_basic
#' @inheritParams step_replace_na
#' @inherit step_basic return
#' @export
#' @seealso step_replace_na
#' @details
#'  Step: Nothing
#'  Prep: Populates `with` and `replace` according to above.
#'  Bake: Overwrite `replace` specs with non-NA `with` specs.
step_replace <- function(recipe, replace = NULL, with, trained = FALSE) {
  add_step(recipe,
           step_replace_new(
             replace = replace,
             with = with,
             trained = trained
           ))
}

step_replace_new <- function(replace = NULL, with, trained = FALSE) {
  step(subclass = "replace",
       replace = replace,
       with = with,
       trained = trained)
}

prep.step_replace <- function(x, training, ...) {
  if (all(x$with %in% c("def_", "sup_", "imp_"))) {
    if (!is.null(x$replace)) stop("You provided a prefix in `with`. You must not provide replace.")
    replacements <- find_replacement(names(training), x$with)
    if (length(replacements) > 0) {
      replace <- names(replacements)
      with <- unname(replacements)
    } else {
      replace <- NA_character_
      with <- x$with
    }
  } else {
    if (is.null(x$replace)) {
      replace <- gsub("def_|sup_|imp_", "", x$with)
    } else {
      replace <- x$replace
    }
    with <- x$with
  }
  step_replace_new(
    replace = replace,
    with = with,
    trained = TRUE
  )
}

bake.step_replace <- function(object, newdata, ...) {
  if (all(!is.na(object$replace))) {
    replace(data = newdata, with = object$with, replace = object$replace)
  } else {
    if (interactive()) warning("No replacements for", paste0(object$with, "specs"))
    newdata
  }
}


summary.step_replace <- function(x, ...) {
  if (is.null(x$replace)) {
    x$replace <- gsub("def_|sup_|imp_", "", x$with)
  }
  data.table(overwrite = x$replace, with_non_na = x$with)
}






#' Replaces NAs with another column's value
#'
#' Replaces NAs in specs. Provided with dynamic, default,
#'  supplemental, or imputed specs, NA values will be replaced in the corresponding
#'  dealer-entered spec. Specifying `replace` allows for more flexibility.
#'  You can replace multiple variables at once. See examples.
#'
#' @param data Data.
#' @param with Specs to replace NA values with. If a prefixed variable and replace
#'   is not provided, the prefix will be removed to generate replace.
#' @param replace Defaults to `with` sans prefix.
#' @export
#' @examples \dontrun{
#'   #replaces na values in hours and capacity
#'   replace_na(data, with = c("sup_hours", "sup_capacity"))
#'   # replace na default capacities with supplemental capacities.
#'   replace_na(data, replace = "def_capacity", with = "sup_capacity")
#' }
#' @importFrom data.table copy set
#' @seealso replace
replace_na <- function(data, with, replace = NULL) {
  stopifnot(
    is.data.frame(data),
    is.character(with),
    is.null(replace) || is.character(replace)
  )
  if (is.null(replace)) {
    replace <- gsub("sup_|def_|imp_", "", with, ignore.case = TRUE)
  }
  # Get indices for each spec to replace
  ind <- seq_along(replace)
  i_set <- lapply(ind, function(x) which(is.na(data[[replace[x]]]) & !is.na(data[[with[x]]])))
  names(i_set) <- with
  # Remove ones which are completely filled in.
  i_set <- i_set[lengths(i_set) > 0]
  # Get the index for replace.
  match <- replace[match(names(i_set),with)]
  # Replace rows in 'replace' column with 'with' for the set where 'replace' is missing
  for (k in seq_along(i_set)) {
    set(data, i = i_set[[k]], j = match[k], value = data[[names(i_set)[k]]][i_set[[k]]])
    dt_add_message(data, i_set[[k]], str_c(" Used:", names(i_set)[k], sep = " "))
  }
  data
}

#' Replace dealer-entered specs with non-NA extended specs
#'
#'
#' Replace all dealer-entered specs with corresponding non-NA default,
#'  dynamic, supplemental, or imputed specs.
#'
#' @inheritParams replace_na
#'
#' @export
#' @importFrom data.table set copy
#' @seealso replace_na
replace <- function(data, with, replace = NULL) {
  stopifnot(
    is.data.frame(data),
    is.character(with),
    is.character(replace) | is.null(replace)
  )
  if (is.null(replace)) {
    replace <- gsub("sup_|def_|dyn_|imp_", "", with, ignore.case = TRUE)
  }
  # Get indices to replace for each spec.
  ind <- seq_along(with)
  i_set <- lapply(with, function(x) which(!is.na(data[[with]])))
  names(i_set) <- replace
  # Remove specs which are completely filled in
  i_set <- i_set[lengths(i_set) > 0]
  # Get the index for with
  match <- with[match(names(i_set), replace)]
  # Replace rows in 'replace' column with 'with' for the set where 'replace' is not missing.
  for (k in seq_along(i_set)) {
    set(data, i = i_set[[k]], j = names(i_set)[k], value = data[[match[k]]][i_set[[k]]])
    dt_add_message(data, i_set[[k]], str_c(" Used:", names(i_set)[k], sep = " "))
  }
  data
}
