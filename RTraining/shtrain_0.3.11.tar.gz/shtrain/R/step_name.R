#' Convert names from R to SQL, or vice-versa
#'
#' `step_name` creates a *specification* of a recipe step that will
#'   convert names of the variables to the appropriate standard. If
#'   a name doesn't have a match, remain unchanged.
#' @inheritParams step_basic
#' @param from 'r' or 'sql'
#' @param ref Populated on `prep`.
#' @inherit step_basic return
#' @export
#' @seealso change_names
#' @details
#'  Step: Checks that `from` is 'r' or 'sql.'
#'  Prep: Populates `ref` from `shref$name_cache`
#'  Bake: Changes names.
step_name <- function(recipe, from, ref = NULL, trained = FALSE) {
  stopifnot(from %in% c("r", "sql"))
  add_step(recipe,
           step_name_new(
             from = from,
             ref = ref,
             trained = trained
           ))
}

step_name_new <- function(from, ref = NULL, trained = FALSE) {
  step(subclass = "name",
       from = from,
       ref = ref,
       trained = trained)
}


prep.step_name <- function(x, training, ...) {
  ref <- shref$name_cache
  step_name_new(
    from = x$from,
    ref = ref,
    trained = TRUE
  )
}
#' @importFrom data.table setnames
bake.step_name <- function(object, newdata, ...) {
  setnames(newdata, change_names(names = names(newdata),
                                 from = object$from, ref = object$ref))
  newdata
}

summary.step_name <- function(x, ...) {
  x$ref
}