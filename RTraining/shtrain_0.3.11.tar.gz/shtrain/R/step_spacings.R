#' Reformats spacing specs to be numeric
#'
#' `step_spacings` is a *specification* of a recipe step
#' which will reformat any spacing specs that should be numeric.
#' @inheritParams step_basic
#' @param col Column that should be reformatted to be numeric.
#' @details
#'
#' Uses regex to parse out the relevant numerics and remove any labeling or bad entry.  The regex will correctly extract any numeric
#' values within 1-3 digits and any decimals.  Spacing specs are typically only recorded in the base unit and do not need to be scaled.
#'
#' * Step: Captures relevant information in order to reformat the column appropriately.
#' * Prep: Prepares data before reformatting.
#' * Bake: Reformats column to be a numeric spec.
#' @export
#' @import stringr
#' @importFrom data.table copy set
#' @importFrom RODBC odbcClose sqlQuery
#' @importFrom data.table is.data.table
step_spacings <- function(recipe, col, trained = FALSE){
  add_step(recipe, step_spacings_new(
    col = col,
    trained = trained
  ))
}

step_spacings_new <- function(col, trained = FALSE){
  step(subclass = 'spacings',
       col = col,
       trained = trained
  )
}

prep.step_spacings <- function(x, training, ...){
  stopifnot(is.data.table(training))
  step_spacings_new(col = x$col,
                        trained = TRUE
  )
}

bake.step_spacings <- function(object, newdata, ...){
  if (!can_be_numeric(newdata[[object$col]])) {
    #Replaces spec value with numeric values
    set(x = newdata,
        i = NULL,
        j = object$col,
        value = as.numeric(str_extract(newdata[[object$col]], "^\\d{1,2}\\.?\\d{1,3}"))
    )
  }
  newdata
}
