#' Retrieve R names for default, dynamic, and supplemental specs
#'
#' Given an `RODBC` connection and category ID, return a vector
#' of valid selections for the category.
#'
#' @param con Connection from [create_server_connection()].
#' @param category_id Single category ID.
#' @param raw Logical. If `TRUE`, return SQL names.
#' @param all Logical. if `TRUE`, return all columns. Default selections and
#' filter selections are excluded by default.
#' @return Character vector of available column names.
#' @family querying functions
#' @export
#' @importFrom RODBC sqlColumns sqlTables
#' @importFrom snakecase to_snake_case
sql_columns <- function(con,  category_id, raw = FALSE, all = FALSE) {
  stopifnot(length(category_id) == 1)
  industry <- get_industry(category_id = category_id)
  col_list <- list(auction = NULL,
                   aftersale = NULL,
                   asking = NULL,
                   dynamic = NULL,
                   supplemental = NULL,
                   default = NULL)
  valid_tbls <- tolower(sqlTables(channel = con)$TABLE_NAME)
  type <- c("auction", "aftersale", "asking", "dynamic", "supplemental", "default")
  for (i in seq_along(type)) {
    tbl <- get_table_name(category_id = category_id, type = type[i])
    if (tbl %in% valid_tbls) {
    col_list[[i]] <- sqlColumns(channel = con,  tbl)$COLUMN_NAME
      if (raw == FALSE) {
        col_list[[i]] <- translate_names(names = col_list[[i]], from = type[i], to = "r")
      }
      if (all == FALSE && i < 4) {
        col_list[[i]] <- setdiff(col_list[[i]], c(shdata$default_selection_table[[type[i]]],
                                                  shdata$filter_selections[[type[i]]]))
      }
    }
  }
col_list <- col_list[!vapply(col_list, is.null, FUN.VALUE = TRUE, USE.NAMES = FALSE)]
lapply(col_list, function(x) x[order(x)])
}


