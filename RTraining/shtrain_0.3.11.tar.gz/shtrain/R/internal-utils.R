################################ Renaming #####################################

#' Convert to SQL compatible names
#'
#' Performs name conversion to SQL compatible names for supplemental, dynamic,
#'  and default tables
#'
#' @param string String
#'
#' @param ... Arguments passed to \code{snakecase::to_any_case}
#'
#' @importFrom snakecase to_any_case
to_sql_case <- function(string, ...) {

  string <- to_any_case(string, case = "big_camel")
  gsub("^(Mmm|Def|Sup|Dyn|Val)", "\\U\\1_", string, perl = TRUE)
}


#' Change names to reflect appropriate environment
#'
#' Renames current dataframe based on matching names in \code{from} to the
#' corresponding names in \code{to}. Names with no matches are unmodified.
#'
#' @param data Dataframe.
#' @param to The desired reference for names.
#' @param from The current reference for names.
#' @param names A vector containing names for the data.
#'
#' @return Renamed dataframe. Any names not matched will be unmodified. If \code{names}
#'  is provided instead of \code{data}, a character vector containing the new names will
#'  be returned.
#' @aliases rename renaming
#' @rdname renaming
#' @importFrom stats na.omit
translate_names <- function(data = NULL, from, to, names = NULL) {
  if (!is.null(data) && !is.null(names)) {
    stop("Provide data or names, not both")
  }
  if (is.null(data) && !is.null(names)) {
    current_names <- names
  } else {
    current_names <- names(data)
  }
  if (any(c(to, from) %in% c("auction", "asking", "aftersale"))) {
    new_names <- current_names
    from_matched <- match(new_names, shdata$name_table[[from]])
    to_matched <- which(!is.na(from_matched) & !is.na(shdata$name_table[[to]][from_matched]))
    new_names[to_matched] <- na.omit(shdata$name_table[[to]][from_matched])
  } else if (to == "r" && (from %in% c("supplemental", "dynamic", "default"))) {
    new_names <- to_snake_case(current_names)
  } else if (from == "r" && (to %in% c("supplemental", "dynamic", "default"))) {
    new_names <- to_sql_case(current_names)
  }
  if (is.null(data) && !is.null(names)) {
    return(new_names)
  } else {
    names(data) <- new_names
  }
  data
}

#' Replace variable names in a string.
#'
#' @param x Vector of strings
#' @param from auction, aftersale, asking
#' @param to auction, aftersale, asking
#' @return Modified string
#' @family renaming
#' @rdname renaming
#' @aliases rename renaming
#' @importFrom stringr str_replace_all
translate_string <- function(x, from, to, matches) {
  if (!missing(to) && to %in% c("auction", "asking", "aftersale")) {
    matches <- shdata$name_table[[to]]
    names(matches) <- paste0(shdata$name_table[[from]], "[^_]")
    str_replace_all(x, paste0(matches))
  } else if (!missing(matches)) {
    names(matches) <- paste0(names(matches), "[^_]")
    str_replace_all(x, matches)
  } else {
    stop("If to is not a base type, matches must be supplied, with r_name = sql_name")
  }
}

name_check <- function(data, names, require = FALSE, has = TRUE) {
  d_names <- names(data)
  if (!all(names %in% d_names)) {
    missing <- setdiff(names, d_names)
    if (require == TRUE) {
      stop(glue::glue("{glue::collapse(missing, sep = ', ')} not present in `data`."), call. = FALSE)
    }
  }
  if (has == TRUE) {
    return(intersect(d_names, names))
  } else {
    return(setdiff(names, d_names))
  }
}

################################## Miscellaneous ###############################


#' @keywords internal
add_default <- function(arg, val) {
  if (is.null(arg)) {
    val
  } else {
    arg
  }
}

#' @keywords internal
#' @importFrom stats predict
predict_safely <- function(model, data) {
  predict(model, newdata = missing_levels_to_na(data = data, object = model))
}


lc <- function(x) {
  stringr::str_c(x, collapse = ', ')
}


brackify = function(x) {
  # arbitrary cutoff
  if (length(x) > 10L) x = c(x[1:6], '...')
  paste0("[",paste(x, collapse = ', '), "]")
}