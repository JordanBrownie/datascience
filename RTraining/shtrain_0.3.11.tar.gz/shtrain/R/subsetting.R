#' @title Convenient subsetting in `[.data.table`
#'
#' @description Subsets a  `data.table` to a particular data-set, which should
#'   be clear from the function name. Each function corresponds to a particular
#'   logical expression. If the logical expression cannot be determined for a
#'   row (it returns `NA`), `data.table` will treat it as `FALSE`, and not
#'   return the row.
#'
#' @return A logical index for use in \code{i} argument of `[.data.table`
#' @name subsetting
#' @importFrom data.table data.table
#' @examples \dontrun{
#' library(data.table)
#' dt <- data.table(rep(c("auction", "asking", "aftersale"), 5), x = 1:15)
#' dt[auction()]
#' dt[!auction()]
#' dt[auction() | asking()] # works, but should use dt[aftersale()] instead.
#' }
NULL

#' @export
#' @rdname subsetting
current_asking <- function() {
  evalq(data_type == "asking" & web_end_date > as.IDate(Sys.Date(), origin = "1753-01-01"), envir = parent.frame())
}

#' @export
#' @rdname subsetting
auction <- function() {
 evalq(data_type == "auction", envir = parent.frame())
}
#' @rdname subsetting
#' @export
asking <- function() {
 evalq(data_type == "asking", envir = parent.frame())
}
#' @export
#' @rdname subsetting
aftersale <- function() {
  evalq(data_type == "aftersale", envir = parent.frame())
}
