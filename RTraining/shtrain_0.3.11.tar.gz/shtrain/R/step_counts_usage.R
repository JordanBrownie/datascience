#' Extract numeric counts for certain text patterns
#'
#' `step_counts_usage` will parse common text patterns for a count
#' into the appropriate numeric representation. See details.
#' @inheritParams step_basic
#' @param col Column that should be reformatted to be numeric.
#' @details
#'
#' Uses different regex calls to parse out the relevant numerics and remove any approximations and bad entry. The regex can handle any
#' excess words (1000 bales) and will deal with ranges (5-7), commas (12,000), decimals (12.700), and "K" abbreviation (10K).
#'
#' * Step: Nothing.
#' * Prep: Verifies the given columns are in the data and of type `character`.
#' * Bake: Reformats column to a whole number.
#' @export
#' @family step functions
#' @family step_dimensions step_spacings
#' @import stringr
#' @importFrom data.table copy set
#' @importFrom data.table is.data.table
step_counts_usage <- function(recipe, col, trained = FALSE){
  add_step(recipe, step_counts_usage_new(
    col = col,
    trained = trained
  ))
}

step_counts_usage_new <- function(col, trained = FALSE){
  step(subclass = 'counts_usage',
                 col = col,
                 trained = trained
  )
}

prep.step_counts_usage <- function(x, training, ...){
  stopifnot(all(x$col %in% names(training)))
  stopifnot(all(vapply(x$col, is.character, FUN.VALUE = logical(1L))))
  step_counts_usage_new(col = x$col,
                        trained = TRUE)
}

bake.step_counts_usage <- function(object, newdata, ...){
  newdata <- copy(newdata)
  if (!can_be_numeric(newdata[[object$col]]) ) {
    # creates column for numeric values
    # Extracts simplified numbers (20k = 20,000)
    num <- as.numeric(str_extract(newdata[[object$col]], "(\\d+)(?=k)")) * 1000
    # Replaces ranges with end value
    num[is.na(num)] <- str_extract(newdata[[object$col]][is.na(num)], "(?<=\\d{1,9}-)(\\d+)")
    # comma/period fix
    num[is.na(num)] <- str_extract(newdata[[object$col]][is.na(num)], ("(\\d+\\.?,?\\d+)"))
    num <- as.numeric(str_replace(num, ",|\\.", ""))
    #Extracts Numeric values
    num[is.na(num)] <- str_extract(newdata[[object$col]][is.na(num)], "\\d+")
    set(x = newdata,
        i = NULL,
        j = object$col,
        value = as.numeric(num))
  } else {
    set(x = newdata,
        i = NULL,
        j = object$col,
        value = as.numeric(str_replace_all(newdata[[object$col]], ",", "")))
  }
  newdata
}
