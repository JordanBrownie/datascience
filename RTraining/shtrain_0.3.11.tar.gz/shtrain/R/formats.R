
# format_character --------------------------------------------------------



#' Formats strings consistently
#'
#' format_character creates a *specification* of a recipe step that will
#'   trim and lower (or upper) all character columns, and set "" to `NA_character`.
#' @inheritParams step_basic
#' @param lower Do you wish to lower?
#' @param col Populated on [prep()].
#' @inherit step_basic return
#' @export
#' @details
#' * Step: Nothing
#' * Prep: Determine which columns are of `class` "character".
#' * Bake: Trim, upper or lower, and set empty strings to `NA_character_`
format_character <- function(recipe, exclude = NULL, lower = TRUE, trained = FALSE, col = NULL) {
  add_step(recipe,
           format_character_new(
             exclude = exclude,
             lower = lower,
             trained = trained,
             col = col
           ))
}

format_character_new <- function(exclude = NULL, lower = TRUE, col = NULL, trained = FALSE) {
  format(subclass = "character",
         exclude = exclude,
         lower = lower,
         trained = trained,
         col = col)
}

prep.format_character <- function(x, training, ...) {
  char_cols <- which(sapply(training, is.character))
  col <- names(training)[char_cols]
  if (!is.null(x$exclude) && any(!x$exclude %in% names(training))) {
    not_present <- x$exclude[!x$exclude %in% names(training)]
    stop(glue("{lc(not_present) are not in the data at this point,
              so may not be excluded from character formatting."), call. = FALSE)
  }
  col <- setdiff(col, x$exclude)
  format_character_new(
    exclude = x$exclude,
    lower = x$lower,
    trained = TRUE,
    col
  )
  }

#' @importFrom stringr str_length str_trim str_to_lower
#' @importFrom data.table set
bake.format_character <- function(object, newdata, ...) {
  f <- if (object$lower == TRUE) {
    function(x) str_trim(str_to_lower(x))
  } else if (object$lower == FALSE) {
    function(x) str_trim(str_to_upper(x))
  }
  for (k in object$col) {
    set(x = newdata,
        i = NULL,
        j = k,
        value = f(newdata[[k]]))
  }
  empty <- lapply(newdata[,object$col, with = FALSE], function(x) which(str_length(x) == 0))
  empty <- empty[lengths(empty) > 0]
  empty <- empty[setdiff(names(empty),  c("required_fields", "invalid_data", "insufficient_data", "r_message"))]
  for (k in seq_along(empty)) {
    set(x = newdata,
        i = empty[[k]],
        j = names(empty)[k],
        value = NA_character_)
  }
  newdata
}

#' @describeIn format_character Non-recipe version.
#' @importFrom data.table .SD  ':='
#' @importFrom stringr str_trim str_to_lower str_to_upper
#' @export
.format_character <- function(data, lower = TRUE) {
  data <- copy(data)
  f <- if (lower == TRUE) {
    function(x) str_trim(str_to_lower(x))
  } else if (lower == FALSE) {
    function(x) str_trim(str_to_upper(x))
  }
  char_cols <- which(sapply(data, is.character))
  for (k in char_cols) {
    set(x = data,
        i = NULL,
        j = k,
        value = f(data[[k]]))
  }
  # data[, (char_cols) := lapply(.SD, f),
  #      .SDcols = char_cols]
  invisible(data)
}




# format_numeric ----------------------------------------------------------



#' Enforces consistent storage for numeric data
#'
#' Stores all numeric data as doubles to prevent
#' type errors.
#' @inheritParams step_basic
#' @param col Populated automatically on [prep()].
#' @export
#' @details
#' * Step: Nothing.
#' * Prep: Determine columns which need to be coerced with [base::as.double()].
#' * Bake: Coerces columns determined in [prep()].
format_numeric <- function(recipe, trained = FALSE, col = NULL) {
  add_step(recipe,
           format_numeric_new(
             trained = trained,
             col = col))
}

format_numeric_new <- function(col = NULL, trained = FALSE) {
  format(subclass = "numeric",
         trained = trained,
         col = col)
}


#' @importFrom stringr str_which
prep.format_numeric <- function(x, training, ...) {
  int_cols <- which(sapply(training, is.integer))
  int_cols <- setdiff(int_cols, str_which(names(training), "date"))
  ref <- names(training)[int_cols]
  format_numeric_new(col = ref,
                     trained = TRUE)
}
#' @importFrom data.table copy set
bake.format_numeric <- function(object, newdata, ...) {
  for (k in seq_along(object$col)) {
    set(x = newdata,
        i = NULL,
        j = object$col[k],
        value = as.double(newdata[[object$col[k]]]))
  }
  newdata
}

#' @describeIn format_numeric Non-recipe version.
#' @export
.format_numeric <- function(data) {
  temp_data <- copy(data)
  numerics <- which(vapply(temp_data, is.numeric, FUN.VALUE = c(TRUE), USE.NAMES = FALSE))
  numerics <- setdiff(numerics, which(grepl("date", names(temp_data))))
  if (length(numerics) != 0) {
    temp_data[, (numerics) := lapply(.SD, as.double), .SDcols = numerics]
  }

  temp_data
}


# format_yes_no -----------------------------------------------------------



#' 1/0 to Yes/No according to MMM
#'
#' Translates binary values to Yes/No based on settings in MMM. Explicitly
#' ignores "SUP_HoursMeterInaccurate", "SUP_EngineRebuilt", "SUP_TransmissionRebuilt"
#' for backwards compatibility.
#' @inheritParams step_basic
#' @param category_id A single category ID.
#' @param col The columns changed to yes/no.
#' @details
#' * Step: Nothing
#' * Prep: Populates `col`.
#' * Bake: 1 to "yes", 0 to "no", invalid and `NA` values left alone.
#'
#' @export
format_yes_no <- function(recipe, category_id = NULL, trained = FALSE, col = NULL) {
  add_step(recipe,
           format_yes_no_new(
             category_id = category_id,
             trained = trained
           ))
}

format_yes_no_new <- function(category_id = NULL, trained = FALSE, col = NULL) {
  format(subclass = "yes_no",
         category_id = category_id,
         trained = trained,
         col = col)
}
#' @importFrom shapi SearchModel
#' @importFrom shapi mmm
#' @importFrom httr content
prep.format_yes_no <- function(x, training, ...) {
  smodel <- SearchModel(CategoryID == !!x$category_id, 1 %in% DisplayOptionList, GroupType = "Detailed Input", PropertiesToInclude = "SpecField, IsYesNo")
  res <- suppressWarnings(content(mmm$methods$CategorySpec_Search(smodel), 'parsed'))
  isyesno <- setDT(rbindlist(res))
  isyesno <- isyesno[IsYesNo == TRUE, list(SpecField, IsYesNo)]
  sup <- copy(isyesno)[,SpecField := paste0("SUP_", SpecField)]
  def <- copy(isyesno)[,SpecField := paste0("DEF_", SpecField)]
  isyesno <- rbindlist(l = list(isyesno, sup, def), use.names = TRUE)[!SpecField %in% c("SUP_HoursMeterInaccurate", "SUP_EngineRebuilt", "SUP_TransmissionRebuilt")]
  yes_no <- intersect(names(training), change_names(isyesno$SpecField, from = 'sql'))
  format_yes_no_new(category_id = x$category_id,
                    trained = TRUE,
                    col = yes_no)
}

bake.format_yes_no <- function(object, newdata, ...) {
  stopifnot(all(object$col %in% names(newdata)))
  for (k in object$col) {
    zeros <- which(newdata[[k]] == 0)
    missing <- which(is.na(newdata[[k]]))
    ones <- which(newdata[[k]] == 1)
    yes_no <- which(newdata[[k]] %in% c("yes", "no"))
    rows <- seq_len(nrow(newdata))
    incorrect <- setdiff(rows, c(zeros, missing, ones, yes_no))
    if (length(incorrect) > 0 && interactive()) {
      warning(glue::glue("{k} is marked as \"Yes/No\", but contains at least one value other \\
                         than `1`, `0`, or `NA`. Incorrect values are ignored."), call. = FALSE)
    }
    if (interactive()) {
      message(glue::glue("Changing {k} from 1/0 to yes/no."))
    }
    set(x = newdata,
        i = NULL,
        j = k,
        value = as.character(newdata[[k]]))
    set(x = newdata,
        i = zeros,
        j = k,
        value = "no")
    set(x = newdata,
        i = ones,
        j = k,
        value = "yes")
    }
  newdata

}

#' Attempts to change 1/0 to yes/no
#'
#'
#' __DEPRECATED__ Use [format_yes_no()] instead.
#' @export
#' @rdname format_1_0
.format_1_0 <- function(data) {
  data <- copy(data)
  only_1_0_na <- function(x) {
    vals <- x[!is.na(x)]
    ifelse(identical(union(c(1, 0), vals), c(1, 0)), TRUE, FALSE)
  }
  logicals <- which(vapply(data, FUN = only_1_0_na, FUN.VALUE = TRUE))
  logicals <- logicals[names(logicals) != "event_type_id"]
  to_yes_no <- function(x){
    ifelse(x == 1 & !is.na(x), "yes",
           ifelse(x == 0 & !is.na(x), "no", NA_character_))
  }
  data[, (logicals) := lapply(.SD, to_yes_no),
       .SDcols = logicals]
  invisible(data)
}


# format_class ------------------------------------------------------------




#' Sets each column to the correct base type.
#'
#' `format_class` creates a *specification* of a recipe step that will
#'   make sure each necessary column exists, and is character, double, or logical, as appropriate.
#'   Only needed on export recipes.
#' @inheritParams step_basic
#' @param exclude Columns to exclude from coercion rules.
#' @param ref_dt Generated automatically.
#' @inherit step_basic return
#' @export
#' @details
#'  * Step: Nothing.
#'  * Prep: Compute 0-row reference `data.table`.
#'  * Bake: Enforce the classes of the passed data based on `ref_dt`. Creates
#'  columns which don't exist in the input data.
format_class <- function(recipe, exclude = NULL, ref_dt = NULL, trained = FALSE) {
  add_step(recipe,
           format_class_new(exclude = exclude,
                            ref_dt = ref_dt,
                            trained = trained))
}

format_class_new <- function(exclude = NULL, ref_dt = NULL, trained = FALSE) {
  format(subclass = "class",
         exclude = exclude,
         ref_dt = ref_dt,
         trained = trained)
}

prep.format_class <- function(x, training) {
  # ref_dt <- training[0, setdiff(names(x$training), x$exclude), with = FALSE]
  if (!"data_type" %in% names(training)) {
    training <- copy(training)
    training[,data_type := NA_character_]
  }
  format_class_new(exclude = x$exclude,
                   ref_dt = training[0],
                   trained = TRUE)
}
#' @importFrom stringr str_replace_all
#' @importFrom data.table rbindlist
bake.format_class <- function(object, newdata, ...) {
  # Subset to the columns which may be coerced.
  has_cols <- setdiff(names(newdata), object$exclude)
  ref_dt <- object$ref_dt[, setdiff(names(object$ref_dt), object$exclude), with = FALSE]
  # factors to strings.
  factors <- vapply(newdata, FUN = is.factor, FUN.VALUE = logical(1L), USE.NAMES = TRUE)
  columns <- names(factors)[factors]
  for (k in seq_along(columns)) {
    set(x = newdata,
        i = NULL,
        j = columns[k],
        value = str_replace_all(as.character(newdata[[columns[k]]]), ",", ""))

  }
  # Don't try to coerce columns which have a missing "base" class. This is here to
  # make sure the step can be used on "clean" data without error.

  ref_classes <- vapply(object$ref_dt, FUN = function(x) class(x)[1], FUN.VALUE = character(1L), USE.NAMES = TRUE)
  classes <- vapply(newdata, FUN = function(x) class(x)[1], FUN.VALUE = character(1L), USE.NAMES = TRUE)
  # Only select columns with different base classes.
  coerce_cols <- na.omit(names(classes)[ref_classes[names(classes)] != classes[match(names(classes), names(ref_classes[names(classes)]))]])
  # Skip coercion if none need it.
  if (length(coerce_cols) > 0) {
    not_missing <- !is.na(newdata[,coerce_cols, with = FALSE])
    # SQL names for error messages
    colnames(not_missing) <- change_names(colnames(not_missing), from = "r")
    for (k in coerce_cols) {
      set(x = newdata,
          i = NULL,
          j = k,
          value = as(newdata[[k]], ref_classes[k]))
    }
    # See what observations have been eliminated
    now_missing <- is.na(newdata[, coerce_cols, with = FALSE])
    colnames(now_missing) <- change_names(colnames(now_missing), from = "r")
    has_missing <- which(rowSums(not_missing & now_missing) > 0)
    # colnames(now_missing) <- change_names(names = colnames(now_missing), from = "r")
    for (k in has_missing) {
      set(x = newdata,
          i = k,
          j = "invalid_data",
          value = str_c(colnames(now_missing)[now_missing[k,]], collapse = "; "))
    }
  }
 # Any columns which are assumed to exist in later "general" steps (check_*, add_json, etc.), should be
 # initialized here.
  if (!("r_message" %in% names(newdata))) {
    set(x = newdata,
        i = NULL,
        j = "r_message",
        value = "")
  } else {
    set(x = newdata,
        i = which(is.na(newdata[["r_message"]])),
        j = "r_message",
        value = "")
  }
  if (!("required_fields" %in% names(newdata))) {
    set(x = newdata,
        i = NULL,
        j = "required_fields",
        value = "")
  }
  if (!"invalid_data" %in% names(newdata)) {
    set(x = newdata,
        i = NULL,
        j = "invalid_data",
        value = "")
  }
  if (!"insufficient_data" %in% names(newdata)) {
    set(x = newdata,
        i = NULL,
        j = "insufficient_data",
        value = "")
  }
  if (!"skip_checks" %in% names(newdata)) {
    set(x = newdata,
        i = NULL,
        j = "skip_checks",
        value = FALSE)
  }
  # setnames(newdata, change_names(names(newdata), from = "sql"))
  rbindlist(list(object$ref_dt, newdata), fill = TRUE, use.names = TRUE)
}


summary.format_class <- function(x, ...) {
  data.table(column = names(x$ref_dt),
             class = vapply(x$ref_dt, FUN = function(x){class(x)[length(class(x))]}, FUN.VALUE = character(1), USE.NAMES = FALSE))
}

