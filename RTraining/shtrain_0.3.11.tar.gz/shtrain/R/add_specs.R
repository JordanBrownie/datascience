#' Add supplemental, default, or dynamic specs to data
#'
#' Retrieve selections (or all) data from corresponding view. Automatically adds
#' the merge variable to selections, and completes the merge. Can mix and match
#' supplemental, dynamic, and default specs in the same call. See details.
#'
#' @param con RODBC connection from [create_server_connection()].
#' @param data A data.table containing "ds_lookup_id", "ref_id", "data_type",
#' and possibly "oh_id".
#' @param selections Selections with `R` names.
#' @param coerce `Logical`. Will make best efforts to coerce data based on base
#' spec class, then based on proportion of values which can't be coerced to `numeric`.
#' This only applies to new columns added.
#' @details Note that variables are coerced based on the corresponding base spec.
#' So if hours is numeric and sup_hours isn't, sup_hours is coerced to numeric,
#' with warnings suppressed. If you wish coercing for some variables but not
#' others, use a second call to `add_specs`.
#' @export
#' @family querying functions
#' @importFrom RODBC sqlQuery
#' @importFrom snakecase to_snake_case to_any_case
#' @importFrom data.table rbindlist ':=' setnames melt.data.table
#' @importFrom glue glue collapse
#' @importFrom stringr str_replace str_pad str_detect
#'
add_specs <- function(con, data, selections, coerce = TRUE, threshold = 0.05) {
  starting_cols <- names(data)
  industry <- get_industry(data = data)
  category_id <- get_category_id(data = data)
  len <- length(category_id)
  types <- list(supplemental = "sup_", default = "def_", dynamic = "dyn_")
  specs <- vector(mode = "list", length = 3)
  all_specs <- vector(mode = "list", length = 3)
  for (i in seq_along(types)) {
    specs[[i]] <- vector(mode = "list", length = len)
    type_name <- names(types)[i]
    expanded_selections <- expand_selections(selections, type = type_name)
    for (j in seq_along(category_id)) {
      temp_selections <- expanded_selections[grepl(types[[i]], expanded_selections, ignore.case = TRUE)]
      if (length(temp_selections) > 0) {
        valid <- if (any(grepl("\\*", temp_selections))) {"*"} else{
          temp_selections_sql <- translate_names(names = temp_selections, from = "r", to = type_name)
          sql_choices <- sql_columns(con = con, category_id = category_id[j])[[type_name]]
          valid <- temp_selections_sql[match(sql_choices, temp_selections, nomatch = 0)]
          valid <- c(valid, ifelse(type_name == "default", "LOWER(MakeModel) as MakeModel",
                                                ifelse(type_name == "supplemental", "ReferenceID, ReferenceTypeID",
                                                       "DSLookupID")))
          valid
        }
        tbl <- glue("vw_{industry}{type_name}Specs_{category_id[j]}")
        if (type_name == "supplemental") {
          sup_filter <- "WHERE ReferenceTypeID <> 10"
        } else {
          sup_filter <- ""
        }
        specs[[i]][[j]] <- setDT(sqlQuery(channel = con, glue("SELECT {collapse(valid, sep = ', ')} FROM {tbl} (NOLOCK) {sup_filter}"), stringsAsFactors = FALSE))
        if (is.character(specs[[i]][[j]]) && typeof(specs[[i]][[j]]) == "character" && interactive()) {
          warning(glue("{collapse(specs[[i]][[j]], sep = '\n')} \n {type_name} specs for {category_id[j]} not retrieved
                {if(len>1) {{ glue('{type_name} specs for other categories returned, if possible.')} }} else {{''}}"), call. = TRUE)
          specs[[i]][[j]] <- NULL
        }
      } else {
        specs[[i]][[j]] <- NULL
      }
    }
    if (!identical(unique(unlist(specs[[i]], use.names = FALSE)), NULL)) {
        all_specs[[i]] <- rbindlist(specs[[i]],
                                    use.names = TRUE,
                                    fill = TRUE)
        setDT(all_specs[[i]])
        old_names <- names(all_specs[[i]])
        sql_names <- str_replace(old_names, "^DYN_", "")
        new_names <-  to_snake_case(sql_names)
        setnames(all_specs[[i]], old = old_names, new = new_names)
        sql_names <- setdiff(sql_names, "ReferenceID")
        new_names <- setdiff(new_names, "reference_id")
        cache_names(sql = sql_names, r = new_names)

        if (type_name == "default") {
          all_specs[[i]]$make_model <- tolower(all_specs[[i]]$make_model)
          data <- merge(data, all_specs[[i]],
                        all.x = TRUE,
                        by = "make_model")
        } else if (type_name == "supplemental") {
          # Determine ReferenceID/DsLookupIDs which are in supplemental data.
          # If both are in there for one listing, choose DSLU (due to code order),
          # Combine in one column to merge together on.
          temp_data <- copy(data)[,ref_id := as.double(ref_id)][,ds_lookup_id := as.double(ds_lookup_id)]
          # reference_type_id == 1 is DSLookupID for all industries, whereas
          # the the DBs OHID reference_type_id differs.
          auction_ohid <- temp_data[auction()][all_specs[[i]][reference_type_id != 1], as.double(ref_id), on = c("ref_id" = "reference_id"), nomatch = 0L]
          auction_dslu <- temp_data[auction()][all_specs[[i]][reference_type_id == 1], as.double(ds_lookup_id), on = c("ds_lookup_id" = "reference_id"), nomatch = 0L]
          if ("oh_id" %in% names(temp_data)) {
          aftersale_ohid <- temp_data[aftersale()][all_specs[[i]][reference_type_id != 1],as.double(i.reference_id),  on = c("oh_id" = "reference_id"), nomatch = 0L]
          aftersale_dslu <- temp_data[aftersale()][all_specs[[i]][reference_type_id == 1],as.double(ds_lookup_id), on = c("ds_lookup_id" = "reference_id"), nomatch = 0L]
          temp_data[oh_id %in% aftersale_ohid, ref_id2 := as.double(oh_id)]
          temp_data[ds_lookup_id %in% aftersale_dslu, ref_id2 := as.double(ds_lookup_id)]
          } else {
             temp_data[aftersale(), ref_id2 := as.double(ds_lookup_id)]
          }
          temp_data[ref_id %in% auction_ohid, ref_id2 := as.double(ref_id)]
          temp_data[ds_lookup_id %in% auction_dslu, ref_id2 := as.double(ds_lookup_id)]
          asking_ohid <- temp_data[asking()][all_specs[[i]][reference_type_id != 1], as.double(ref_id), on = c("ref_id" = "reference_id"), nomatch = 0L]
          asking_dslu <- temp_data[asking()][all_specs[[i]][reference_type_id == 1], as.double(ds_lookup_id), on = c("ds_lookup_id" = "reference_id"), nomatch = 0L]
          temp_data[ref_id %in% asking_ohid, ref_id2 := as.double(ref_id)]
          temp_data[ds_lookup_id %in% asking_dslu, ref_id2 := as.double(ds_lookup_id)]
          data <- merge(temp_data, all_specs[[i]],
                        all.x = TRUE,
                        by.x = "ref_id2",
                        by.y = "reference_id")
          data[,ref_id2 := NULL]

        } else if (type_name == "dynamic") {

          data <- merge(data, all_specs[[i]],
                        all.x = TRUE,
                        by.x = "ds_lookup_id",
                        by.y = "ds_lookup_id")
    }
    }
  }
  setnames(data, old = names(data), new = str_replace(names(data), "^dyn_", ""))
  not_needed <- intersect(names(data), c("object_default_id", "reference_type_id"))
  if (length(not_needed) > 0) {
    data[,(not_needed) := NULL]
  }
  if (coerce == TRUE) {
    sups <- find_replacement(names(data), "sup_")
    defs <-  find_replacement(names(data), "def_")
    both <- c(sups, defs)
    base_numeric <- vapply(names(both), FUN = function(x) is.numeric(data[[x]]), FUN.VALUE = logical(1L), USE.NAMES = FALSE)
    both <- both[base_numeric]
    if (interactive() && length(both) > 0) {
      message(str_c("Coerced ", glue::collapse(both, sep = ", ", width = 50),
                    " to match type of the corresponding dealer-entered value."))
    }
    for (k in seq_along(both)) {
      suppressWarnings({set(x = data,
                            i = NULL,
                            j = both[k],
                            value = as.double(str_replace_all(data[[both[k]]], ",\\+", "")))
      })}
  }
  classes <- unlist(lapply(data, function(x) class(x)[1]))
  logicals <- names(data)[which(classes == "logical")]
  props <- data[,setdiff(names(data), c(starting_cols, logicals)), with = FALSE]
  props <- suppressWarnings({melt(props, measure.vars = names(props), na.rm = TRUE)[
    , .(prop = sum(str_detect(value, "[^0-9,\\.\\s\\+]"), na.rm = TRUE)/sum(!is.na(value))), by = list(variable)]})
  props <- props[prop < threshold & prop != 0]
  props <- props[order(prop)]
  to_coerce <- props[["variables"]]
  if (length(to_coerce) > 0) {
  tracker <- str_c("Coerced ", str_pad(props[['variable']],
                                       width = max(str_length(props[['variable']])) + 1L, side = "right"),
                   " to numeric. Lost ", round(props[['prop']], 3)*100, "%", collapse = "\n")
  if (interactive()) {
  message(str_c("Coerced ", str_pad(props[['variable']],
                                    width = max(str_length(props[['variable']])), side = "right"),
                " to numeric. Lost ", round(props[['prop']], 3)*100, "%", collapse = "\n"))
  }

  for (k in names(to_coerce)) {
    suppressWarnings({
    set(x = data,
        i = NULL,
        j = k,
        value = as.double(str_replace_all(data[[k]], ",\\+", "")))
    }
    )}
  }
  new_cols <- setdiff(names(data), starting_cols)
  if (length(new_cols) < length(selections) & interactive()) {
    i
  }
  data
}




#' Add "description" field to data
#'
#' Retrieve "description" (GeneralInfo) separately and add to supplied data.
#' This allows descriptions up to 4000 characters long.
#'
#' @param data A data.table containing"ref_id" and "data_type".
#' @param selections A character vector of data types to retrieve descriptions for.
#' Defaults to "auction", "aftersale", and "asking".
#' @param archive Logical. Coupled with `selections` to determine which data types
#' to retrieve descriptions for.
#' @details This function returns longer description fields (4000 characters) than
#' if "description" is supplied as a selection in `get_data`.
#' @export
#' @family querying functions
#' @importFrom RODBC sqlQuery
#' @importFrom data.table rbindlist ':=' CJ
#' @importFrom stringr str_detect str_extract
#'
add_description <- function(data, types = c("auction", "asking", "aftersale"), archive = TRUE) {

  if ("description" %in% names(data)) {
    stop("'description' field already found within data. Remove 'description' from `get_data()` selections.")
  }

  con <- create_server_connection()
  on.exit(odbcClose(con))
  cids <- unique(data$category_id)
  ind <- get_industry(data = data)

  archive <- if (archive) c("_archive", "") else ""
  tbls <- CJ(types = types, archive = archive)[!(types == "aftersale" & archive == "_archive")]
  tbls <- paste0("vw_",  ind,  "_", tbls$types, tbls$archive)
  dscs <- vector(mode = "list", length = length(tbls))

  for (k in seq_along(tbls)) {

    dscs[[k]] <- setDT(sqlQuery(con,
                                glue::glue("SELECT CAST(LOWER(GeneralInfo) as nvarchar(4000)) as description, referenceID as ref_id
                                            FROM {tbls[k]} (NOLOCK) where categoryID in {shtrain:::sql_c(cids)};"),
                                stringsAsFactors = FALSE))
    dscs[[k]][str_detect(tbls[k], "archive"), archive := TRUE][is.na(archive), archive := FALSE]
    dscs[[k]][, data_type := str_extract(tbls[k], "auction|aftersale|asking")]

  }

  all_dsc <- rbindlist(dscs)
  all_dsc <- .format_character(all_dsc)
  all_dsc <- .format_numeric(all_dsc)

  data[,did := .I]
  data <- merge(data, all_dsc[!is.na(ref_id), list(ref_id, data_type, archive, description)], by = c("ref_id", "data_type", "archive"), all.x = TRUE)

  unique(data, by = "did")[,did := NULL]

}
