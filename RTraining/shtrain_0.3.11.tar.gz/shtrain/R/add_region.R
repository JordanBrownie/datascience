#' Add region to data
#'
#' add_region creates a *specification* of a recipe step that will
#'   merge to a table on the 'state' column. It will drop 'region' in
#'   the input data set if present. For regions not defined by "state",
#'   you can pass a named list to `region_list`.
#' @inheritParams step_basic
#' @param region_dt Optional input. If provided, the table is merged to by state,
#' if not, one is generated using [region_table()], based off the
#' category IDs in the data. It is best to generate manually and inspect.
#' @param region_list Optional input. Used to define regions based off country
#' instead of state.
#' @inherit step_basic return
#' @export
#' @include tables.R
#' @details
#'  * Step: Nothing.
#'  * Prep: Populate `region_dt` if `NULL`.
#'  * Bake: Merge on `region_dt` on "state", dropping "region" from the input data if present.
#'  Set region's based on country using `region_list`.
add_region <- function(recipe, region_dt = NULL, region_list = NULL, trained = FALSE) {
add_step(recipe,
         add_region_new(
         region_dt = region_dt,
         region_list = region_list,
         trained = FALSE)
         )
}


add_region_new <- function(region_dt = NULL, region_list = NULL, trained = FALSE) {
  add(subclass = "region",
          region_dt = region_dt,
          region_list = region_list,
          trained = trained
  )
}

#' @importFrom RODBC odbcClose
#' @importFrom glue glue
prep.add_region <- function(x, training, ...) {
  if (is.null(x$region_dt)) {
con <- create_server_connection()
on.exit(odbcClose(con))
ref <- region_table(con, get_category_id(training))
  } else {
    ref <- x$region_dt
  }
  if (!is.null(x$region_list)) {
    not_in <- unlist(x$region_list, use.names = FALSE)
    if (!all(not_in %in% unique(training$country)) && interactive()) {
     message(glue("{glue::collapse(setdiff(not_in, unique(training$country)), sep = ', ', last = ' and ')} \\
                not present in the training data."))
    }
  }
  add_region_new(
  region_dt = ref,
  region_list = x$region_list,
  trained = TRUE
)
}
#' @importFrom data.table %chin%
bake.add_region <- function(object, newdata, ...) {
  if ("region" %in% names(newdata)) {
    newdata[,region := NULL]
  }
newdata <- merge(newdata, object$region_dt, by = "state", all.x = TRUE)
for (k in seq_along(object$region_list)) {
  set(x = newdata,
      i = which(newdata[["country"]] %chin% object$region_list[[k]]),
      j = "region",
      value = names(object$region_list)[k])
}
newdata
}

summary.add_region <- function(x, ...) {
  if (!is.null(x$region_dt)) {
    x$region_dt
  } else {
    NULL
  }
}