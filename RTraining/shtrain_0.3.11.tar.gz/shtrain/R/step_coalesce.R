
#' Coalesce multiple columns
#'
#' `step_coalesce` is a *specification* of a recipe step which coalesces columns
#' for desired specs and spec types. Column names can be specified explicitly, or the
#' function will look for any possible replacements to perform. The specs used for
#' replacement, and the order of replacement, is determined by parameter entry. Based
#' on SQL Server's coalesce function.
#'
#' @inheritParams step_basic
#' @param col A vector of base (dealer-entered) spec columns found within the data.
#' If a column name is included in `col` which does not have any additional spec types
#' to use for replacement, a warning message is issued. If `col` is not provided, it
#' defaults to `NULL` and the step will perform replacements on all possible columns found
#' within the data. **This must be provided if "dlr" is not in `order`**.
#' @param order A vector of spec types which defines the order of replacement for missing
#' values in the column defined by the first type provided. To reference the dealer-entered
#' spec, please enter 'dlr' wherever necessary in this vector. Common spec types referenced
#' here include 'dlr', 'sup', 'def', 'imp', 'scr', and 'dsc'.
#' @param spec_list Generated in the prep step.
#' @seealso step_replace_na step_replace
#' @family step functions
#' @export
#' @examples \dontrun{
#'   # replaces na values in all possible dealer spec columns with supplemental spec columns.
#'   dt <- data.table(hours = (1, 2, 3, 4, NA, NA), sup_hours = 10, def_hours = c(1, 1, 1, 1, 4, NA),
#'                    drive = c(rep("2wd", 3), rep(NA, 3)), sup_drive = "2wd")
#'   dt
#'   recipe(dt) %>% step_coalesce(col = NULL, order = c("dlr", "sup")) %>% trained()
#'   # Only modify drive.
#'   recipe(dt) %>% step_coalesce(col =  "drive", order = c("dlr", "sup")) %>% trained()
#'   }
#' @details
#'
#' * Step: Nothing
#' * Prep: Generates a named list of character vectors. Each vector in the list conatains the
#' names, in the correct order, of the columns to be coalesced. The first column name in this
#' vector is the final spec which will hold all of the replacements. Each character vector is
#' named with the appropriate respective base spec.
#' * Bake: Replace missing values in the columns successively, using the order provided int he step.
step_coalesce <- function(recipe, order, col = NULL, trained = FALSE, spec_list = NULL) {
add_step(recipe,
         step_coalesce_new(
           order = order,
           col = col,
           trained = trained,
           spec_list = spec_list
         ))
}

step_coalesce_new <- function(order, col = NULL, trained = FALSE, spec_list = NULL) {
  step(subclass = "coalesce",
                 order = order,
                 col = col,
                 trained = trained,
                 spec_list = spec_list
  )
}


prep.step_coalesce <- function(x, training, ...) {

  if (is.null(x$col)) {
    x$col <- names(training)
    original_spec <- NULL
  } else {
    original_spec <- x$col
  }

  rgx <- str_c(str_c(x$order, "_"), collapse = "|")
  rgx_2 <- str_c(str_c(x$order[x$order != "dlr"], "_"), collapse = "|")

  spec_name <- CJ(V1 = x$order, V2 = x$col, sorted = FALSE)[,str_c(V1, V2, sep = "_")]
  spec_name <- unique(str_replace_all(spec_name, "dlr_", ""), fromLast = TRUE)
  spec_name <- dplyr::intersect(spec_name, names(training))
  spec_name[!str_detect(spec_name, rgx_2)] <- str_c("dlr_", spec_name[!str_detect(spec_name, rgx_2)])

  spec_name_2 <- vector()
  for (k in seq_along(x$order)) {
    keep <- spec_name[startsWith(spec_name, x$order[k])]
    keep <- str_replace_all(keep, "dlr_", "")
    spec_name_2 <- c(spec_name_2, keep)
  }

  spec_list <- vector("list", length(x$col))
  names(spec_list) <- x$col
  for (j in seq_along(x$col)) {
    spec_list[[j]] <- spec_name_2[str_replace_all(spec_name_2, rgx, "") == names(spec_list)[j]]
  }
  spec_list <- spec_list[lengths(spec_list) > 1]

  if (!is.null(original_spec)) {
    missing <- str_c(original_spec[!original_spec %chin% names(spec_list)], collapse = ", ")
    if (length(missing) > 0 & interactive()) {
      warning(glue("Columns {missing} were supplied to step_coalesce() in 'col', but no comparable \\
                   columns to coalesce were found using the prefixes supplied in 'order'."), call. = FALSE)
    }
    }

  if (is.null(original_spec) && interactive()) {
    message(glue::glue("[{str_c(names(spec_list), collapse = \", \")}] collapsed in the following order: \\
                       [{str_c(x$order, collapse = \", \")}]."))
    # for (m in seq_along(names(spec_list))) {
    #   str_1 <- names(spec_list)[m]
    #   str_2 <- str_c(spec_list[[m]], collapse = ", ")
    #   message(glue("{str_1} columns were coalesced in the following order: {str_2}."))
    # }
    if (length(spec_list) < 1) {
      warning("No comparable columns to coalesce were found using the prefixes supplied in 'order'.", call. = FALSE)
    }
  }


  step_coalesce_new(
    order = x$order,
    col = x$col,
    trained = TRUE,
    spec_list
  )

  }


bake.step_coalesce <- function(object, newdata, ...) {

  list_names <- names(object$spec_list)

  for (j in seq_along(list_names)) {
    for (k in seq_along(object$spec_list[[j]])) {
      if (k == 1) {
        next
      }
      newdata <- replace_na(data = newdata, replace = object$spec_list[[j]][1], with = object$spec_list[[j]][k])
    }
  }

  newdata
}
