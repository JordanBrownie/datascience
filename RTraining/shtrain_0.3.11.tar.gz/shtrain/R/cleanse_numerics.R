# #' cleanseNumerics
# #'
# #' Reformats any numeric \code{spec} that might initially be formatted as a character string.  The function also cleanses numeric values to be
# #' in the correct base unit.
# #'
# #' @param dframe Dataframe containing numeric \code{spec}.
# #' @param spec The numeric \code{spec} that needs to be cleansed.
# #' @param nlunit_cutoff The named list of cutoffs that will be used to cleanse the data. See details.
# #'
# #' @details This function will reformat and calculate the corrected numeric value based on the relevant BaseUnit.  Currently works
# #' on \code{spec} in the UnitGroups of Length and Mass.  If \code{spec} needs reformatted the function will pull the relevant Unit and BaseUnit
# #' and update value to be in the correct BaseUnit.  If \code{spec} is correctly formatted, the function will adjust the value to be in the
# #' correct BaseUnit.  The names given in \code{nlunit_cutoff} MUST correspond to the Unit and/or BaseUnit given in the MeasurementUnit Table
# #' in MMM. This is necessary in order for the function to use the correct conversion value.  The first cutoff given is the max value for Unit and
# #' the second cutoff is the max value for BaseUnit. If the \code{spec} is RowSpacing, the cutoffs will be the min and max value for the
# #' BaseUnit.  There is a special case for BaseUnit of Pounds where the Unit given can be Half Ton which is not in the MeasurementUnit table. The
# #' function will also work on Count Specs that have no base unit.  When passing the named cutoff, you would just pass the name "Count".
# #'
# #' @return The dataframe with the correctly formatted and cleansed numeric specs.
# #' @importFrom stringr str_extract str_replace
# #' @importFrom RODBC sqlQuery odbcCloseAll
# #' @include utils.R
# #' @export
# #'
# #' @examples #Here are example calls for this function
# #' \dontrun{
# #' First example is the base case for using this function
# #' dfAuction <- cleanseNumerics(train14a, "Length", list("Foot" = 96, "Inch" = 1152))
# #' Second example is special case for Row Spacing
# #' dfAuction <- cleanseNumerics(train14r, "Length", list("Inch" = 2, "Inch" = 24))
# #' Third example is for count data
# #' dfMerged <- cleanseNumerics(dfMerged, "NumBales", list("Count" = 1000))
# #' Final example is the special case for the Weight Specs
# #' dfAuction <- cleanseNumerics(dfAuction, "GrossVehicleWeight",
# #' list("Half Ton" = 80, "Pound" = 80000))
# #' }
can_be_numeric <- function(x) {
  if (is.numeric(x)) {
    ret <- TRUE
  } else {
    ret <- sum(str_detect(x, "[^0-9\\,\\.]"), na.rm = TRUE) == 0
  }
  ret
  }
# cleanse_numerics <- function(data, spec, nl_unit_cutoffs){
#   on.exit(odbcCloseAll())
#   stopifnot(is.data.table(data), is.list(nl_unit_cutoffs))
#   data <- copy(data)
#   unit_cutoff <- tolower(names(nl_unit_cutoffs))
#   dbhandle <- shtrain:::create_server_connection()
#   measurements <- sqlQuery(dbhandle,"SELECT LOWER(Unit) as Unit, LOWER(BaseUnit) as BaseUnit, MultiplyBy
#                            FROM dbMMM.dbo.MeasurementUnit MU(NOLOCK);",
#                            stringsAsFactors = FALSE)
#   names(measurements) <- to_snake_case(names(measurements))
#   if (!can_be_numeric(data[[spec]]) && any(spec == c("length", "width", "height", "internal_height"))) {
#     #identifies the unit we are using
#     match <- chmatch(unit_cutoff[1], measurements[,"unit"])
#     # Create these as vectors instead of columns of the dataframe. This way we do not have to remove them.
#     ##Specifically for UnitGroup of Length
#     #creates column for numeric values
#     #creates column for foot values
#     #Pulls out the numeric values
#     num <- as.numeric(str_extract(data[[spec]], "^[0-9]{1,4}\\.?\\d{1,2}?|^\\d{1}\\.?\\d{0,2}"))
#     #Pulls out the next 3 relevant digits as BaseUnit value
#     bu <-  as.numeric(str_extract(data[[spec]], "(?<!\\-\\d{1,2}')(\\d{1,3})(?=\")"))
#     lt_lower <- which(num < nl_unit_cutoffs[[1]])
#     # Creates vector of 0's
#     u <- double(length = length(data[[spec]]))
#     u[lt_lower] <- num[lt_lower]
#     #Places values that are greater than second cutoff in baseUnit column
#     gt_lower <- which(num >= nl_unit_cutoffs[[1]])
#     bu[gt_lower] <- num[gt_lower]
#     bu[is.na(bu)] <- 0
#     #Replaces NA with 0 in order to reformat
#     # data[is.na(u), u] <- 0
#     # data[is.na(bu), bu] <- 0
#     #Converts value to relevant BaseUnit
#     set(x = data,
#         i = NULL,
#         j = spec,
#         value = u*measurements[match, "multiply_by"] + bu)
#     set(x = data,
#         i = which(data[[spec]] == 0),
#         j = spec,
#         value = NA_real_)
#
#   } else if (!can_be_numeric(data[[spec]]) && any(spec == c("row_spacing"))) {
#     #identifies the unit we are using
#     # match <- match(unit_cutoff[1], measurements[,"Unit"])
#     # u <- measurements[match,"Unit"]
#     # bu <- measurements[match, "BaseUnit"]
#     #creates column for inch values
#     #Pulls out the first few digits(including decimals) as BaseUnit value
#     set(x = data,
#         i = NULL,
#         j = spec,
#         value = as.numeric(str_extract(data[[spec]], "^\\d{1,2}\\.?\\d{1,3}"))
#         )
#     #Replaces spec value with numeric values
#     #Used for Numeric Counts (numBales, numHoppers, etc.)
#   } else if (!can_be_numeric(data[[spec]]) && any(spec == c("num_bales"))) {
#     #Identifies and removes bad values
#     bad <- str_which("\\d{1,2}X\\d{1,2}", data[[spec]])
#     set(x = data,
#         i = bad,
#         j = spec,
#         value = NA_character_)
#     # creates column for numeric values
#     # Replaces ranges with first value
#     num <- str_extract(data[[spec]], "(\\d+)(?=-)")
#     # Extracts simplified numbers (20k = 20,000)
#     num[is.na(num)] <- str_extract(data[[spec]][is.na(num)], "(\\d+)(?=K)")
#     # comma/period fix
#     num[is.na(num)] <- str_extract(data[[spec]][is.na(num)], ("(\\d+)(?:[\\.\\,])\\d{1}"))
#     num <- as.numeric(str_replace(num, ",", "."))
#     # Multiply those not represented in 1,000s already
#     multiply <- which(num < nl_unit_cutoffs[[1]])
#     num <- num[multiply]*1000
#
#     #Extracts Numeric values
#     num[is.na(num)] <- as.numeric(str_extract(data[[spec]][is.na(num)], "\\d+"))
#     set(x = data,
#         i = NULL,
#         j = spec,
#         value = num)
#   } else {
#     # Adjusts values which are determined to be too large or too small.
#       lt_lower <- which(data[[spec]] < nl_unit_cutoffs[[1]])
#       gt_upper <- which(data[[spec]] > nl_unit_cutoffs[[2]])
#       if (unit_cutoff[1] %in% measurements[["unit"]]) {
#         match <- match(unit_cutoff[1], measurements[["unit"]])
#         set(x = data,
#             i = lt_lower,
#             j = spec,
#             value = data[[spec]][lt_lower]*measurements[match, "multiply_by"])
#         set(x = data,
#             i = gt_upper,
#             j = spec,
#             value = data[[spec]][gt_upper]/measurements[match, "multiply_by"])
#       } else if (unit_cutoff[1] == "half ton") {
#         set(x = data,
#             i = lt_lower,
#             j = spec,
#             value = data[[spec]][lt_lower]*1000)
#         set(x = data,
#             i = gt_upper,
#             j = spec,
#             value = data[[spec]][gt_upper]/1000)
#       } else {
#         stop("First unit provided not recognized.")
#       }
#     }
#   data
# }
#