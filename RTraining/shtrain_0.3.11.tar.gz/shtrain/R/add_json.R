#' Add JSON containing spec values
#'
#' `add_json()` is the mechanism used to pass spec values back to FE. While the
#' default inclusions may be much more than you want, FE __ONLY__ shows spec values
#' for those fields specified in [attr_data()]. In most cases, this means you shouldn't
#' feel the need to offer a character vector for `exclude`.
#'
#' If any recommended specs are found within the data, `add_json()` will now also pass
#' them along in the json to be used in FE. If the user enters a value different from
#' the recommended value passed back, a helpful "FE recommends" message will be shown.
#'
#' @inheritParams step_basic
#' @param include Vector of names to include, in addition to `recipe$info$used_vars`.
#' @param exclude Vector of names to exclude from `recipe$info$used_vars`.
#' @param vars Generated automatically.
#' @inherit step_basic return
#' @export
#' @details
#' * Step: Populates `step$vars` with `recipe$info$used_vars`.
#' * Prep: Adds `include`, subtracts `exclude`.
#' * Bake: Constructs JSON column.
add_json <- function(recipe, include = NULL, exclude = NULL, trained = FALSE, vars = NULL) {
  add_step(recipe, add_json_new(
    include = include,
    exclude = exclude,
    vars = recipe$info$used_vars,
    trained = trained)
  )
}

add_json_new <- function(include = NULL, exclude = NULL, trained = FALSE, vars = NULL) {
  add(subclass = "json",
                include = include,
                exclude = exclude,
                trained = trained,
                vars = vars)
}


prep.add_json <- function(x, training, ...) {
  vars <- unique(c(x$vars, x$include, "state", "country"))
  vars <- setdiff(vars, x$exclude)
  if (interactive() && !is.null(x$include) && !all(x$include %in% shref$name_cache$r)) {
    stop(glue("Please provide SQL names for {lc(x$include)} using `cache_names()`."), call. = FALSE)
  }
  add_json_new(include = x$include,
                      exclude = x$exclude,
                      trained = TRUE,
                      vars)
}

#' @importFrom jsonlite toJSON
#' @importFrom stringr str_replace_all str_split_fixed str_c str_to_upper str_trim
#' @importFrom data.table set copy setnames
bake.add_json <- function(object, newdata, ...) {
  names <- change_names(names = object$vars, from = "r")
  temp <- copy(newdata[, object$vars, with = FALSE])
  setnames(temp, old = names(temp), new = names)
  char_cols <- which(sapply(temp, is.character))
  for (k in char_cols) {
    set(x = temp, i = NULL,
        j = k,
        value = str_trim(str_to_upper(temp[[k]])))
  }
  temp_json <- toJSON(temp)
  json <- str_replace_all(temp_json, pattern = "^\\[\\{|\\}\\]$", replacement = "")
  by_row <- str_split_fixed(json, pattern = "\\},\\{", n = nrow(newdata))
  json_by_row <- str_c("{", by_row, "}", sep = "")

  set(x = newdata,
      i = NULL,
      j = "spec_json",
      value = json_by_row)

  if (any(stringr::str_detect(names(newdata), "^rec_"))) {

    rec_specs <- str_subset(names(newdata), "^rec_")
    temp_rec <- copy(newdata[, rec_specs, with = FALSE])

    names_rec <- change_names(str_replace_all(names(temp_rec), "^rec_", ""), from = "r")
    setnames(temp_rec, old = names(temp_rec), new = names_rec)

    char_cols_rec <- which(sapply(temp_rec, is.character))
    for (k in char_cols_rec) {
      set(x = temp_rec, i = NULL,
          j = k,
          value = str_trim(str_to_upper(temp_rec[[k]])))
    }

    temp_json_rec <- toJSON(temp_rec)
    json_rec <- str_replace_all(temp_json_rec, pattern = "^\\[\\{|\\}\\]$", replacement = "")
    by_row_rec <- str_split_fixed(json_rec, pattern = "\\},\\{", n = nrow(newdata))
    json_by_row_rec <- str_c("{", by_row_rec, "}", sep = "")

    set(x = newdata,
        i = NULL,
        j = "rec_json",
        value = json_by_row_rec)

    newdata[,spec_json := stringr::str_c(spec_json, rec_json)
            ][,spec_json := stringr::str_c(stringr::str_replace_all(spec_json, "\\}\\{", ',\\"RecommendedValues\\":\\{'), "}")
              ][,rec_json := NULL]

  }

  newdata
}

summary.add_json <- function(x, ...) {
  if (is_trained(x)) {
    data.table(r_specs = x$vars,
               sql_specs = change_names(x$vars, from = "sql"))
  } else {
    NULL
  }
}
