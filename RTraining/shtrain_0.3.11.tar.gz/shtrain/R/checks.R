

# check_condition ---------------------------------------------------------

#' Error messages for condition
#'
#' Any listing with condition other than "used" will recieve "Invalid Data:Condition".
#' Prior to 2019-02-19 and version 0.2.12, we returned "No evaluations at this time".
#'
#'
#' @inheritParams step_basic
#' @export
#' @family check functions
check_condition <- function(recipe, trained = FALSE) {
  add_step(recipe, check_condition_new(trained = trained))
}

check_condition_new <- function(trained = FALSE) {
  check(subclass = "condition", trained = trained)
}

prep.check_condition <- function(x, training, ...) {
  if (!"condition" %in% names(training)) {
    stop("'condition' is not in the training data. This must be present for scoring.",
         call. = FALSE)
  }
  x$trained <- TRUE
  x
}

bake.check_condition <- function(object, newdata, ...) {
  newdata <- copy(newdata)
  invalid_condition <- which(newdata[["condition"]] != 'used' |
                               is.na(newdata[["condition"]]))
  dt_rm_evaluations(newdata, invalid_condition)
  dt_add_invalid(newdata, invalid_condition, "Condition")
  # dt_rm_errors(newdata, invalid_condition)
  # dt_add_skip(newdata, invalid_condition)
  dt_add_message(newdata, invalid_condition, " Unsupported: Condition")
  newdata
}


# check_state -------------------------------------------------------------

#' Error messages for state
#'
#' Performs checks on `state` column if the corresponding `country` uses them.
#' @inheritParams step_basic
#' @param has_states vector of country names which use 'state' for region.
#' @export
#' @family check functions
check_state <- function(recipe, has_states = c("usa", "canada"), trained = FALSE) {
  add_step(recipe, check_state_new(
    has_states = has_states,
    trained = trained))
}


check_state_new <- function(has_states = c("usa", "canada"), trained = FALSE) {
  check(subclass = "state",
        has_states = has_states,
        trained = trained)
}

prep.check_state <- function(x, training, ...) {
  check_state_new(has_states = x$has_states,
                  trained = TRUE)
}

bake.check_state <- function(object, newdata, ...) {
  invalid_state <- which(newdata[["country"]] %in% object$has_states & is.na(newdata[["region"]]) & !is.na(newdata[["state"]]))
  missing_state <- which(newdata[["country"]] %in% object$has_states & is.na(newdata[["state"]]))
  unsupported_state <- which(newdata[["country"]] == "usa" &
                               newdata[["state"]] %chin% c('hawaii', 'puerto rico', 'alaska', 'hi', 'pr', 'ak') &
                               is.na(newdata[["region"]]))
  dt_add_invalid(newdata, invalid_state, "State")
  dt_add_required(newdata, missing_state, "State")
  dt_rm_evaluations(newdata, unsupported_state)
  dt_rm_errors(newdata, unsupported_state)
  dt_add_skip(newdata, unsupported_state)
  dt_add_message(newdata, unsupported_state, " Unsupported: State")
  newdata
}

# check_country -----------------------------------------------------------


#' Error messages for country
#'
#' See details.
#' @inheritParams step_basic
#' @param allowed A vector of country names. This corresponds to the countries
#' which Fleet Evaluator supports for the category.
#' @param valid Generated on [prep()]. A vector of valid countries pulled from DB.
#' @details
#' * Step: Nothing.
#' * Prep: Check all `allowed` are in `valid`, populate `valid`.
#' * Bake: Make error messages
#'     -- `NA` country: Required
#'     -- country not in `valid`: Invalid
#'     -- not `allowed`: No evaluations at this time.
#'
#' @export
#' @family check functions
check_country <-
  function(recipe,
           allowed,
           trained = FALSE,
           valid = NULL) {
    add_step(recipe,
             check_country_new(
               allowed = allowed,
               trained = trained,
               valid = valid
             ))
  }

check_country_new <-
  function(allowed,
           trained = FALSE,
           valid = NULL) {
    check(
      subclass = "country",
      allowed = allowed,
      trained = trained,
      valid = valid
    )
  }

prep.check_country <- function(x, training, ...) {
  con <- create_server_connection()
  on.exit(odbcClose(con))
  valid <-
    sqlQuery(
      con,
      "SELECT LOWER(Country) as country from dbShared.dbo.country where
      Status = 'ACTIVE';",
      stringsAsFactors = FALSE
    )$country
  if (!all(x$allowed %in% valid)) {
    invalid <- setdiff(x$allowed, valid)
    stop(glue("{invalid} not present in dbShared.dbo.country", call. = FALSE))
  }
  check_country_new(allowed = x$allowed,
                    trained = TRUE,
                    valid)
}
bake.check_country <- function(object, newdata, ...) {
  # Indices which correspond to 1 of 4 cases.
  skip <- newdata[skip_checks == TRUE]
  newdata <- fsetdiff(newdata, skip)
  missing_country <- which(is.na(newdata[["country"]]))
  invalid_country <- setdiff(which(!(newdata[["country"]] %in% object$valid)), missing_country)
  supported_country <- which(newdata[["country"]] %in% object$allowed)
  obs <- seq_len(nrow(newdata))
  unsupported_country <- setdiff(obs, c(supported_country, invalid_country, missing_country))
  newdata <- copy(newdata)
  dt_add_required(newdata, missing_country, "Country")
  dt_add_invalid(newdata, invalid_country, "Country")
  # Removing values for these 2 fields result in "No evaluation at this time" error.
  dt_rm_evaluations(newdata, unsupported_country)
  dt_rm_errors(newdata, unsupported_country)
  dt_add_skip(newdata, unsupported_country)
  dt_add_message(newdata, unsupported_country, " Unsupported: Country")
  rbind(newdata, skip, use.names = TRUE, fill = TRUE)
}


# check_insufficient_data -------------------------------------------------
#' Errors for various insufficient data conditions
#'
#' @inheritParams step_basic
#' @param bad_levels A named `list` or a `data.table` with at least columns
#' `factor`, `level`. Evaluations with priority order less than or equal to 25
#' which contain one of these levels will be removed and receive an error message
#' for that spec, or its source.
#' @param info A subset of `recipe$info`, generated automatically.
#' @param subset  A logical expression which will be executed in the context of the data. Error
#' messages will only be produced for rows which satisfy the criteria. Not that column "skip_checks",
#' has priority, so if `subset == TRUE & skip_checks == TRUE`, the row will not receive an error message
#' from the step. Subsequent steps of the same class will have checks applied if their `subset` evaluates
#' to `TRUE` for a row which has already been checked. To provide a catch-all version, use a
#' subset of `insufficient_data == ""`, which will evaluate all rows which haven't yet received a
#' "Insufficient Data error". To provide a "default" version for rows which were not yet checked,
#' use a logical `&` concatentation of `insufficient_data == ""` with your previous `subset` expressions.
#' @details
#' * Step: Nothing
#' * Prep: Construct all pieces for error-checking before hand. This consists of
#' putting `bad_levels` into the correct shape, determining labels, and separating
#' derived factors, base factors, and derived numerics.
#' * Bake:
#'    1. Derived factors which are missing from `recipe$info$xlevels` whose
#'    source variables are not `NA` will receive an error.
#'    2. Base factors which are not `NA` but not in `recipe$info$xlevels` will
#'     receive an error.
#'    3. Derived numerics which are `NA` when their source factor is not will
#'    receive an error.
#'    4. At this point, any evaluation with a PO <= 25 will have errors removed,
#'    under the presumption they are spurious. This is mostly protection
#'    for using multiple best formulas.
#'    5. If a bad level is found in the listing, an error is added. If the
#'    listing also received PO <= 25, the evaluations are removed.
#'    6. The ValidMakeModel flag is checked if present. If not valid,
#'    an *invalid* error is added, and evaluations are removed.
#'
#' Note that numerics derived from numerics are solely handled by `check_required_fields`.
#'
#'
#' @family check functions
#' @export
#' @importFrom stringr str_c
#' @examples \dontrun{
#' ### This example inspired by Tractor code as of 2019-06-05
#'
#' bad_levels_big <- check_slope_coefficients(data = training_data[class == "big"],
#'                                            model = full_models_big,
#'                                            ratio_bounds = c(0, 0),
#'                                            n_bounds = c(3, 40))
#' bad_levels_small <- check_slope_coefficients(data = training_data[class == "small"],
#'                                              model = full_models_small,
#'                                              ratio_bounds = c(0, 0),
#'                                              n_bounds = c(3, 40))
#'
#' info_big <- gather_info(training_data, full_models_big)
#' info_small <- gather_info(training_data, full_models_small)
#'
#' scoring_one <- recipe(training_data, info = full_info) %>%
#'    bunch_of_steps() %>%
#'    check_required_fields(subset = class == "big, check = info_big$used_vars) %>%
#'    check_required_fields(subset = class == "small, check = info_small$used_vars) %>%
#'    check_required_fields(subset = required_fields == "") %>%
#'    check_country() %>%
#'    check_state() %>%
#'    check_insufficient_data(subset = class == "big", bad_levels = bad_levels_big, info = info_big) %>%
#'    check_insufficient_data(subset = class == "small", bad_levels = bad_levels_small, info = info_small) %>%
#'    more_steps() %>%
#'    prep()
#' }
check_insufficient_data <-
  function(recipe,
           bad_levels = NULL,
           info = NULL,
           subset = NULL,
           trained = FALSE) {
    info <-  if (is.null(info)) {
      recipe$info[c(
        "formula_vars",
        "base_vars",
        "source_vars",
        "derived_vars",
        "xlevels",
        "dependencies",
        "used_vars"
      )]
    } else{
      info[c(
        "formula_vars",
        "base_vars",
        "source_vars",
        "derived_vars",
        "xlevels",
        "dependencies",
        "used_vars"
      )]
    }

    add_step(
      recipe,
      check_insufficient_data_new(
        bad_levels = bad_levels,
        info = info,
        subset = enexpr(subset),
        trained = trained
      )
    )
  }

check_insufficient_data_new <-
  function(bad_levels = NULL,
           info = NULL,
           subset = NULL,
           trained = FALSE) {
    check(
      subclass = "insufficient_data",
      bad_levels = bad_levels,
      info = info,
      subset = subset,
      trained = trained
    )
  }


prep.check_insufficient_data <- function(x, training, ...) {
  if (!is.null(x$subset) && !all((svars <- all.names(x$subset,functions = FALSE)) %in% names(training))) {
    missing_vars <- setdiff(svars,names(training))
    stop("Not all variables used in `subset` exist in the training data at this point.",
         " Please check your data and recipe specification.",
         call. = FALSE)
  }
  if (is.null(x$subset)) {
    subset <- TRUE
  } else {
    subset <- x$subset
  }
  list2env(x$info, envir = environment())
  base_factors <- intersect(names(xlevels), base_vars)
  base_levels <- xlevels[base_factors]
  derived_factors <-
    setdiff(intersect(names(xlevels), derived_vars), "region")
  derived_levels <- xlevels[derived_factors]
  derived_numerics <- setdiff(derived_vars, names(xlevels))
  # Only care about factors which are derived from other factors.
  # `check_required_fields` will catch any errors involving numeric specs.
  #TODO Error
  # Update for n-conditional error messaging. In particular, you can't use vapply because
  # the function has variable length return since each element of dependencies will not be
  # length-1. Probably best to use a for loop and handle conditionally.
  # There is a lot of changes overall for check_insufficient_data, but there are also
  # tests written to verify current behavior. Take a look at these before making changes.
  factor_source <-
    which(tryCatch(
      vapply(derived_factors, function(x)
        !is.numeric(training[[dependencies[[x]]]]), FUN.VALUE = logical(1L), USE.NAMES = FALSE),
      error = function(e)
        integer(0L)
    ))
  # for (k in seq_along(factor_source)) {
  derived_factors <- derived_factors[factor_source]
  derived_levels <- derived_levels[factor_source]
  # }
  # List of derived, labels
  # List of base, labels
  #TODO Error
  # The representation of this will have to change. `source_factors` will have to be a list.,
  # at the very least.
  factor_checks <- list(
    derived_xlevels = derived_levels,
    source_factors = unlist(dependencies[derived_factors], use.names = FALSE),
    derived_labels = change_names(unlist(dependencies[derived_factors],
                                         use.names = FALSE),
                                  from = "r"),
    base_xlevels = base_levels,
    base_labels = change_names(names(base_levels), from = "r")
  )
  # Only need to check ones derived from factors.
  # Numerics from numerics will be picked up by `check_required_fields`.

  #TODO Error
  # This also need to be rewritten because dependency slots are variable length.
  num_from_fctr <- tryCatch({
    derived_numerics_from_fctr <-
      derived_numerics[vapply(derived_numerics, function(x)
        !is.numeric(training[[dependencies[[x]]]]), FUN.VALUE = logical(1L), USE.NAMES = FALSE)]
    data.table(
      derived = derived_numerics_from_fctr,
      source = unlist(dependencies[derived_numerics_from_fctr], use.names = FALSE),
      label = change_names(
        names = unlist(dependencies[derived_numerics_from_fctr], use.names = FALSE),
        from = "r"
      )
    )
  }, error = function(e)
    data.table(NULL))


  # Convert factor = level list to a data.table
  if (!is.data.table(x$bad_levels)) {
    if (length(x$bad_levels) > 0) {
      lens <- lengths(x$bad_levels)
      ind <- seq_along(x$bad_levels)
      nms <- names(x$bad_levels)
      # Creates factor col by repeating each factor as many times as necessary.
      factor_col <-
        sapply(ind, function(x)
          rep(nms[x], lens[x]), USE.NAMES = FALSE)
      # make data.table, label is constructed that way to ensure lengths agree.
      bad_levels <- data.table(
        factor = factor_col,
        level = unlist(x$bad_levels, use.names = FALSE),
        label = rep("", length(factor_col))
      )
    } else  {
      bad_levels <-
        data.table(
          factor = character(0L),
          level = character(0L),
          label = character(0L)
        )
    }
  } else {
    bad_levels <- x$bad_levels
  }
  if (!is.null(x$bad_levels) && nrow(bad_levels) > 0) {
    # If table is passed in make sure it has the correct form.
    stopifnot(c("factor", "level") %chin% names(bad_levels))
    bad_levels <- bad_levels[, c("factor", "level"), with = FALSE]
    # Determine indices of derived
    derived <-
      chmatch(bad_levels[["factor"]], names(dependencies))
    # Get matching dependency name for each derived variable
    sql_derived <-
      change_names(names = unlist(dependencies, use.names = FALSE),
                   from = "r")
    # set a label column with the sql name.
    set(
      x = bad_levels,
      i = which(!is.na(derived)),
      j = "label",
      value = sql_derived[derived[!is.na(derived)]]
    )
    set(
      x = bad_levels,
      i = which(is.na(derived)),
      j = "label",
      value = change_names(names = bad_levels[['factor']][which(is.na(derived))], from = "r")
    )
  }
  # Safeguard to make sure the correct form is passed forward to prevent errors
  # on evaluation.
  if (length(bad_levels) == 0 || nrow(bad_levels) == 0) {
    bad_levels <-
      data.table(factor = character(0L),
                 level = character(0L),
                 label = character(0L))
  }

  # Do some  subsetting to make matters easier on scoring.
  check_insufficient_data_new(
    bad_levels = bad_levels,
    info = list(fctrs = factor_checks,
                num_from_fctr = num_from_fctr),
    subset = subset,
    trained = TRUE
  )

}
#' @importFrom data.table fsetdiff
bake.check_insufficient_data <- function(object, newdata, ...) {
  skip <- newdata[skip_checks == TRUE]
  newdata <- fsetdiff(newdata, skip)
  subset <- newdata[eval(object$subset)]
  newdata <- fsetdiff(newdata, subset)
  if (nrow(subset) > 0) {
    # We want this to remove errors later.
    best <- subset[["priority_order"]] <= 25L
    # Handles factors derived from factors used in the first model -groupings, etc. (not region)
    # Logs an error if the derived factor level isn't in the derived levels from `gather_info`
    # and the source variable is non-missing. If it is missing, `check_required_fields`
    # will handle the error.
    fctrs <- object$info$fctrs
    num_from_fctr <- object$info$num_from_fctr
    derived_fctrs <- names(fctrs$derived_xlevels)
    #TODO Error
    # This loop is what will need changing to support n-conditional error messages.
    # I think it might need to be a double-loop. The 3rd slot of `dt_add_insufficient`
    # will be something like str_c(fctrs$derived_labels[[k]][j], collapse = ','),
    # where each component of `fctrs` is now a list, instead of a vector.
    # Double loops are ugly, but the big concern with them in R is:
    # how many iterations are we doing? If you're doing < 100 and the code uses very low-level
    # functions, the overhead is not going to be noticeable. Here, we're limiting ourselves
    # to some very fast data.table code, then very efficient functions: `[`, `[[`, `which`, etc.
    for (k in seq_along(derived_fctrs)) {
      ind <-
        which(!subset[[derived_fctrs[k]]] %chin% fctrs$derived_xlevels[[k]] &
                !is.na(subset[[fctrs$source_factors[k]]]))
      dt_add_insufficient(subset, ind, fctrs$derived_labels[k])
    }
    # Handles factors passed in and used in first model - transmission, make_model, etc.
    # Logs an error if the factor level isn't present in the xlevels recorded
    # from `gather_info`.
    base_fctrs <- names(fctrs$base_xlevels)
    for (k in seq_along(fctrs$base_xlevels)) {
      ind <- which(!subset[[base_fctrs[k]]] %chin% fctrs$base_xlevels[[k]] & !is.na(subset[[base_fctrs[k]]]))
      dt_add_insufficient(subset, ind, fctrs$base_labels[k])

    }

    # Handles numerics derived from factors which are used in first model.
    # If the derived numeric is missing and the source variable is not, receive
    # an insufficient data error.
    for (k in seq_len(nrow(num_from_fctr))) {
      ind <- which(is.na(subset[[num_from_fctr[["derived"]][k]]]) &
                     !is.na(subset[[num_from_fctr[["source"]][k]]]))
      dt_add_insufficient(subset, ind, string = num_from_fctr[["label"]][k])
    }
    # Remove errors for any listings which received best formula evaluation.
    # This is to account for multiple best formulas, since the error messaging
    # is entirely based off the first formula.
    dt_rm_errors(subset, which(best))

    # Add error, remove evaluations from bad level listings.
    # We only do this for the best formulas. Presumably we are okay showing
    # less than great evaluations for worse formulas.
    bad_levels <- object$bad_levels
    for (k in seq_len(nrow(bad_levels))) {
      bad <-
        subset[[bad_levels[["factor"]][k]]] == bad_levels[["level"]][k]
      dt_rm_evaluations(subset, which(bad & best))
      dt_add_insufficient(subset, which(bad), bad_levels[["label"]][k])
    }

  }

  finaldata <- rbind(newdata, subset, skip, use.names = TRUE, fill = TRUE)

  # Don't need to check if column in table because if it isn't badmm = logical(0),
  # so no rows will get touched.
  badmm <- which(finaldata[["ValidMakeModel"]] == FALSE)
  if (getOption("shtrain.industry", -99) == 28) {
    dt_add_invalid(finaldata,
                   index = badmm,
                   string = "Manufacturer")
  } else {
    dt_add_invalid(finaldata,
                   index = badmm,
                   string = "MakeModel")
  }
  dt_rm_evaluations(finaldata, badmm)

  finaldata
}


# check_required_fields ---------------------------------------------------


#' Error messages for missing values
#'
#' `check_required_fields` creates a *specification* of a recipe step which will
#' add 'RequiredField' error messages for variables.
#' @inheritParams step_basic
#' @param include Vector of column names to check for missing values.
#' @param exclude Vector of column names to exclude. This is for excluding
#' variables that would be put into `check` during [prep()]. "state" will be added
#' to this vector.
#' @param subset A logical expression which will be executed in the context of the data. Error
#' messages will only be produced for rows which satisfy the criteria. Not that column "skip_checks",
#' has priority, so if `subset == TRUE & skip_checks == TRUE`, the row will not receive an error message
#' from the step. Subsequent steps of the same class will have checks applied if their `subset` evaluates
#' to `TRUE` for a row which has already been checked. To provide a catch-all version, use a
#' subset of `required_fields == ""`, which will evaluate all rows which haven't yet received a
#' "Required Fields error". To provide a "default" version for rows which were not yet checked,
#' use a logical `&` concatentation of `required_fields == ""` with your previous `subset` expressions.
#' @param check Auto-populates from `recipe$info$used_vars`. See [gather_info()] for which variables
#' fall into this group. Alternatively, provide a character vector of variables.
#' @export
#' @details
#' * Step: Populate `check` with `recipe$info$used_vars` if not provided.
#' * Prep: Remove `exclude` and "state", add `include`, take unique values, verify all are present in the data.
#' If `check` is provided manually, use that instead. Verify that `check` and `subset` variables reside in the
#' training data.
#' * Bake: If a variable is present in `check`, add RequiredFields error if missing. Only do so for
#' rows where `subset == TRUE & skip_chekcs == FALSE`.
#' @family check functions
#' @examples \dontrun{
#' library(dplyr)
#' library(data.table)
#' library(shtrain)
#' # Names are used internally, populating the reference table.
#' cache_names(r = shtrain:::shdata$name_table$r, sql = shtrain:::shdata$name_table$sql)
#' cache_names(r = 'make_model', sql = "MakeModel")
#' set.seed(702)
#' dt <- data.table(make_model = sample(c(letters[1:4], NA), size = 50, replace = TRUE),
#'                  class = sample(c("big", "small"), size = 50, replace = TRUE),
#'                  important_small_var = NA_character_,
#'                  skip_checks = FALSE, # Indicator fed to `check` functions to skip it.
#'                  required_fields = "") # All error fields are initialized as empty strings
#' cache_names(r = c("class", "enormous_bucket"), sql = c("Class", "Enormous Bucket"))
#' # Add a column, "enormous_bucket", which is small for `class == "small"` but is "yes", "no" or
#' # `NA_character_` for `class == "big"`.
#' dt[,enormous_bucket := dplyr::if_else(class == 'big',
#'                                       true = sample(c("yes", "no", NA_character_),
#'                                                     size = 50,
#'                                                     replace = TRUE),
#'                                       NA_character_)]
#' recipe(dt) %>% check_required_fields(subset = class == "big", check = "enormous_bucket") %>%
#'    check_required_fields(subset = class == "small", check = "important_small_var") %>%
#'    check_required_fields(subset = NULL, check = "make_model") %>%
#'    trained()
#'
#'
#'
#' ### This example inspired by Tractor code as of 2019-06-05
#'
#' bad_levels_big <- check_slope_coefficients(data = training_data[class == "big"],
#'                                            model = full_models_big,
#'                                            ratio_bounds = c(0, 0),
#'                                            n_bounds = c(3, 40))
#' bad_levels_small <- check_slope_coefficients(data = training_data[class == "small"],
#'                                              model = full_models_small,
#'                                              ratio_bounds = c(0, 0),
#'                                              n_bounds = c(3, 40))
#'
#' info_big <- gather_info(training_data, full_models_big)
#' info_small <- gather_info(training_data, full_models_small)
#'
#' scoring_one <- recipe(training_data, info = full_info) %>%
#'    bunch_of_steps() %>%
#'    check_required_fields(subset = class == "big, check = info_big$used_vars) %>%
#'    check_required_fields(subset = class == "small, check = info_small$used_vars) %>%
#'    check_required_fields(subset = required_fields == "") %>%
#'    check_country() %>%
#'    check_state() %>%
#'    check_insufficient_data(subset = class == "big", bad_levels = bad_levels_big, info = info_big) %>%
#'    check_insufficient_data(subset = class == "small", bad_levels = bad_levels_small, info = info_small) %>%
#'    more_steps() %>%
#'    prep()
#' }
check_required_fields <-
  function(recipe,
           include = NULL,
           exclude = NULL,
           subset = NULL,
           check = NULL,
           trained = FALSE) {
    check <- check %||% recipe$info$used_vars
    add_step(
      recipe,
      check_required_fields_new(
        include = include,
        exclude = exclude,
        subset = rlang::enexpr(subset),
        check = check,
        trained = trained
      )
    )
  }



check_required_fields_new <-
  function(include = NULL,
           exclude = NULL,
           subset = NULL,
           check = NULL,
           trained = FALSE) {
    check(
      subclass = "required_fields",
      include = include,
      exclude = exclude,
      subset = subset,
      check = check,
      trained = trained
    )
  }


#' @include internal-utils.R
prep.check_required_fields <- function(x, training, ...) {
  to_check <- setdiff(x$check, c(x$exclude, "state"))
  to_check <- unique(c(to_check, x$include))
  if (!is.null(x$subset) && !all((svars <- all.names(x$subset,functions = FALSE)) %in% names(training))) {
    missing_vars <- setdiff(svars,names(training))
    stop("Not all variables used in `subset` exist in the training data at this point.",
         " Please check your data and recipe specification.",
         call. = FALSE)
  }
 if (is.null(x$subset)) {
   subset <- TRUE
 } else {
   subset <- x$subset
 }
  if (!(all(to_check %in% names(training)))) {
    missing_vars <- setdiff(to_check, names(training))
    stop(
      "Not all `check` variables are in the recipe template at this point.",
      "Please check your data and recipe specification.",
      "Missing: ",
      lc(missing_vars),
      call. = FALSE
    )
  }
  check_required_fields_new(
    include = x$include,
    exclude = x$exclude,
    subset = subset,
    trained = TRUE,
    check = to_check
  )
}

bake.check_required_fields <- function(object, newdata, ...) {
  skip <- newdata[skip_checks == TRUE]
  newdata <- fsetdiff(newdata, skip)
  subset <- newdata[eval(object$subset)]
  newdata <- fsetdiff(newdata, subset)
  if (nrow(subset) > 0) {
  temp_data <-subset[, object$check, with = FALSE]
  setnames(temp_data, change_names(names = names(temp_data), from = "r"))
  missing <- is.na(temp_data)
  has_missing <- which(rowSums(missing) > 0)
  missing_names <- colnames(missing)
  req_field_values <- apply(missing, 1, FUN = function(x) str_c(missing_names[x], collapse = ";"))
  has_error <- which(lengths(req_field_values) > 0)
  subset[has_error, required_fields := str_c(required_fields, req_field_values[has_error], sep = ";")]
  # I think that this might still be faster... dispatches to C immediately.
  # for (k in has_missing) {
  #   set(
  #     x = subset,
  #     i = k,
  #     j = "required_fields",
  #     value = str_c(subset[["required_fields"]][k],str_c(missing_names[missing[k, ]], collapse = ";"),
  #                   sep = ";")
  #   )
  # }
  }
  rbind(newdata, subset, skip, fill = TRUE, use.names = TRUE)
}




# check_requirements ------------------------------------------------------

#' Error messages for listings not meeting requirements
#'
#' Any listing not meeting the requirements which has an evaluation of the
#' specified priority order will lose its evaluation.
#' @inheritParams step_basic
#' @param expr A logical expression, which will be evaluated in the context of the
#' data; i.e. `hours > 100 & hours < 150000`.
#' @param priority_order `NULL` to check all priority orders, or vector of priority orders.
#' @param check Vector of columns which will be checked.
#' @export
#' @family check functions
check_requirements <-
  function(recipe,
           expr,
           priority_order,
           trained = FALSE,
           check = NULL) {
    expr <-  substitute(expr)
    add_step(
      recipe,
      check_requirements_new(
        expr = expr,
        priority_order = priority_order,
        trained = trained,
        check = check
      )
    )
  }



check_requirements_new <-
  function(expr,
           priority_order,
           trained = FALSE,
           check = NULL) {
    check(
      subclass = "requirements",
      expr = expr,
      priority_order = priority_order,
      trained = trained,
      check = check
    )
  }

prep.check_requirements <- function(x, training, ...) {
  check <- all.names(x$expr, functions = FALSE)
  if (!all(check %in% names(training))) {
    not_present <- check[!check %in% names(training)]
    stop(
      glue(
        "{not_present} are not in the training data at this point.
        All variables must be within the training data."
      ),
      call. = FALSE
      )
  }
  check_requirements_new(
    expr = x$expr,
    trained = TRUE,
    priority_order =  x$priority_order,
    check
  )
}

bake.check_requirements <- function(object, newdata, ...) {
  skip <- newdata[skip_checks == TRUE]
  newdata <- fsetdiff(newdata, skip)
  if (!is.null(object$priority_order)) {
    correct_priority <-
      newdata[priority_order %in% object$priority_order, which = TRUE]
  } else {
    correct_priority <- which(!is.na(newdata[["priority_order"]]))
  }
  meets_requirements <-
    newdata[eval(object$expr, envir = parent.frame()), which = TRUE]
  no_eval_at_this_time <-
    setdiff(correct_priority, meets_requirements)
  dt_rm_evaluations(newdata, no_eval_at_this_time)
  dt_add_message(newdata, no_eval_at_this_time, " Requirement Violated")
  rbind(skip, newdata, use.names = TRUE, fill = TRUE)
}




# error helpers -----------------------------------------------------------

#' @title Helpers for common patterns in error message generation
#'
#' @description
#' These functions are internal helpers to perform common tasks when handling
#' FE error generation. They all modify the data in place, so don't need to be
#' assigned back to a variable. If you don't want to modify in place, do `copy` first.
#' @name dt_error_helpers
#'
NULL

# These functions are internal helpers to perform common tasks when handling
# FE error generation. They all modify the data in place, so don't need to be
# assigned back to a variable. If you don't want to modify in place, do `copy` first.

#' Removes evaluations by reference
#'
#' `dt_rm_evaluations` takes the data, an index, and updates (by reference)
#' the 'evaluation' and 'priority_order' columns to NA.
#' @rdname dt_error_helpers
#' @export
dt_rm_evaluations <- function(data, index) {
  if (length(index) == 0) {
    return(invisible(data))
  }
  new_evals <- intersect(names(data), c("evaluation_asking", "evaluation_auction",
                                        "evaluation_aftersale"))
  if (length(new_evals) > 0) {
    set(x = data,
        i = index,
        j = c(new_evals, "priority_order"),
        value = NA_real_)
  } else {
    set(x = data,
        i = index,
        j = c("evaluation", "priority_order"),
        value = NA_real_)
  }
  invisible(data)
}

#' Removes errors by reference
#'
#' `dt_rm_errors()` takes the data, an index, and updates (by reference)
#' the 'required_fields' and 'invalid_columns' columns to `""`. This is useful
#' to trigger the "No evaluations at this time" error message in FE.
#' @rdname dt_error_helpers
dt_rm_errors <- function(data, index) {
  if (length(index) == 0) {
    return(invisible(data))
  }
  set(x = data,
      i = index,
      j = c("required_fields", "invalid_data", "insufficient_data"),
      value = "")
  invisible(data)
}

#' Adds message by reference
#'
#' `dt_add_message()` appends a string to the  "r_message" column.
#' @param data The `data.table`.
#' @param index An index, usually constructed with a logical predicate and `which`.
#' @param string A character vector of length  1 or length of the index.
#' @return Updated data, invisibly.
dt_add_message <- function(data, index, string) {
  dt_add(data = data, col = "r_message", index = index, string = string)
}

dt_add_required <- function(data, index, string) {
  dt_add(data = data, col = "required_fields", index = index, string = string)
}

dt_add_invalid <- function(data, index, string) {
  dt_add(data = data, col = "invalid_data", index = index, string = string)
}
dt_add_insufficient <- function(data, index, string) {
  dt_add(data = data, col = "insufficient_data", index = index, string = string)
}

dt_add <- function(data, col, index, string) {
  if (length(index) == 0) {
    if (!is.null(index)) {
      invisible(data)
    } else {
      set(x = data,
          i = index,
          j = col,
          value = str_c(data[[col]], string, sep = ";"))
      invisible(data)
    }
  } else {
    set(x = data,
        i = index,
        j = col,
        value = str_c(data[[col]][index], string, sep = ";"))
    invisible(data)
  }
}

#' Adds "skip_checks" by reference
#'
#' `dt_add_skip()` adds a logical column used by error-checking
#' functions to ignore those marked `TRUE`. This is useful when
#' a particular type of error is generated, and nothing else needs to be
#' checked. For example, if `condition == "new"` for a listing, there
#' is no reason to continue checking.
#' @rdname dt_error_helpers
#' @export
dt_add_skip <- function(data, index) {
  if (length(index) == 0 && !is.null(index)) {
    invisible(data)
  } else {
    set(x = data,
        i = index,
        j = "skip_checks",
        value = TRUE)
  }
  invisible(data)
}
