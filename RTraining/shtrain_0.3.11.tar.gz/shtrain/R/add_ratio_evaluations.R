
#' Adds additional evaluation columns
#'
#' Adds additional evaluation columns to the data. Looks within the data for exactly
#' one evaluation column, and at least one ratio column, and generates additional
#' evaluation columns based on this information. All evaluation and ratio columns
#' should be named 'evaluation_{data_type}' or ratio_{data_type}'.
#'
#' @inheritParams step_basic
#' @param eval A column of evaluations in the data produced by [add_evaluations()].
#' Generated in the prep step.
#' @param col A list of evaluation columns to be created and added to the data,
#' named with the appropriate ratio column used to compute the evaluation.
#' Generated in the prep step.
#' @export
#' @family step functions
#' @details
#' * Step: Nothing
#' * Prep: Generates a list of evaluation columns to be created and added to the
#' data, named with the appropriate ratio column used to compute the evaluation.
#' Also identifies the original evaluation column for reference in [bake()].
#' * Bake: Uses the existing evaluation and ratio columns to compute and name
#' remaining evaluations needed.
#' @examples \dontrun{
#' dt <- data.table(evaluation_aftersale = 50000, ratio_auction = 0.5, ratio_asking = 1.2)
#' recipe(dt) %>%
#'   add_ratio_evaluations()
#'   trained()
#' }
add_ratio_evaluations <- function(recipe, trained = FALSE, eval = NULL, col = NULL) {
  add_step(recipe,
                     add_ratio_evaluations_new(
                       trained = trained,
                       eval = eval,
                       col = col
                     )
  )
}

add_ratio_evaluations_new <- function(trained = FALSE, eval = NULL, col = NULL) {
  add(subclass = "ratio_evaluations",
                trained = trained,
                eval = eval,
                col = col
  )
}

prep.add_ratio_evaluations <- function(x, training, ...) {

  eval <- str_subset(names(training), "evaluation_")
  if (length(eval) > 1) {
    eval_2 <- str_c(eval, collapse = ", ")
    stop(glue("Multiple evaluation columns found: {stringr::str_c('[', eval_2, ']', collapse = ', ')}.\n`add_ratio_evaluations()` expects exactly one evaluation column."), call. = FALSE)
  }
  if (length(eval) < 1) {
    eval_2 <- str_c(eval, collapse = ", ")
    stop("No evaluation column found.\nMake sure add_evaluations() is called prior to add_ratio_evaluations().", call. = FALSE)
  }


  ratios <- str_subset(names(training), "ratio_")
  if (length(ratios) < 1) {
    stop("No ratio columns found. Ratio columns should be named 'ratio_{data_type}'.", call. = FALSE)
  }
  bad_names <- ratios[str_count(ratios, "_") > 1]
  bad_names_2 <- str_c(bad_names, collapse = ", ")
  if (length(bad_names) > 1 & interactive()) {
    warning(str_c(glue("Improper ratio names.\n{bad_names_2} should be renamed in the form "), "'ratio_{data_type}'."), call. = FALSE)
  }


  col <- vector("list", length(ratios))
  names(col) <- ratios
  for (j in seq_along(ratios)) {
    col[[j]] = c(str_c("evaluation_", str_sub(ratios[j], 7)))
  }

  if (interactive()) {
    names_eval <- str_c(col, collapse = ", ")
    names_ratio <- str_c(names(col), collapse = ", ")
    message(glue("Adding {stringr::str_c('[', names_eval, ']', collapse = ', ')} to data using [{eval}] and {stringr::str_c('[', names_ratio, ']', collapse = ', ')}."))
  }
  add_ratio_evaluations_new(
    trained = TRUE,
    eval,
    col
  )
}

bake.add_ratio_evaluations <- function(object, newdata, ...) {

  col <- object$col
  eval <- object$eval

  for (j in seq_along(names(col))) {
    set(x = newdata,
        i = NULL,
        j = col[[j]],
        value = newdata[[eval]]*newdata[[names(col)[j]]]
    )
  }

  newdata

}
