#' Adds count by groups
#'
#' `add_count()` will perform counts by `by` group and add a column `new_col` based
#' on the tabulations to the data.
#' @inheritParams step_basic
#' @param by A list of unquoted names from the `data` provided to [recipe()].
#' @param new_col Optional. Defaults to `paste0(paste0(by, collapse = "_") "_count")`.
#' @param ref_count Generated on [prep()]. Contains the `by` columns and `new_col`.
#' @details
#' * Step: check `by` is a list.
#' * Prep: Create table of counts relative to `by`.
#' * Bake: Merge to this table based on `by`. Anything which does not fall into a
#'  group will be assigned a count of 0.
#' @export
add_count <- function(recipe, by, new_col = NULL, ref_count = NULL, trained = FALSE) {
  by <- substitute(by)
  by_list <- any(grepl("list", by))
  if (!by_list) {
    stop("Please provide `by` a list of unquoted column names.")
  }
  add_step(recipe,
           add_count_new(
             by = by,
             new_col = new_col,
             ref_count = ref_count,
             trained = trained
           ))
}

add_count_new <- function(by, new_col = NULL, ref_count = NULL, trained = FALSE) {
  add(subclass = "count",
      by = by,
      new_col = new_col,
      ref_count = ref_count,
      trained = trained)
}

#' @importFrom data.table :=
prep.add_count <- function(x, training, ...) {
  training <- copy(training)
  if (is.null(x$new_col)) {
    new_col <- paste0(paste0(as.character(x$by)[-1], collapse = "_"), "_", "count")
  } else {
    new_col <- x$new_col
  }
  ref <- unique(training[, (new_col) := .N, by = eval(x$by)][,c(new_col, as.character(x$by)[-1]), with = FALSE])
  add_count_new(by = x$by,
                new_col = new_col,
                ref_count = ref,
                trained = TRUE)
}

bake.add_count <- function(object, newdata, ...) {
  data <- merge(newdata, object$ref_count, by = as.character(object$by)[-1], all.x = TRUE)
  for (k in object$new_col) {
    set(x = data,
        i = which(is.na(data[[k]])),
        j = k,
        value = 0)
  }
data
}
