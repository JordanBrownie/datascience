#' Joins by nearest value
#'
#' Uses [data.table::data.table()]'s rolling join functionality
#' to allow matching on all but the last column specified in `on`. Can condense
#' the lookup table to only those rows needed to successfully complete the rolling-join,
#' *assuming `roll` is set to `Inf` or "nearest"*.
#'
#' @inheritParams step_basic
#' @param x A data.table to join the training data to. After calling [prep()],
#' this will be replaced with a table which has been reduced in size. See details.
#' @param on See [data.table::data.table()] for documentation.
#' @param roll See [data.table::data.table()] for documentation.
#' @param rollends See [data.table::data.table()] for documentation.
#' @param condense Defaults to `TRUE`, which will remove duplicated rows by all columns
#' except the rolling-join column. If `roll == Inf` or `roll == "nearest"`, you will get the same results form
#' the join with either `TRUE` or `FALSE`.
#' table
#' @details
#'
#' * Step: No action taken.
#' * Prep: The table is keyed based on the join columns in `on`. Unique rows
#' are taken based on everything but the rolling-join column. This reduces rows
#' where the ratios or values associated with the group are constant.
#' * Bake: The data is joined to `x` on all columns. If a record matches all but
#' the last join column, it will match to a row in `x` if a row exists which falls
#' within `roll` distance. For dates, `roll` represents the number of days.
#'
#' @export
#' @importFrom glue glue
#' @importFrom data.table setkeyv copy data.table
#' @include recipes.R
#' @include steps.R
#' @examples \dontrun{
#' dt <- data.table(x = letters,
#'                  date = seq(as.Date("2015-01-01"), by = "1 day", length.out = 26))
#' lookup <- data.table(value = 1:10,
#'                      date = seq(as.Date("2014-12-31"), by = "5 days", length.out = 10))
#' # These are equivalent
#'  dt_value <- lookup[dt, on = 'date', roll = 2, rollends = rep(TRUE, 2)]
#'  step_value <- recipe(dt) %>%
#'    step_roll_join(lookup, on = "date", roll = 2, rollends = rep(TRUE, 2)) %>%
#'    trained()
#' }
step_roll_join <- function(recipe, x, on, roll = 5, rollends = c(TRUE, TRUE), condense = TRUE, trained = FALSE) {
  add_step(recipe, step("roll_join",
                                            x = x, on = on, roll = roll, rollends = rollends,  condense = condense, trained = trained))
}

prep.step_roll_join <- function(x, training, ...) {
  roll_col <- x$on[length(x$on)]
  lookup <- copy(x$x)
  setkeyv(lookup, x$on)
  other_join_cols <- setdiff(x$on, roll_col)
  other_cols <- setdiff(names(lookup), roll_col)
  if (length(other_cols) == 0) {
    stop("No columns exist for the rolling-join aside from the join columns.",
         "At least one additional column must be present.")
  }
  if (x$condense == TRUE) {
    if (length(other_join_cols)) {
      orig_rows <- lookup[,.N, by = other_join_cols]
      lookup <- unique(lookup, by = other_cols)
      new_rows <- lookup[,.N, by = other_join_cols]
    } else {
      orig_rows <- lookup[,.N]
      lookup <- unique(lookup, by = other_cols)
      new_rows <- lookup[,.N]
    }
    if (interactive() || getOption("shtrain.verbose", FALSE)) {
      if (length(other_join_cols)) {
        row_compare <- merge(orig_rows, new_rows, by = other_join_cols)
      } else {
        row_compare <- data.table(N.x = orig_rows, N.y = new_rows)
      }
      rc <- row_compare[,list(max_rm = max(N.x - N.y, na.rm = TRUE),
                              min_rm = min(N.x - N.y, na.rm = TRUE),
                              mean_rm = mean(N.x - N.y, na.rm = TRUE),
                              n_groups = .N)]
      if (is.data.table(orig_rows)) {
        orig_rows_total <- orig_rows[,sum(N, na.rm = TRUE)]
        new_rows_total <- new_rows[,sum(N, na.rm = TRUE)]
      } else {
       orig_rows_total <- orig_rows
       new_rows_total <- new_rows
      }
      message(glue::glue("step_roll_join:
      From {rc$n_groups} groups, each group had {rc$min_rm} to {rc$max_rm} \\
      rows removed, with an average of {round(rc$mean_rm,2)} removed, for a total \\
      of {orig_rows_total - new_rows_total}."))
    }
  }
  step("roll_join",
                 x = lookup, on = x$on, roll = x$roll, rollends = x$rollends, condense = x$condense, trained = TRUE)
}

bake.step_roll_join <- function(object, newdata, ...) {
  object$x[newdata, on = object$on, roll = object$roll, rollends = object$rollends]

}


