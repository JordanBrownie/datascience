#' Adds recommended spec fields to data
#'
#' Adds a new receommended spec column for each spec in `col` using a prefix of "rec_". 
#
#' @inheritParams step_basic
#'
#' @param col Character vector of spec names to provide recommendations for.
#' @param vars Internal parameter - generated automatically.
#' @inherit step_basic return
#' @export
#' @details
#' * Step: Populates `step$vars` with `recipe$info$used_vars`.
#' * Prep: Checks that all columns in `step$col` exist in `step$vars`, 
#' exist in the data, and have SQL names in `shref$name_cache`.
#' * Bake: Adds NA_real_ or NA_character_ "rec_" spec columns.
add_rec_spec <- function(recipe, col, trained = FALSE, vars = NULL) {
  shtrain:::add_step(recipe,
                     add_rec_spec_new(
                       col = col,
                       trained = FALSE,
                       vars = recipe$info$used_vars)
  )
}

add_rec_spec_new <- function(col, trained = FALSE, vars = NULL) {
  shtrain:::add(subclass = "rec_spec",
                col = col,
                trained = trained,
                vars = vars)
}

prep.add_rec_spec <- function(x, training, ...) {
  if (!all(x$col %in% x$vars)) {
    stop(glue::glue("{str_c(setdiff(x$col, x$vars), collapse = ', ')} supplied in `col` but not found in `recipe$info$used_vars`."), call. = FALSE)
  }
  if (!all(x$col %in% names(training))) {
    stop(glue::glue("{str_c(setdiff(x$col, names(training)), collapse = ', ')} supplied in `col` but not found in data."), call. = FALSE)
  }
  if (!all(x$col %in% shtrain:::shref$name_cache$r)) {
    stop(glue::glue("Please provide SQL names for {str_c(x$col, collapse = ', ')} using `cache_names()`."), call. = FALSE)
  }
  if (interactive()) {
    message(glue::glue("Adding {str_c('rec_', x$col, collapse = ', ')} to data."))
  }
  
  add_rec_spec_new(col = x$col,
                   trained = TRUE)
}

bake.add_rec_spec <- function(object, newdata, ...) {
  temp_list <- lapply(newdata[,object$col, with = FALSE], class)
  temp_dt <- data.table(spec = names(temp_list), type = unlist(temp_list, use.names = FALSE))
  temp_dt[,spec := str_c("rec_", spec)]
  
  num_spec <- temp_dt[type == "numeric", spec]
  char_spec <- temp_dt[type == "character", spec]
  
  if (length(num_spec) > 0) {
    set(x = newdata,
        i = NULL,
        j = num_spec,
        value = NA_real_)
  }
  if (length(char_spec) > 0) {
    set(x = newdata,
        i = NULL,
        j = char_spec,
        value = NA_character_)
  }
  
  newdata
}