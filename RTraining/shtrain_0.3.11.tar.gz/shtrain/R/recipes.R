#' Formally defines pre-processing steps
#'
#' Construct to retain information from training data to apply on scoring.
#' A recipe consists of a series of steps which will be ran sequentially.
#' Each step will first be run through [prep()] to retain any information
#' needed from the training data. [bake()] performs the modifications to the
#' the data.
#' @param x Training data, either a `data.frame` or `data.table`.
#' @param info Pass `gather_info(data, models)`.
#'
#' @seealso prep.recipe bake.recipe
#' @export
recipe <- function(x, info = NULL, ...) {
  UseMethod("recipe")
}
recipe.default <- function(x, info, ...) {
  stop("Input data must be a data.table.")
}
#' @export
recipe.data.table <- function(x, info = NULL, ...) {
  out <- list(template = copy(x), steps = NULL, info = info, trained = NULL, ...)
  if ("models" %in% names(out)) {
    out[["info"]] <- gather_info(out[["template"]], models = out[["models"]])
  }
  class(out) <- "recipe"
  out
}
#' @importFrom data.table as.data.table
#' @export
recipe.data.frame <- function(x, ...) {
  x   <- as.data.table(x, stringsAsFactors = FALSE)
  recipe.data.table(x, ...)
}


add_step <- function(rec, object) {
  rec$steps[[length(rec$steps) + 1]] <- object
  rec
}

is.recipe <- function(x) {
  "recipe" %in% class(x)
}

#' Bake a recipe
#'
#' Applies steps to the supplied data.
#' @param object 'recipe' or 'step' object.
#' @export
bake <- function(object, ...) {
  UseMethod("bake")
}
#' Prepare a recipe
#'
#' Computes all information necessary from training data for each step. The
#' recipe can then be re-applied to new (or the same) data using [bake()].
#'
#' @param x A [recipe()].
#' @export
prep <- function(x, ...) {
  UseMethod("prep")
}

#' Applies recipe to a data set
#'
#' Applies a recipe which has been prepared using [prep()] to
#' `newdata`.
#' @param object An object of class "recipe".
#' @param newdata A set of data to process. Defaults to the training data
#' the recipe was made with.
#' @return `newdata` modified according to the steps in the recipe.
#' @rdname bake
#' @export
#' @details
#' `bake.recipe` simply iterates through the steps of the recipe and bakes
#' each individually.
bake.recipe <- function(object, newdata = object$template, ...) {
newdata <- copy(newdata)
  for (i in seq_along(object$steps)) {
    newdata <- bake(object$steps[[i]], newdata = newdata)
  }
  newdata
}

#' Trains a recipe
#'
#' Each step in the recipe is populated with the information it needs
#' from the `training` data.
#'
#' @param x A recipe object.
#' @param training Training data to use during [prep()].
#' @param info Output of [gather_info()].
#' @param retain Logical. If `TRUE`, it will [prep()] and [bake()] the training
#' data and store in `recipe$trained`.
#' @return An updated recipe with each step trained. The steps can be accessed
#' by name once they have been trained. The names are constructed from the step
#' name and a sequence of numbers as necessary.
#' @export
#' @rdname prep
#' @importFrom rlang has_length
prep.recipe <- function(x, training = NULL, info = x$info, retain = FALSE, ...) {
  if (is.null(training)) {
    training <- x$template
  }
  if (prepped(x)) {
    return(x)
  }
  training <- copy(training)
  for (i in seq_along(x$steps)) {
    if (!x$steps[[i]]$trained) {
      x$steps[[i]] <- prep(x$steps[[i]], training = training, ...)
      training <- suppressMessages(bake(x$steps[[i]], newdata = training))
    }
  }
  if (retain == TRUE) {
    x$trained <- training
  }
  if (rlang::has_length(x$steps)) {
  names(x$steps) <- unlist(lapply(x$steps, function(x) class(x)[1]), recursive = FALSE, use.names = FALSE)
  names(x$steps) <- make.unique(names(x$steps), sep = "_")
  }
  x
}

#' Prep a recipe and extract baked training data
#'
#' Takes a recipe, prepped or unprepped, and returns the [bake()]d template data.
#' Quicker than `prep(recipe) %>% bake()`, more convenient than
#' `prep(recipe, retain = TRUE) %>% bake()`
#' @param recipe An object of class [recipe()].
#' @return The [bake()]d training data originally provided to the recipe.
#' @export
trained <- function(recipe) {
  prep(recipe, retain = TRUE)$trained
}
#' Untested summarying of a recipe
#'
#' @rdname summary
summary.recipe <- function(x, step = NA, ...) {
  n_steps <- length(x$steps)
  if (n_steps == 0) {
    stop("Empty recipe.", call. = FALSE)
  }
  if (is.null(names(x$steps))) {
    names(x$steps) <- unlist(lapply(x$steps, function(x) class(x)[1]), recursive = FALSE, use.names = FALSE)
    names(x$steps) <- make.unique(names(x$steps), sep = "_")
  }
 if (is.na(step)) {
   pattern <- "(^step_)|(^check_)|(^filter_)|(^validate_)|(^add_)|(^merge_)|(^format_)"
   classes <- unlist(lapply(x$steps, FUN = function(x) {class(x)[1]}))
   types <- grep(pattern, classes, value = TRUE)
   operation <- gsub(pattern, "", classes)
   trained <- vapply(x$steps, function(x) x$trained, logical(1))
   dt <- data.table(number = seq_along(x$steps),
                    type = types,
                    operation = operation,
                    trained = trained)
 } else {
   if (!(step %in% names(x$steps))) {
     stop("Invalid step name. Names are constructed by step name and appending a number as necessary")
   } else {
     summary(x$steps[[step]])
   }
 }
}


prepped <- function(x) {
  all(vapply(x$steps, is_trained, logical(1L), USE.NAMES = FALSE))
}