#' Scales numeric specs to be in the correct base unit.
#'
#' `cleanse_numerics` is a function
#' that will scale a particular numeric column to the correct base_unit.
#' @param col Column that needs to be scaled to the correct base unit.
#' @param unit A named vector including the measurement label(s) for the unit(s)
#' and the appropriate bound(s) with respect to the unit. See details.
#' @param base_unit A named vector including the measurement label for the base unit
#' and the appropriate bound with respect to the base unit. See details.
#' @param measurements The measurement table that stores the units and base units as well as the conversions needed for scaling values.
#' @details
#'
#' Any value strictly lower than the bound for the unit value supplied will be scaled to the base unit. Any value strictly higher
#' than the bound for the base unit value supplied will be scaled down, as the entered value was most likely scaled correctly initially but given
#' the wrong unit label and scaled again.
#'
#' @export
#' @import stringr
#' @importFrom data.table copy set
#' @importFrom RODBC odbcClose sqlQuery
#' @importFrom data.table is.data.table
cleanse_numerics <- function(data, col, unit = c(label = value), base_unit = c(label = value), measurements = NULL){
  stopifnot(is.data.table(data))
  data <- copy(data)
  nu <- tolower(names(unit))
  nbu <- tolower(names(base_unit))
  if (is.null(measurements)) {
  dbhandle <- shtrain:::create_server_connection()
  on.exit(odbcClose(dbhandle))
  measurements <- sqlQuery(dbhandle,"SELECT Unit AS unit, BaseUnit AS base_unit, MultiplyBy AS multiply_by, UnitGroup AS unit_group
                          FROM dbMMM.dbo.MeasurementUnit MU(NOLOCK);",
                          stringsAsFactors = FALSE)
  # Add special case unit values here. If we end up with 3+ special cases maybe we want to rethink this.
  if (nbu == "pound") {
    measurements <- rbind(measurements, data.table(unit = "half ton", base_unit = "pound", multiply_by = 1000L, unit_group = "mass"))
  }
  measurements <- measurements[measurements$base_unit == nbu & measurements$unit == nu,]
  }
  # Adjusts values which are determined to be too large or too small.
  lt_lower <- which(data[[col]] < unit)
  gt_upper <- which(data[[col]] > base_unit)
  set(x = data,
      i = lt_lower,
      j = col,
      value = data[[col]][lt_lower]*measurements[, "multiply_by"])
  set(x = data,
      i = gt_upper,
      j = col,
      value = data[[col]][gt_upper]/measurements[, "multiply_by"])
  data
}

#' Swaps numeric columns that are related to one another.
#'
#' `swap_columns` is a function
#' that will swap two numeric columns based on the relationship between specs.
#' @param data Data.table that contains the specs that need to be swapped.
#' @param large character string spec name that is known to be the larger of the two specs.
#' @param small character string spec name that is know to be the smaller of the two specs.
#' @param split The cutoff that can be used if only one column is populated to identify which column the value belongs in if there is a
#' distinct separation in values between the two specs.
#' @details
#'
#' This function will swap spec values when there is a known relationship between specs.  You pass in both specs distinguishing
#' which specs should be the larger and smaller of the two.  Values that are the same will not change and when only one column is filled
#' out the split cutoff determines which column the value should go in.
#'
#' @export
#' @examples
#' shtrain::swap_columns(data, "length", "width")
#' @import stringr
#' @importFrom data.table copy set
swap_columns <- function(data, large, small, split = NULL ) {
   data <- copy(data)
   to_switch <- which(data[[large]] < data[[small]])
   larger <- data[[small]][to_switch]
   smaller <- data[[large]][to_switch]
   set(x = data,
       i = to_switch,
       j = large,
       value = larger
   )
   set(x = data,
       i = to_switch,
       j = small,
       value = smaller)
   if (!is.null(split)) {
     too_large <- which(data[[small]] > split)
     set(x = data,
         i = too_large,
         j = large,
         value = data[[small]][too_large])
     set(x = data,
         i = too_large,
         j = small,
         value = NA)
     too_small <- which(data[[large]] < split)
     set(x = data,
         i = too_small,
         j = small,
         value = data[[large]][too_small])
     set(x = data,
         i = too_small,
         j = large,
         value = NA)
   }
   data
}

#' Strips ft in labels from dimension specs on evaluation.
#'
#' `strip_ft_in` strips any unnecessary "ft", "in" labels from
#' numeric dimension specs and will be specifically used for evaluation.
#' @param data Data.table that contains the specs that need to be swapped.
#' @param col Column to remove feet and inch labels from.
#' @export
#' @import stringr
#' @importFrom data.table copy set
strip_ft_in <- function(data, col){
  data <- copy(data)
  ft_in <- str_which(data[[col]], "\\d'\\s?\\d\"|\\dft\\s?\\din")
  set(x = data,
      i = ft_in,
      j = col,
      value = as.character(as.numeric(str_extract(data[[col]][ft_in], "\\d+(?=[f']\\w?\\s?\\d[\"i])"))*12 + as.numeric(str_extract(data[[col]][ft_in], "(?<!\\-\\d{1,2}')\\d+(?=i|\")"))))
  ft <- str_which(data[[col]], "feet|ft|'")
  set(x = data,
      i = ft,
      j = col,
      value = str_extract(data[[col]][ft], "\\d+"))
  inch <- str_which(data[[col]], "inch|in|\"")
  set(x = data,
      i = inch,
      j = col,
      value = str_extract(data[[col]][inch], "\\d+"))
  num <- str_which(data[[col]], "^\\d$")
  set(x = data,
      i = num,
      j = col,
      value = str_extract(data[[col]][num], "\\d+"))
  data
}


can_be_numeric <- function(x) {
  if (is.numeric(x)) {
    ret <- TRUE
  } else {
    ret <- sum(str_detect(x, "[^0-9\\,\\.]"), na.rm = TRUE) == 0
  }
  ret
}