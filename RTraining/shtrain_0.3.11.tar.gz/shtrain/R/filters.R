
# Filters -----------------------------------------------------------------




#' Filter outlying sale prices
#'
#' Removes listings outside the bounds specified.
#' Does not affect `NA`-valued listings.
#' @inheritParams step_basic
#' @param lower The lower bound. Not included.
#' @param upper The upper bound. Not included.
#' @include recipes.R
#' @include steps.R
#' @family filter steps
#' @export
filter_usd_sale_price <- function(recipe, lower, upper, trained = FALSE) {
  add_step(recipe,
           filterat(subclass = "usd_sale_price",
                    lower = lower,
                    upper = upper,
                    trained = trained
           ))
}



bake.filter_usd_sale_price <- function(object, newdata, ...) {
  update_used_filters()
  newdata[usd_sale_price > object$lower & usd_sale_price < object$upper | is.na(usd_sale_price)]
}

#' @describeIn filter_usd_sale_price Non-recipe version.
#' @export
.filter_usd_sale_price <- function(data, lower = 500, upper = Inf) {
  data[usd_sale_price > lower & usd_sale_price < upper | is.na(usd_sale_price)]
}



#' Removes listings not in allowed countries
#'
#' Removes listings not in allowed countries. Removes `NA`-valued listings.
#' @inheritParams step_basic
#' @param include Vector of countries to include. Uses 'canada' and 'usa' by default.
#' @include recipes.R
#' @include steps.R
#' @family filter steps
#' @export
filter_country <- function(recipe, include = NULL, trained = FALSE) {
  add_step(recipe,
           filterat(subclass = "country",
                    include = include,
                    trained = trained))
}


bake.filter_country <- function(object, newdata, ...) {
  update_used_filters()
  newdata[country %in% c(c("usa", "canada"), object$include)]
}

#' @export
#' @describeIn filter_country Non-recipe version.
.filter_country <- function(data, include = NULL) {
  data <- data[country %in% c(c("usa", "canada"), include)]
  update_used_filters()
  data
}


#' Removes aftersale listings marked as excluded
#'
#' Removes aftersale listings marked as excluded in `dbPostSale.dbo.PostSale`. They were
#' marked because they exceeded the historical hi/lo average
#' by cat year make model. Removes `NA`-valued listings. The prices
#' on these aren't necessarily bad, but they could mark an outlier
#' machine in some other respect. These are excluded before training,
#' but could possibly be used for spec imputation.
#' @inheritParams step_basic
#' @include recipes.R
#' @include steps.R
#' @family filter steps
#' @family aftersale filters
#' @export
filter_exclude_hi_lo_avg <- function(recipe, trained = FALSE) {
  add_step(recipe,
           filterat(subclass = "exclude_hi_lo_avg",
                    trained = trained))
}

bake.filter_exclude_hi_lo_avg <- function(object, newdata, ...) {
  update_used_filters()
  newdata[auction() | asking() | exclude_hi_lo_avg == 0]
}

#' @export
#' @describeIn filter_exclude_hi_lo_avg Non-recipe version.
.filter_exclude_hi_lo_avg <- function(data) {
  data <- data[auction() |
                 asking() |
                 exclude_hi_lo_avg == 0]
  update_used_filters()
  data
}


#' Removes listings with condition other than 'used'
#'
#' Removes machines which are not used. Removes `NA`-valued listings. We typically
#' remove these because FleetEvaluator formulas are meant to value used machinery,
#' and new machines are outliers in terms of usage specs and price. See
#' `dbPostSale.dbo.StringMap` for the full list of conditions.
#' @inheritParams step_basic
#' @include recipes.R
#' @include steps.R
#' @family filter steps
#' @export
filter_condition <- function(recipe, trained = FALSE) {
  add_step(recipe,
           filterat(subclass = "condition",
                    trained = trained))
}


bake.filter_condition <- function(object, newdata, ...) {
  update_used_filters()
  newdata[condition == "used"]
}

#' @describeIn filter_condition Non-recipe version.
#' @export
.filter_condition <- function(data) {
  data <- data[condition == "used"]
  update_used_filters()
  data
}


#' Removes listings which are older than specified
#'
#' Removes listings which are older than the specified
#' listing date. Removes listings with a sale date later than `end_date`, which
#' defaults to today.
#' Does remove listings missing `sale_date`, so use [add_date()] before using this.
#' We typically filter to a time-window on training because it has offered improved
#' results.
#' @inheritParams step_basic
#' @param years Number of years to look back for included listings.
#' @param start_date A different way to specify the filter. Provide in yyyy-mm-dd format.
#' @param end_date A different way to specify the filter. Provide in yyyy-mm-dd format.
#' @include recipes.R
#' @include steps.R
#' @family filter steps
#' @export
filter_sale_date <- function(recipe, years = 3, start_date = NULL, end_date = NULL, trained = FALSE) {
  add_step(recipe,
           filterat(subclass = "sale_date",
                    years = years,
                    start_date = start_date,
                    end_date = end_date,
                    trained = trained))
}

bake.filter_sale_date <- function(object, newdata, ...) {
  end_date <- add_default(object$end_date, as.IDate(Sys.Date(), origin = '1753-01-01'))
  if (is.null(object$start_date)) {
    newdata <- newdata[sale_date >= end_date - 365*object$years & sale_date <= end_date]
    newdata <- newdata[!auction() | sale_date < as.IDate(Sys.Date(), origin = "1753-01-01")]
  } else {
    newdata <- newdata[sale_date >= object$start_date & sale_date <= end_date]
    newdata <- newdata[!auction() | sale_date < as.IDate(Sys.Date(), origin = "1753-01-01")]
  }
  update_used_filters()
  newdata
}

#' @export
#' @describeIn filter_sale_date Non-recipe version.
.filter_sale_date <- function(data, years = 3, start_date = NULL, end_date = NULL) {
  end_date <- add_default(end_date, as.IDate(Sys.Date(), origin = '1753-01-01'))
  if (is.null(start_date)) {
    data <-  data[sale_date >= end_date - 365*years & sale_date <= end_date]
    data <- data[!auction() | sale_date < as.IDate(Sys.Date(), origin = "1753-01-01")]
  } else {
    data <- data[sale_date >= start_date & sale_date <= end_date]
    data <- data[!auction() | sale_date < as.IDate(Sys.Date(), origin = "1753-01-01")]
  }

  update_used_filters()
  data
}

#' Removes aftersale listings from a bad company
#'
#' Removes aftersale listings whose company ID is
#' registered as bad in SQL. Removes `NA`-valued listings, although
#' every aftersale listing should be attached to a company
#' @inheritParams step_basic
#' @include recipes.R
#' @include steps.R
#' @family filter steps
#' @family aftersale filters
#' @details The companies who are added to the relevant table
#' are either known to provide bad sale information or opted
#' out of MarketTrends. The actual listing data should be good for
#' any computation unrelated to price.
#' @export
filter_company_id <- function(recipe, trained = FALSE) {
  add_step(recipe,
           filterat(subclass = "company_id",
                    trained = trained))
}

#' @importFrom RODBC sqlQuery
bake.filter_company_id <- function(object, newdata, ...) {
  update_used_filters()
  con <- create_server_connection()
  on.exit(odbcClose(con))
  excluded_company_ids <- sqlQuery(con,
                                   "SELECT CompanyID from dbPostSale.dbo.ExcludedCompanyIDs (NOLOCK)")$CompanyID
  newdata[auction() | asking() | !(company_id %in% excluded_company_ids) | is.na(company_id)]

}

#' @describeIn filter_company_id Non-recipe version.
#' @export
.filter_company_id <- function(data) {
  data <- data[auction() |
                 asking() |
                 !(company_id %in% shdata$excluded_company_ids$CompanyID)]
  update_used_filters()
  data
}

#' Removes listings with invalid currency by country
#'
#' Removes listings with invalid currency by country. This
#' does not affect asking data, and only affects US, Canada, and UK listings.
#' Other countries will not be filtered out. Removes `NA`-valued listings.
#' See details.
#' @inheritParams step_basic
#' @include recipes.R
#' @include steps.R
#' @family filter steps
#' @details
#' The rationale behidn this is dealers make (a lot of) mistakes. They could easily select
#' the wrong currency when entering sale prices, so we exclude any sales which
#' are not in a well-represented currency. "Well-represented" is in the context of
#' the totality of listings which have sold in the country.
#'
#' * USA allows USD.
#' * Canada allows USD and CAD.
#' * UK allows USD, GBP, and EUR.
#' * Other countries allow any currency.
#' @export
filter_sale_currency <- function(recipe, trained = FALSE) {
  add_step(recipe,
           filterat(subclass = "sale_currency",
                    trained = trained))
}

bake.filter_sale_currency <- function(object, newdata, ...) {
  update_used_filters()
  general <- newdata[asking() | (country == "usa" & sale_currency == "usd") |
                       (country == "canada" & (sale_currency %in% c("cad", "usd"))) |
                       (country == "united kingdom" & (sale_currency %in% c("usd", "gbp", "eur"))) |
                       !(country %in% c("canada", "usa", "united_kingdom")),
                     which = TRUE]
  if (!is.null(object$include)) {

    specific <- newdata[asking() | eval(object$include), which = TRUE]
    general <- which(specific | general)
  }
  newdata[general]
}

#' @describeIn filter_sale_currency Non-recipe version.
#' @export
.filter_sale_currency <- function(data) {
  data <- data[asking() |
                 (country == "usa" & sale_currency == "usd") |
                 (country == "canada" & sale_currency %in% c("cad", "usd")) |
                 (country == "united kingdom") & (sale_currency %in% c("usd", "gbp", "eur")) |
                 !(country %in% c("usa", "canada", "united kingdom"))]
  update_used_filters()
  data
}



#' Removes aftersale listings which have a bad review status
#'
#' Removes aftersale listings which have a bad review status and are not approved.
#' You may use [expand_review_status_id()] to see
#' what this column actually represents, or see `dbPostSale.dbo.ReviewStatus`.
#' Removes `NA`-valued listings, although this should never apply. See details.
#'
#' @inheritParams step_basic
#' @include recipes.R
#' @include steps.R
#' @family filter steps
#' @family aftersale filters
#' @export
#'
#' @details
#' If "Good" is marked, it will not be filtered out. If any of the "Bad" filters
#' are marked and "Good" isn't, it will be filtered out. If none of the bad
#' are marked, and a blank is, it will not be filtered out. See examples for
#' how to check a bit.
#' \tabular{llr}{
#' \tab  Review Status ID             \tab      \cr
#' 1    \tab PassedEvaluation             \tab     \cr
#' 2    \tab FailedEvaluation             \tab Bad \cr
#' 4    \tab PassedReview (historical)    \tab     \cr
#' 8    \tab MarkedForReview (historical) \tab Bad \cr
#' 16   \tab Approved                     \tab Good \cr
#' 32   \tab PassedSecondaryEvaluation    \tab Bad \cr
#' 64   \tab OutsideAveragePriceRange     \tab Bad \cr
#' 128  \tab OutsideListPriceRange        \tab Bad \cr
#' 256  \tab SalePriceEqualsListPrice     \tab Bad \cr
#' 512  \tab Duplicate                    \tab Bad \cr
#' 1024 \tab InsufficientData             \tab     \cr
#' 2048 \tab MultipleQuantity             \tab Bad
#' }
#' @examples \dontrun{
#' bits <- c(1, 5, 80, 1553)
#' # Result of 0 means it does not have the corresponding review status.
#' # Result of `x`, where `x` is the review status ID, means it does have that status.
#' bitwAnd(bits, 16)
#' bitwAnd(bits, 1024)
#' bitwAnd(1)
#' }
filter_review_status_id <- function(recipe, trained = FALSE) {
  add_step(recipe, filterat(subclass = "review_status_id",
                            trained = trained))
}


bake.filter_review_status_id <- function(object, newdata, ...) {
  newdata <- newdata[auction() |
                       asking() |
                       bitwAnd(review_status_id, 16) == 16 |
                       ((bitwAnd(review_status_id, 1) == 1 |
                           bitwAnd(review_status_id, 4) == 4 |
                           bitwAnd(review_status_id, 32) == 32 |
                           bitwAnd(review_status_id, 1024) == 1024) &
                          bitwAnd(review_status_id, 2) == 0 &
                          bitwAnd(review_status_id, 8) == 0 &
                          bitwAnd(review_status_id, 64) == 0 &
                          bitwAnd(review_status_id, 128) == 0 &
                          bitwAnd(review_status_id, 256) == 0 &
                          bitwAnd(review_status_id, 512) == 0 &
                          bitwAnd(review_status_id, 2048) == 0)
                     ]
  update_used_filters()
  newdata
}

#' @describeIn filter_review_status_id Non-recipe version.
#' @export
.filter_review_status_id <- function(data) {
  data <- data[auction() |
                 asking() |
                 bitwAnd(review_status_id, 16) == 16 |
                 ((bitwAnd(review_status_id, 1) == 1 |
                     bitwAnd(review_status_id, 4) == 4 |
                     bitwAnd(review_status_id, 32) == 32 |
                     bitwAnd(review_status_id, 1024) == 1024) &
                    bitwAnd(review_status_id, 2) == 0 &
                    bitwAnd(review_status_id, 8) == 0 &
                    bitwAnd(review_status_id, 64) == 0 &
                    bitwAnd(review_status_id, 128) == 0 &
                    bitwAnd(review_status_id, 256) == 0 &
                    bitwAnd(review_status_id, 512) == 0 &
                    bitwAnd(review_status_id, 2048) == 0)]
  update_used_filters()
  data
}

#' Removes machines based on manufacturer year
#'
#' Removes machines which were manufactured before 1950 by default.
#' Removes machines that would receive a negative age.
#' Does not remove `NA`-valued listings. Age is calculated using [step_add_age()]
#' @inheritParams step_basic
#' @param min_year The lowest manufacturer year acceptable.
#' @include recipes.R
#' @include steps.R
#' @family filter steps
#' @export
filter_year <- function(recipe, min_year = 1950, trained = FALSE) {
  add_step(recipe,
           filterat(subclass = "year",
                    min_year = min_year,
                    trained = trained))
}

bake.filter_year <- function(object, newdata, ...) {
  temp <- .add_age(newdata)
  .index <- temp[age > 0 | is.na(age), which = TRUE]
  newdata <- newdata[.index]
  newdata[is.na(year) | year >= object$min_year]
}

#' @describeIn filter_year Non-recipe version.
#' @export
.filter_year <- function(data, min = 1950) {
  temp <- .add_age(data)
  .index <- temp[age > 0 | is.na(age), which = TRUE]
  data[(is.na(year) | year > min) & .index]
}


#' Removes 'not sold' aftersale listings
#'
#' Removes aftersale listings with a 'not sold' status. These are typically
#' listings which were not real sales. Other than sale information (prices),
#' the data should be usable for spec information.
#' @inheritParams step_basic
#' @include recipes.R
#' @include steps.R
#' @family filter steps
#' @export
filter_sale_status <- function(recipe, trained = FALSE) {
  add_step(recipe, filterat(subclass = "sale_status",
                            trained = trained))
}

bake.filter_sale_status <- function(object, newdata, ...) {
  update_used_filters()
  newdata[asking() | auction() | sale_status == "sold"]
}


#' @describeIn filter_sale_status Non-recipe version.
#' @export
.filter_sale_status <- function(data) {
  data <- data[asking() | auction() | sale_status == "sold"]
  update_used_filters()
  data
}

#' Removes non-retail aftersale listings
#'
#' Removes aftersale listings whose sale type is not "retail". See
#' the full list of possible sale types at `dbPostSale.dbo.StringMap`.
#' Aftersale listings whose sale type is not retail typically correspond
#' to AuctionTime or Bidcaller listings, which will also be accounted for
#' in the auction views.
#' @inheritParams step_basic
#' @include recipes.R
#' @include steps.R
#' @family filter steps
#' @family aftersale filters
#' @export
filter_sale_type <- function(recipe, trained = FALSE) {
  add_step(recipe, filterat(subclass = "sale_type",
                            trained = trained))
}

bake.filter_sale_type <- function(object, newdata, ...) {
  update_used_filters()
  newdata[asking() | auction() | sale_type == "retail" | data_type == "simulated"]
}

#' @describeIn filter_sale_type Non-recipe version.
#' @export
.filter_sale_type <- function(data) {
  data <- data[asking() | auction() | sale_type == "retail"]
  update_used_filters()
  data
}



#' Removes excluded aftersale listings
#'
#' Removes aftersale listings which have a PostSaleID present in the
#' PostSaleExclusion table, `dbDataScientist.dbo.PostSaleExclusion`.
#' These could have been put here because they are in the wrong category,
#' wrong spec values, bad prices, and possibly other reasons. Without
#' exception, they should be excluded before doing any data analysis.
#' @inheritParams step_basic
#' @include recipes.R
#' @include steps.R
#' @family filter steps
#' @family aftersale filters
#' @export
filter_aftersale_exclusions <- function(recipe, trained = FALSE) {
  add_step(recipe, filterat(subclass = "aftersale_exclusions",
                            trained = trained))
}

#' @importFrom RODBC sqlQuery
bake.filter_aftersale_exclusions <- function(object, newdata, ...) {
  update_used_filters()
  con <- create_server_connection()
  on.exit(odbcClose(con))
  exclusions <- sqlQuery(con, "SELECT PostSaleID as ref_id from dbDataScientist.dbo.PostSaleExclusion;")
  newdata[asking() | auction() | is.na(ref_id) | !(ref_id %in% exclusions$ref_id)]
}

#' Removes excluded **auction AND asking** listings
#'
#' Removes listings which have an ObjectHistoryID present in the
#' ListingExclusion table, `dbDataScientist.dbo.ListingExclusion`.
#' Removes `ref_id` `NA`-valued listings.
#' @inheritParams step_basic
#' @include recipes.R
#' @include steps.R
#' @family filter steps
#' @family auction filters
#' @family asking filters
#' @export
filter_auction_exclusions <- function(recipe, trained = FALSE) {
  add_step(recipe,
           filterat(subclass = "auction_exclusions",
                    trained = trained))
}

#' @importFrom RODBC sqlQuery
bake.filter_auction_exclusions <- function(object, newdata, ...) {
  update_used_filters()
  con <- create_server_connection()
  on.exit(odbcClose(con))
  exclusions <- sqlQuery(con, "SELECT BaseCategoryID, ListingID from dbDataScientist.dbo.ListingExclusion;")
  bcat_id <- get_base_category_id(data = newdata)
  newdata <- newdata[aftersale() |
                       !(ref_id %in% exclusions[exclusions$BaseCategoryID == bcat_id, "ListingID"])]
  newdata
}

#' @describeIn filter_auction_exclusions Non-recipe version.
#' @export
.filter_auction_exclusions <- function(data) {
  exclusions <- shdata$auction_exclusion_table
  bcat_id <- get_base_category_id(data = data)

  data <- data[aftersale() |
                 !(ref_id %in% exclusions[exclusions$BaseCategoryID == bcat_id, "ListingID"])]
  update_used_filters()
  data
}

#' Removes asking listings which exceed the given date
#'
#' Removes asking listings which have a web end date which
#' exceed the given date, or today's date if not given. This is a good
#' way to filter out current asking from historical asking.
#' @inheritParams step_basic
#' @param date A date in ISO 8601 format -- `yyyy-mm-dd`.
#' @family filter steps
#' @family asking filters
#' @export
filter_web_end_date <- function(recipe, date = NULL, trained = FALSE) {
  add_step(recipe,
           filterat(subclass = "web_end_date", date = date, trained = trained))

}

bake.filter_web_end_date <- function(object, newdata, ...) {
  if (is.null(object$date)) {
    object$date <- Sys.Date()
  }
  newdata[is.na(web_end_date) | web_end_date > object$date]
}

#' @describeIn filter_web_end_date Non-recipe version.
#' @export
.filter_web_end_date <- function(data, date) {
  .date <- date
  data[is.na(web_end_date) | web_end_date > .date]
}

#' Removes spurious asking listings
#'
#' Historically, the asking views also contained auction data. This
#' removes "asking" listings which are not for sale, rent, or lease.
#' Use `filter(data, event_type_id == 1)` to get only for sale listings.
#' @inheritParams step_basic
#' @family filter steps
#' @family asking filters
#' @export
filter_event_type_id <- function(recipe, trained = FALSE) {
  add_step(recipe,
           filterat(subclass = "event_type_id", trained = trained))
}

bake.filter_event_type_id <- function(object, newdata, ...) {
  update_used_filters()
  newdata[!asking() | event_type_id %in% c(1, 2, 20)]
}

#' @describeIn filter_web_end_date Non-recipe version.
#' @export
.filter_event_type_id <- function(data) {
  data[!asking() | event_type_id %in% c(1, 2, 20)]
}


#' Remove all "bad" listings flagged by supplemental specs
#'
#' Removes all "bad" listings flagged by one of these four supplemental specs:
#' `sup_does_not_run`, `sup_engine_rebuilt`, `sup_transmission_rebuilt`,
#' `sup_hours_meter_inaccurate`. See details.
#' @inheritParams step_basic
#' @param col Vector of additional column names which are formatted to flag bad
#' listings the same as supplemental specs, where "bad" listings are assigned a
#' value of 1, and all other listings are either 0 or NA.
#'
#' @details
#' This filter does not remove NA values for these supplemental specs.
#' As long as at least one of these specs is in the data, this filter
#' can be applied. If none of the specs listed above are found, this
#' filter will error and should be removed from the script.
#'
#' This can replace the following four lines of code, found in most category scripts:
#'
#' ```
#' filter(sup_does_not_run == 0 | is.na(sup_does_not_run)) %>%
#' filter(sup_engine_rebuilt == 0 | is.na(sup_engine_rebuilt)) %>%
#' filter(sup_hours_meter_inaccurate == 0 | is.na(sup_hours_meter_inaccurate)) %>%
#' filter(sup_transmission_rebuilt == 0 | is.na(sup_transmission_rebuilt)) %>%
#' ```
#' @export
filter_sup_conditions <- function(recipe, col = NULL, trained = FALSE) {
  flags <- c("sup_does_not_run", "sup_engine_rebuilt", "sup_transmission_rebuilt", "sup_hours_meter_inaccurate", col)
  add_step(recipe, filterat(subclass = "sup_conditions",
                            col = c(flags, col),
                            trained = trained))
}

bake.filter_sup_conditions <- function(object, newdata, ...) {
  specs <- intersect(object$col, names(newdata))
  good <- seq_len(nrow(newdata))
  for (i in seq_along(specs)) {
    good <- intersect(good, which(is.na(newdata[[specs[i]]]) | newdata[[specs[i]]] == 0))
  }
  update_used_filters()
  newdata[good]
}


# Helper functions --------------------------------------------------------

#' Filters data on baking
#'
#' `filter.recipe` adds a step to the recipe which
#' will apply the filter you provide to the data. See details and examples.
#' @inheritParams step_basic
#' @param expr An expression, e.g. `country == "usa"` to subset the data by.
#' Note that missing values are excluded by default.
#' @param ... Not used.
#' @details
#' * Step: Capture expression for evaluation
#' * Prep: Nothing.
#' * Bake: Evaluate the expression in the context of `newdata` to subset. Note that
#'  - This should only be used in training, not export.
#'  - Will "reach" outside `newdata` to find variable names -- don't create
#'   names in the global environment that reside in `newdata`.
#' @export
#' @examples \dontrun{
#' test <- data.table(make_model = rep(c("a", "b", "c"), 30),
#'                    x = runif(90, 0, 10),
#'                    y = rnorm(90, 0, 5))
#' recipe(test) %>% filter(x > 5) %>% prep() %>% bake()
#' test2 <- data.table(make_model = rep(c("a", "b", "c"), 30),
#'                    y = rnorm(90, 0, 5))
#' x <- 2
#' recipe(test2) %>% filter(x == 2) %>% prep() %>% bake()
#' x <- 7
#' recipe(test2) %>% filter(x == 2) %>% prep() %>% bake()
#' recipe(test2) %>% filter(x > y) %>% prep() %>% bake()
#' }


filter.recipe <- function(recipe, expr, ...) {
  add_step(recipe,
           filterat(subclass = "custom",
                    expr = substitute(expr),
                    trained = FALSE))
}

#' @importFrom dplyr filter
bake.filter_custom <- function(object, newdata, ...) {
  newdata[eval(object$expr, envir = parent.frame())]
}


prep.filter <- function(x, training, ...) {
  x$trained <- TRUE
  x
}


#' Prints status of available filters
#'
#' Prints status of available filters. Returns used
#' filters invisibly.
#'
#'
#' @export
#' @family filter functions
#'
check_filters <- function() {
  shdata$check_filters_counter <- shdata$check_filters_counter + 1
  # cat("Available Filters: \n", paste0(shdata$available_filters, collapse = " \n"))
  cat("Check #", shdata$check_filters_counter, "\n", sep = "")
  if (length(shdata$used_filters) == 0) {
    cat("No filters have been applied. \n")
    cat("Unused filters: \n  ", paste0(setdiff(shdata$available_filters, shdata$used_filters), collapse = " \n  "), sep = "")

  } else if (length(shdata$used_filters) < length(shdata$available_filters)) {
    cat("Used filters: \n", paste0(shdata$used_filters, collapse = " \n  "), "\n", sep = "")
  } else {
    cat("All filters have been applied.")
  }
  invisible(shdata$used_filters)
}

#' @keywords internal
update_used_filters <- function() {
  filter <- deparse(sys.calls()[[sys.nframe() - 1]])
  filter <- gsub("\\(|\\)|bake\\.", "", filter)
  shdata$used_filters <- unique(c(shdata$used_filters, filter))
  NULL
}


#' Drop variables used for filtering
#'
#' Drops variables used for filtering based on data_type.
#' These can be accessed with [shtrain:::shdata$filter_selections()]
#' @param data `data.table`
#' @return Data with filter vars removed.
#' @export
drop_filter_vars <- function(data) {
  filter_vars <- unique(unlist(shdata$filter_selection_table[unique(data$data_type)], use.names = FALSE))
  data[,setdiff(names(data), filter_vars), with = FALSE]
}


#' Expand review status IDs into logical values
#'
#' Expand `review_status_id` into individual columns which
#' are appended to the data.
#' @param data `data.table`
#' @export
expand_review_status_id <- function(data) {
  bits <- 2^(0:11)
  review_status <- data.table(review_status_id = bits,
                              status = c("passed_evaluation",
                                         "failed_evaluation",
                                         "passed_review",
                                         "marked_for_review",
                                         "approved",
                                         "passed_secondary_review",
                                         "outside_average_price_range",
                                         "outside_list_price_range",
                                         "sale_price_equals_list",
                                         "duplicate",
                                         "insufficient_data",
                                         "multiple_quantity"))
  has_bits <-  which(!is.na(data$review_status_id))
  for (k in 1:length(bits)) {
    set(data,
        i = has_bits,
        j = as.character(review_status[k, "status"]),
        value = as.logical(bitwAnd(data[has_bits, review_status_id],bits[k])))
  }
  data
}


