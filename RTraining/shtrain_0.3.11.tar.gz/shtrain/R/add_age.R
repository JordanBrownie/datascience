#' Adds age based off of sale month and year
#'
#' Adds machine age , `sale_month - year + offset` as column "age" based on the industry.
#' Depending on the industry, a machine of year `X` may be released in `X-1`, for example.
#
#' @inheritParams step_basic
#'
#' @param ref_offset Generated when function is called. The amount added to age.
#' @inherit step_basic return
#' @details
#'
#' *  Step: Check the industry set using [get_industry()] and store offset
#'    in `step$ref_offset`. Defaults to `0` if industry is not found, with a
#'    warning if using interactively.
#' * Prep: Sets `year` as a dependency of `age`.
#' * Bake: Add `age` column.
#' @export
add_age <- function(recipe, trained = FALSE, ref_offset = NULL) {
  add_step(recipe,
           add_age_new(
             ref_offset = ref_offset,
             trained = FALSE
           ))
}

add_age_new <- function(trained = FALSE, ref_offset = NULL) {
  add(subclass = "age",
       ref_offset = ref_offset,
       trained = trained)
}



prep.add_age <- function(x, training, ...) {
  cache_dependency("age" = "year")
  offset <- list(mat = 0, trk = 0.5, trl = 13/12, tho = 0.5, cnt = 0)
  ind <- get_industry(data = training)
  if (!ind %in% names(offset)) {
    offset <- 0
    if (interactive()) {
      warning("Industry not found, defaulting to an offset of 0 for age.", call. = FALSE)
    }
  } else {
    offset <- offset[[ind]]
  }
  stopifnot(is.numeric(offset) && length(offset) == 1)
add_age_new(ref_offset = offset,
             trained = TRUE)
}

bake.add_age <- function(object, newdata, ...) {
  set(x = newdata,
      i = NULL,
      j = "age",
      value = newdata[["sale_month"]] - newdata[["year"]] + object$ref_offset)
  newdata
}


#' @export
#' @describeIn add_age Non-recipe version of function.
.add_age <- function(data) {
  data <- copy(data)
  offset <- list(mat = 0, trk = 0.5, trl = 13/12, tho = 0.5, cnt = 0)
  ind <- get_industry(data = data)
  if (!ind %in% names(offset)) {
    offset <- 0
    if (interactive()) {
      warning("Industry not found, defaulting to an offset of 0 for age.", call. = FALSE)
    }
  } else {
    offset <- offset[[ind]]
  }
 has_age <- which(!is.na(data[["year"]] & !is.na(data[["sale_month"]])))
  set(x = data,
      i = has_age,
      j = "age",
      value = data[["sale_month"]][has_age] - data[["year"]][has_age] + offset)
  data
}
