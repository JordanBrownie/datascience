#' Set missing factor levels in \code{data} to NA.
#'
#' @param data Data to be predicted.
#' @param object Model object.
#'
#' @return Modified dataframe.
#' @family Modelling functions
#' @export
#'
#' @importFrom glue glue

missing_levels_to_na <- function(data, object) {
  data <- as.data.frame(droplevels(data))
  factors <-
    (gsub("[-^0-9]|as.factor|\\(|\\)", "", names(unlist(object$xlevels))))
  if (length(factors) == 0) {
    return(data)
  } #else nothing
  factorLevels <- unlist(object$xlevels, use.names = FALSE)
  model_factors <- data.table(factors, factorLevels)

  predictors <- names(data[names(data) %in% factors])
  for (i in 1:length(predictors)) {
    if (length(predictors > 1)) {
      found <-
        data[, predictors[i]] %in% model_factors[model_factors$factors ==
                                                    predictors[i],]$factorLevels
      if (any(!found)) {
        data[!found, predictors[i]] <- NA
        data <- droplevels(data)
      } #else nothing
    }
  }
  return(as.data.table(data))

}

#' A faster version of missing_levels_to_na
#'
#' Given data and an object with `xlevels`,
#' NA rows with levels not found in `xlevels`.
#' @param data Data.
#' @param object `glm` object.
#' @export
batch_to_na <- function(data, object) {
  data <- copy(data)
 factors <- names(object$xlevels)
 levels <- object$xlevels
 predictors <- names(data)[names(data) %in% factors]
 for (k in seq_along(predictors)) {
    set(data,
        i = which(is.na(match(data[[predictors[k]]], levels[[predictors[k]]]))),
        j = predictors[k],
        value = NA_character_)
 }
 data
}