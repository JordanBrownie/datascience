
#' Sets auction floor and ceiling price for script.
#'
#' Sets floor and ceiling price for script. Referenced within multiple functions.
#' @return Returns set value invisibly.
#' @family global settings
#' @export
#' @include internal-get.R
set_auction_bounds <- function(floor, ceiling) {
  stopifnot(floor < ceiling,
            floor > 0)
  shref$auction$floor <- floor
  shref$auction$ceiling <- ceiling
  invisible(list(shref$auction$floor, shref$auction$ceiling))
}
#
#' @export
auction_floor <- function() {
  get("auction", envir = shref)$floor
}
#' @export
auction_ceiling <- function() {
  get("auction", envir = shref)$ceiling
}
#' Sets retail floor and ceiling price for script.
#'
#' Sets floor and ceiling price for script. Referenced within multiple functions.
#' @param floor Floor.
#' @param ceiling Ceiling.
#' @family global settings
#' @inherit set_auction_bounds return
#' @export
set_retail_bounds <- function(floor, ceiling) {
  stopifnot(floor < ceiling,
            floor > 0)
  shref$retail$floor <- floor
  shref$retail$ceiling <- ceiling
  invisible(list(shref$retail$floor, shref$retail$ceiling))
}

#' @export
retail_floor <- function() {
  get("retail", envir = shref)$floor
}

#' @export
retail_ceiling <- function() {
  get("retail", envir = shref)$ceiling
}
#' @export
floor_price <- function(evaluation_type) {
  if (tolower(unique(evaluation_type)) == "auction") {
    return(auction_floor())
  } else if (tolower(unique(evaluation_type)) == "retail") {
    return(retail_floor())
  } else {
    stop("Please enter 'auction' or 'retail'.")
  }
}
#' Check industry
#'
#' __Deprecated__ Do not use this function. all calls to `industry()` within
#' the package will now derive it from the category IDs present in the data.
#' This function will be removed in future versions.
#' @export
industry <- function() {
  shref$industry
}

#' Sets industry for the script
#'
#' __Deprecated__ Do not use this function. all calls to `industry()` within
#' the package will now derive it from the category IDs present in the data.
#' This function will be removed in future versions.
#' Set in [set_category_id()].
#' @param category_id Vector of category IDs from the same industry.
#' @param manual 'mat', 'trk', 'trl', 'tho'.
#' @inherit set_auction_bounds return
#' @export
set_industry <- function(category_id, manual = NULL) {
  if (!missing(category_id)) {
   shref$industry <- get_industry(category_id = category_id)
  } else if (!is.null(manual)) {
  if (!(manual) %in% unique(shdata$category_reference$industry, nmax = 10)) {
    stop("Enter 'mat', 'trk', 'trl', or 'tho'.")
  }
  shref$industry <- manual
  } else {stop("Enter a category ID or industry abbreviation.")}

  invisible(shref$industry)
}

#' Check base category ID
#'
#'  __Deprecated__ Do not use this function. all calls to `base_category_id()` within
#' the package will now derive it from the category IDs present in the data.
#' This function will be removed in future versions
#' @export
base_category_id <- function() {
  shref$base_category_id
}

#' Sets base_category_id for the script
#'
#'
#'  __Deprecated__ Do not use this function. all calls to `base_category_id()` within
#' the package will now derive it from the category IDs present in the data.
#' This function will be removed in future versions
#' @param category_id Vector containing category IDs from the same bc ID.
#' @param manual Optional parameter. Set directly. Scalar value.
#' @inherit set_auction_bounds return
set_base_category_id <- function(category_id, manual = NULL) {
  if (missing(category_id) & !missing(manual)) {
    shref$base_category_id <- manual
  } else {
    shref$base_category_id <- get_base_category_id(category_id = category_id)
  }
  invisible(shref$base_category_id)
}
#' Sets category ID, base ID, and industry
#'
#'
#' __Deprecated__ Do not use this function. all calls to `category_id()` within
#' the package will now derive it from the category IDs present in the data.
#' This function will be removed in future versions.
#' @param category_id A single category ID.
#' @return [category_id()] invisibly.
#' @export
set_category_id <- function(category_id) {
  stopifnot(length(category_id) == 1)
shref$category_id <- category_id
set_base_category_id(category_id)
set_industry(category_id)
if (interactive()) {
message("Category ID:      ", if (!is.null(shref$category_id)) shref$category_id else "Not set.", "\n",
    "Industry:         ", if (!is.null(shref$industry)) shref$industry else "Not set.", "\n",
    "Base Category ID: ", if (!is.null(shref$base_category_id)) shref$base_category_id else "Not set.", "\n")
}
invisible(shref$category_id)
}
#' Checks the set category ID
#'
#'  __Deprecated__ Do not use this function. all calls to `category_id()` within
#' the package will now derive it from the category IDs present in the data.
#' This function will be removed in future versions.
#' @export
category_id <- function() {
  shref$category_id
}
