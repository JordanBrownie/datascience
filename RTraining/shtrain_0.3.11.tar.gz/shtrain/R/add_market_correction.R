#' Adds market correction information to data.
#'
#' `add_market_correction` creates a *specification* of a recipe step that will
#'   compute the market correction, along with related information
#' @inheritParams step_basic
#' @param formula formula as a `formula` or string.
#' @param min_listings Minimum listings to use for unsmoothed correction calculation.
#' @param span Proportion of time periods to use in each calculation.
#' @param degree 1 or 2. Degree of polynomial.
#' @param iter How many times to run [rm_outliers()].
#' @param response Variable to compare predictions against for calculating error.
#' @param unit Time period column.
#' @param ref_market Populated during [prep()].
#' @inherit step_basic return
#' @export
#' @details
#' * Step:  Nothing.
#' * Prep:  Compute market correction frame and store in `ref_market`.
#' * Bake:  Left join to `ref_market`.
add_market_correction <- function(recipe, formula, min_listings, span, degree, unit, iter, response = "usd_sale_price", ref_market = NULL, trained = FALSE) {
  add_step(recipe,
           add_market_correction_new(
             formula = formula,
             min_listings = min_listings,
             span = span,
             degree = degree,
             unit = unit,
             iter = iter,
             response = response,
             ref_market = ref_market,
             trained = trained
           ))
}

add_market_correction_new <- function(formula, min_listings, span, degree, unit, iter, response = "usd_sale_price", ref_market = NULL, trained = FALSE) {
  add(subclass = "market_correction",
      formula = formula,
      min_listings = min_listings,
      span = span,
      degree = degree,
      unit = unit,
      iter = iter,
      response = response,
      ref_market = ref_market,
      trained = trained)
}

prep.add_market_correction <- function(x, training, ...) {
 results <-  market_correction(training[data_type != "simulated"], model = x$formula, min_listings = x$min_listings, span = x$span, degree = x$degree, unit = x$unit, iter = x$iter, response = x$response)
 add_market_correction_new(formula = x$formula,
                            min_listings = x$min_listings,
                            span = x$span,
                            degree = x$degree,
                            unit = x$unit,
                            iter = x$iter,
                           response = x$response,
                            ref_market = results,
                           trained = TRUE)
}
#' @importFrom data.table set
bake.add_market_correction <- function(object, newdata, ...) {
 newdata <- merge(newdata, object$ref_market, by = object$unit, all.x = TRUE)
 set(x = newdata,
     i = which(newdata[["data_type"]] == "simulated"),
     j = "correction",
     value = 1)
 newdata
}

summary.add_market_correction <- function(x, ...) {
  if (is_trained(x)) {
    x$ref_market
  }
  else {
    data.table(arg = names(formals(x)[-c(1, 7, 8)]),
               value = unlist(formals(x)[-c(1, 7, 8)], use.names = FALSE))
  }
}


#' Computes a loess curve market correction
#'
#' @param data Data.
#' @param model \code{glm} object or a formula string.
#' @param min_listings Minimum number of listings to base each point on.
#' @param span Proportion of data points to include in the local regression fit.
#' @param degree The degree of the polynomial to be fit, either 1 or 2.
#' @param unit 'sale_month' or 'sale_week'.
#' @param iter Iterations used in \code{\link{rm_outliers}}.
#' @param response Reponse variable, as in `formula`.
#' @return data containing \code{unit}, \code{correction}, and additional columns
#'   containing information about sales in calculation. If you wish to only retrieve the
#'   \code{unit} and \code{correction}, put \code{[, 1:2]} behind the call.
#' @export
#'
#' @importFrom stats loess glm
#' @include internal-get.R
market_correction <- function(data, model, min_listings, span, degree, unit, iter, response = "usd_sale_price") {
  formula <- get_formula(model)
  floor_price <- retail_floor()
  ceiling_price <- retail_ceiling()
  market_data <- rm_outliers(data, model = formula, iter = iter)
  market_fit <- glm(formula = formula, data = market_data, family = "gaussian")
  market_data[["pred"]] <- predict_safely(market_fit, market_data)
  market_data[market_data[["pred"]] < floor_price, pred := floor_price]
  market_data[market_data[["pred"]] > ceiling_price, pred := ceiling_price]
  index <- market_data[[unit]]
  unit_values <- sort(unique(index), na.last = TRUE)
  not_missing <- !is.na(market_data[["pred"]])
  errors <- matrix(NA, ncol = 6, nrow = length(unit_values))
  colnames(errors) <- c(unit, "correction", "unsmoothed_correction", "sales_in_calculation",
                        "units_in_calculation", "sales_in_unit")
  errors[, unit] <- unit_values
  for (i in seq_along(unit_values)) {
    j = 1
    temp_unit <- current_unit <-  unit_values[i]
    while (sum(market_data[[unit]] %in% temp_unit & not_missing) < min_listings |
           is.na(sum(market_data[[unit]] %in% temp_unit & not_missing))) {
      temp_unit = c(temp_unit, unit_values[max(1,i - j)], unit_values[min(length(unit_values),i + j)])
      j = j + 1
      if (j == length(unit_values)) {
        break
      }

    }

    errors[errors[, unit] == current_unit, "unsmoothed_correction"] <- 1 - sum(market_data[index %in% temp_unit & not_missing, "pred"]) /
      sum(market_data[index %in% temp_unit & not_missing, response, with = FALSE])
    errors[errors[, unit] == current_unit, "sales_in_calculation"] <- sum(index %in% temp_unit & not_missing)
    errors[errors[, unit] == current_unit, "units_in_calculation"] <- length(unique(temp_unit))
    errors[errors[, unit] == current_unit, "sales_in_unit"] <- sum(not_missing & index %in% errors[errors[, unit] == current_unit, unit])
  }
  # errors[, 3] <- errors[, 3] - mean(errors[, 3], na.rm = TRUE)
  errors <- as.data.frame(errors)

  names(errors) <- c(unit, "correction", "unsmoothed_correction", "sales_in_calculation",
                     "units_in_calculation", "sales_in_unit")
  errors[, "correction"] <- loess(errors[,"unsmoothed_correction"] ~ errors[,unit], span = span, degree = degree)$fitted
  errors[, "correction"] <- 1 - (errors[, "correction"] - mean(errors[, "correction"], na.rm = TRUE))
  return(errors)



}