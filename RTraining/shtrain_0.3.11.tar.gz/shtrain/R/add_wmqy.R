#' Adds date indicator columns
#'
#' `month`, `quarter`, and `year` arguments are defaulted to `TRUE`, while `week` is defaulted to `FALSE`,
#' due to it's granularity. Only add the ones you require.
#' Assumptions: this step is only run after add_date() has been called within a recipe, and at least one
#' metric should be set to 'TRUE'. Errors will be produced if one of these requirements is not satisfied.
#' @inheritParams step_basic
#' @param week Add `week_of_sale`? Defaults to `FALSE`.
#' @param month Add `month_of_sale`? Defaults to `TRUE`.
#' @param quarter Add `quarter_of_sale`? Defaults to `TRUE`.
#' @param year Add `year_of_sale`? Defaults to `TRUE`.
#' @export
add_wmqy <- function(recipe, week = FALSE, month = TRUE, quarter = TRUE, year = TRUE, numeric = FALSE, trained = FALSE) {
  add_step(recipe,
                     add_wmqy_new(
                       week = week,
                       month = month,
                       quarter = quarter,
                       year = year,
                       numeric = numeric,
                       trained = trained
                     ))
}

add_wmqy_new <- function(week = FALSE, month = TRUE, quarter = TRUE, year = TRUE, numeric = FALSE, trained = FALSE) {
  add(subclass = "wmqy",
                week = week,
                month = month,
                quarter = quarter,
                year = year,
                numeric = numeric,
                trained = trained
  )
}

prep.add_wmqy <- function(x, training, ...) {
  # avoided setting a dependency here. If used in the final model, these metrics will need to removed from the json
  if (!inherits(training[["sale_date"]], "IDate")) {
    stop("`add_date()` must be called on the data before `add_wmqy()`", call. = FALSE)
  }
  if (x$week == FALSE & x$month == FALSE & x$quarter == FALSE & x$year == FALSE) {
    stop("Please remove 'add_wmqy()' from recipe", call. = FALSE)
  }
  add_wmqy_new(
    week = x$week,
    month = x$month,
    quarter = x$quarter,
    year = x$year,
    numeric = x$numeric,
    trained = TRUE
  )
}

bake.add_wmqy <- function(object, newdata, ...) {

  as.type <- function(dt, type = object$numeric) {
    if (type == TRUE) {
      dt <- as.numeric(dt)
    }
    else if (type == FALSE) {
      dt <- as.character(dt)
    }
  }

  if (object$week == TRUE) {
    set(
      x = newdata,
      i = NULL,
      j = "week_of_sale",
      value = as.type(data.table::week(newdata[["sale_date"]]))
    )
    newdata[week_of_sale == as.type(53), week_of_sale := as.type(1)]
  }

  if (object$month == TRUE) {
    set(
      x = newdata,
      i = NULL,
      j = "month_of_sale",
      value = as.type(str_sub(newdata$sale_date, 6, 7))
    )
  }

  if (object$quarter == TRUE) {
    set(
      x = newdata,
      i = NULL,
      j = "quarter_of_sale",
      value = as.type(ceiling(as.numeric(
        str_sub(newdata$sale_date, 6, 7)
      ) / 3))
    )
  }

  if (object$year == TRUE) {
    set(
      x = newdata,
      i = NULL,
      j = "year_of_sale",
      value = as.type(str_sub(newdata$sale_date, 1, 4))
    )
  }
  newdata
}