# Miscellaneous functions which support Fleet Evaluator.

#' Choose best evaluation from among a group of evaluations
#'
#' Choose best evaluation from among a group of evaluations
#' by several prediction models.
#' @family sp functions
best_eval <- function(x) {
  best <-  max(1, which.min(x))
  best
}


#' Copies package for scoring
#'
#' Copies a portion of the package for scoring. Excludes filters,
#' sql functions, step constructors, and summary methods. Does not retain
#' any of the internal package data, like the name table, excluded company IDs, etc.
#' This is because the `.OnLoad`` code isn't run.
#' @return A named list to be passed to [sql_recipe()].
#' @export
#' @importFrom pryr make_function
#' @importFrom rlang fn_env
#' @importFrom glue collapse glue
#' @importFrom utils lsf.str
copy_package <- function(functions = NULL) {
  # Find all bake methods in global environment. Warn if they aren't included in the input, as
  # this is a commons ource of problems.
  global_bake_functions <- lsf.str(envir = globalenv(), pattern = c("bake.*"))
  accidently_excluded <- setdiff(global_bake_functions, functions)
  if (length(accidently_excluded) && interactive()) {
    warning("Bake functions ", collapse(accidently_excluded, sep = ", "),
            " in global environment not included in `copy_package()`. ",
            "If used in the export recipe, they must be included.", call. = FALSE)
  }
  # List all functions in the package.
  fs <- ls(envir = asNamespace("shtrain"), all.names = TRUE)[
    unlist(lapply(ls(envir = asNamespace("shtrain"), all.names = TRUE),
                  function(x) mode(get(x,
                                       envir = asNamespace("shtrain"))))) == "function"]
  # Exclude a lot that won't be needed on scoring.
  fs <- setdiff(
    fs, c(
      ls(envir = asNamespace("shtrain"),
         pattern = "^filter_.*|^sql_.*|^step_.*_new$|.*_new$|^summary\\..*|^minimize.*|^check.*|^step.*|^prep\\..*|^add.*|^Logger.*|^\\.filter.*|^\\.format.*|^set_.*", all.names = TRUE),
      c("post_recipe", "rm_prefix", "has_prefix", "rm_outliers", "market_correction", "lc",
        "get_table_name", "sale_period","validate", "sclass", "pivot_evaluations",
        "mergeto", "metrics", "log_file", "format_params", "extract_ref", "expand_review_status_id",
        "expand_selections", "dt_we", "dt_qae", "dt_mae", "dt_fe", "cv_compare", "custom_query",
        "create_server_connection", "cv_model", "double_asking", "drop_filter_vars",
        "benchmark_model", "cache_names", "cache_dependency", "command_arguments",
        "bake.add_link", "bake.add_imputations", "bake.add_market_correction", "bake.add_simulations",
        "attr_data", "bake.check_invalid_data", "web_start_date", "update_used_filters", "summary_steps",
        "supply_stats", "summary", "demand_stats", "recipe", "recipe.default", "recipe.data.frame", "recipe.data.table",
        "resolve_dependencies", "piece_formula", "reconcile_names", "region_table")
    )
  )
  # Create all functions without the reference to the shtrain namespace.
  f_list <- list()
  for (k in seq_along(fs)) {
    f_list[[k]] <- make_function(formals(fs[k]), body(fs[k]), env = asNamespace("shtrain"))
    rlang::fn_env(f_list[[k]]) <- globalenv()
  }
  names(f_list) <- fs
  # If any functions were passed in, verify they don't collide with package functions.
  # If they do, warn and use the version passed in.
  if (!is.null(functions)) {
    global_f <- vector(mode = "list", length = length(functions))
    for (k in seq_along(global_f)) {
      global_f[[k]] <- get(functions[k], mode = "function", envir = globalenv())
    }
    names(global_f) <- functions

    if (any(names(global_f) %in% names(f_list)) && interactive()) {
      name <- names(global_f)[names(global_f) %in% names(f_list)]
      warning(glue("The functions `{collapse(name, sep = ', ', last = ', and')} are all present ",
                   "in the package namespace and global environment. ",
                   "The version in the global environment will be given preference. ",
                   "If you do not wish this, rename your function."))
    }
    final <- c(global_f[!names(global_f) %in% names(f_list)], f_list)
  } else {
    final <- f_list
  }
  final
  # final[names(final) != ".__A__.1"]
}


#' Generate attribute data for SQL export
#'
#' `attr_data()` Builds a table which is used by FleetEvaluator code to determine:
#'
#' 1. Specs to pass into R upon evaluation
#' 2. Specs to display on FleetEvaluator
#'
#' The fields selected are based on `gather_info()$used_vars`, along with several defaults.
#' This data will tell code which variables need to be passed in for FE valuations.
#' It will pass the requested specs, plus some metadata (Year, Manufacturer, Model, ModelGroup), plus all default/supplemental/vin
#' versions of the requested specs. Fun fact: Everything is passed in as a character
#' regardless of the type here. A good rule of thumb is if a variable originates
#' in SQL and is used at any point in your export recipe, you should request it here.
#'
#' @param data Data used to train the export recipe.
#' @param info [gather_info()] result.
#' @return Table containing SQL type information for columns needed. See details for construction
#' @export
#' @details
#' The fields selected are based on `gather_info()$used_vars`, along with several
#' defaults such as "Year", "Manufacturer", "Model", and "ModelGroup". These variables
#' listed here will also have their default/supplemental/vin versions passed into R upon
#' evaluation. There is a basic heuristic in place to prevent asking for variables which don't exist.
#' If a variable in `info$used_vars` is determined not to be directly from SQL, it will be
#' removed from the result, and you will have to add it back manually.
#'
#' @include internal-utils.R
attr_data <- function(data, info) {
  # chr_or_fctr <- vapply(data, FUN.VALUE = TRUE, USE.NAMES = FALSE, FUN = function(x) is.character(x) | is.factor(x))
  temp_data <- copy(data[,intersect(info$used_vars, names(data)), with = FALSE])
  sql_names <- change_names(names = names(temp_data), from = "r")
  numeric <- which(vapply(temp_data, FUN.VALUE = TRUE, USE.NAMES = FALSE, FUN = is.numeric))
  boolean <- which(vapply(temp_data, FUN.VALUE = TRUE, USE.NAMES = FALSE, FUN = is.logical))
  all_else <- which(vapply(temp_data, FUN.VALUE = TRUE, USE.NAMES = FALSE, FUN = function(x) !is.numeric(x) & !is.logical(x)))
  attr_data <- data.frame(AttributeName = sql_names, SQLDataType = NA_character_, stringsAsFactors = FALSE)
  attr_data[all_else, "SQLDataType"] <- "NVARCHAR(50)"
  attr_data[numeric, "SQLDataType"] <- "DECIMAL(18,2)"
  attr_data[boolean, "SQLDataType"] <- "BOOLEAN"
  attr_data <- rbind(attr_data, data.table(AttributeName = c("Condition", "Country", "Model", "ModelGroup", "Manufacturer"), SQLDataType = c("NVARCHAR(50)")))
  if (get_industry(data = data) == "trl") {
    attr_data <- attr_data[!(AttributeName %in% c("Model", "ModelGroup"))]
  }
  result <- unique(attr_data[!(AttributeName %in% c("MakeModel", "make_model"))], by = "AttributeName")
  #TODO SAFETY
  # Use shapi:::live_MMM$CategorySpec_Search(SearchModel(...)) to get the list of possible specs
  # for the category and validate against those instead.
  bad <- sum(!str_detect(result$AttributeName, "[A-Z]"))
  if ( bad > 0) {
    bad_names <- result$AttributeName[!str_detect(result$AttributeName, "[A-Z]")]
    if (interactive()) {
    message(glue("{lc(bad_names)} included in `attr_data()` result. This may happen \\
                 from not defining a dependency. Only valid columns returned, `rbind()` back if \\
                 this is a mistake."))
    }
    result <- result[!AttributeName %in% bad_names]
  }
  result
}

#' Subsets training data to scoring columns
#'
#' Attempts to subset the data to only columns needed for export.
#' Note that the output of this should always be checked. In particular,
#' any default or supplement specs you use to replace dealer-entered specs
#' should be included.
#'
#' @param data The data you wish to use as a template for [format_class()]. In general,
#' this should include the required columns below, any dealer-entered specs you want,
#' and their default/supplemental equivalents.
#' @param col A character vector of column names. Names do not need to be provided
#' for specs which have a corresponding spec with a prefix in `prefix`. See Details for which ones
#' are always included.
#' @param prefix A vector of prefixes that you wish to retain columns for.
#' Any variables in the data starting with these prefixes will be retained,
#' and their "base" variants (with no prefix).
#' @details
#' "ref_id", "ds_lookup_id", "condition", "data_type",
#' "manufacturer", "state", "country", "year", and "sale_date" are always included,
#' they do not need to be explicitly selected.
#'  "model" and "model_group" are also included (and required) for industries other than trailers.
#' If they are not in your data, the function will fail.
#' "hours" and "mileage" are included by default, but only if they are within the data.
#'
#' For each `prefix`, every matching column in `data` is selected. The prefix is then
#' stripped, and the result is looked for in the data. If present, the base variable
#' is also selected. These are combined with the defaults.
#'
#' Finally, any variables provided through `col` are added. All names are checked
#' against the name cache as a basic check for validity.
#'
#' @export
#' @include internal-get.R
#' @include utils.R
export_data <- function(data, col = NULL,  prefix = c("def_", "sup_")) {
  stopifnot(is.null(col) || all(col %in% names(data)))
  required <- c("ref_id", "ds_lookup_id", "condition", "data_type",
                "manufacturer", "state", "country", "year", "sale_date")
  if (get_industry(data = data) != "trl") {
    required <- append(required, c("model", "model_group"), after = 5L)
  }
  if (!all(required %in% names(data)) && interactive()) {
    missing <- setdiff(required, names(data))
    warning(glue("{missing} are required, but not present in the data.", call. = FALSE))
  }
  possible <- intersect(names(data), c("hours", "mileage"))
  additional_cols <- vector(mode = "list", length = length(prefix))
  for (k in seq_along(additional_cols)) {
    additional_cols[[k]] <- shtrain:::find_replacement(names(data), prefix[k])
    additional_cols[[k]] <- c(rm_prefix(additional_cols[[k]], prefix[k]),additional_cols[[k]])
  }
  additional_cols <- unlist(additional_cols, use.names = FALSE)
  keepers <- unique(c(required, possible, col, additional_cols))
  check <- !(keepers %in% c(shref$name_cache$r, "data_type"))
  if (sum(check) > 0 && interactive()) {
    potentially_bad <- keepers[check]
    warning(glue("{lc(potentially_bad)} provided in `export_data()`, but not present \\
                 in `shref$name_cache$r`. All specs provided should exist within MMM, \\
                 or be dealer-tied (State, Country, etc.). If those listed above should be included, \\
                 use `cache_names()` to assign the correct name. Default/Supplementals \\
                 should match the casing of their base counterparts. If there is another column \\
                 which needs to be included but is not dealer-enterable, also use `cache_names()`."), call. = FALSE)
  }
  data[,keepers, with = FALSE]
  }




#' Gathers metadata for use in a recipe
#'
#' Given `data`, `models`, generates a list containing meta
#' data. This information is primarily used for initial determination of what variables
#' need to receive error checking.  See details.
#' @param data The data you are going to use in [recipe()].
#' @param models a single [stats::glm()] object or list of them which you will use for scoring.
#' @param bad_levels Deprecated. Do not use.
#' @export
#' @details
#'  This function brings together a lot of information.  All results use R names.
#'  \itemize{
#'  \item{base_vars:}{ Variables used in the formula which are present in SQL.}
#'  \item{derived_vars:}{Variables derived from those present in SQL.}
#'  \item{source_vars:}{ Variables present in SQL from which derived_vars came from.}
#'  \item{formula_vars:}{ Variables in the formula. \code{union(base_vars, derived_vars)}}
#'  \item{used_vars:}{ SQL variables which impact formula. \code{union(base_vars, source_vars)}}
#'  \item{xlevels:}{ xlevels from first model object provided}
#'  \item{bad_levels:}{ Output from `check_slope_coefficients` transformed into a named list.}
#'  \item{dependencies:}{ A named list of the form list(derived_var = source_var,...)}
#'  }
#'  @importFrom stats as.formula
#'  @importFrom rlang is_bare_list
#'  @importFrom httr content
gather_info <- function(data, models, bad_levels = NULL) {
  if (!is.null(bad_levels) & interactive()) {
    warning("Please remove `bad_levels` argument from `gather_info()` and use",
            "`step_drop_levels` in your export recipe instead.", call. = FALSE)
  }
  info <- vector(mode = "list", length = 8L)
  names(info) <- c("formula_vars", "derived_vars", "source_vars", "base_vars", "xlevels", "bad_levels", "used_vars", "dependencies")
  formulavars <- vector(mode = "list", length = length(models))
  if (is_bare_list(models)) {
    for (i in seq_along(models)) {
      formulavars[[i]] <- all.vars(as.formula(models[[i]]$formula)[[3]])
    }
    formulavars <- unique(unlist(formulavars, use.names = FALSE))
    info[["xlevels"]] <- models[[1]]$xlevels
  } else {
    formulavars <- all.vars(as.formula(models$formula)[[3]])
    info[["xlevels"]] <- models$xlevels
  }
  dependencies <- shdata$dependencies

  info[["dependencies"]] <- dependencies
  info[["derived_vars"]] <- intersect(formulavars, names(dependencies))
  info[["source_vars"]] <- unique(unlist(dependencies[info[["derived_vars"]]], use.names = FALSE))
  info[["base_vars"]] <- setdiff(formulavars, info[["derived_vars"]])
  info[["used_vars"]] <-union(info[["base_vars"]], info[["source_vars"]])
  info[["formula_vars"]] <- formulavars
  info
}

########################## Function used in SQL SP #############################
#' Score a raw dataset using the recipe(s) provided
#'
#' `score_models()` is used in the SP, which is why it covers multiple use cases.
#' See details.
#' @param data A raw dataset, whose variables should typically match what is specified
#' by [attr_data()].
#' @param aftersale_recipe Either the only recipe provided, or the one which provides
#' aftersale evaluations.
#' @param auction_recipe `NULL` if only one recipe is provided, or the one which
#' provides auction evaluations.
#' @param strict If `TRUE`, the columns will be subset to those which match
#' the SP results. If any of the SP columns are missing, they will be added
#' as `NA`.
#' @param melt Has no effect on two-recipe calls. If `TRUE`, it will pivot
#' `evaluation_*` columns to `evaluation` and `evaluation_type`, with the
#' `evaluation_type` matching up with `*`. `* == "aftersale"` will be converted
#' to `"retail"` to provide compatibility with the API.
#' @return
#' If `strict == TRUE`, it will provide the columns specified in the SP.
#' If `FALSE`, it will return the input dataset plus any columns added by the
#' recipes. The results of the two recipes are row-bound together.
#' For one-recipe calls, `melt == FALSE` will return one row per listing with
#' a column for each type of evaluation, rather than the multiple rows per listing
#' to account for all evaluation types.
#' @details
#' For two-recipe calls, remove any date columns, `eval_type`, and `data_type`.
#' Since the SP does not use any of these, the function attempts to insert it's own.
#' One-recipe calls are basically `bake(recipe, newdata = data)`, with some transformations
#' after if either `strict` or `melt` is `TRUE`.
#'
#'
#'
#' @importFrom data.table setDT set rbindlist setcolorder
#' @importFrom stringr str_sub
#' @family sp functions
#' @export
score_models <- function(data, aftersale_recipe = NULL, auction_recipe = NULL, strict = TRUE, melt = TRUE) {
  if (!is.data.table(data)) {
    setDT(data)
  }
  data <- copy(data)
  #### if using two recipes
  if (!("ReferenceTypeID" %in% names(data))) {
    set(x = data,
        i = NULL,
        j = "ReferenceTypeID",
        value = NA_integer_)
  }
  if (!is.null(auction_recipe) && !is.null(aftersale_recipe)) {

    if (!("eval_type" %in% names(data))) {
      data <- rbindlist(list("auction" = data, "retail" = data), idcol = "eval_type")
    }
    if (!("data_type" %in% names(data))) {
      auction <- which(data[["eval_type"]] == "auction")
      aftersale <- which(data[["eval_type"]] == "retail")
      set(x = data,
          i = auction,
          j = "data_type",
          value = "auction")
      set(x = data,
          i = aftersale,
          j = "data_type",
          value = "aftersale")
    }

    auc_results <- bake(auction_recipe, newdata = data[eval_type == "auction"])
    aft_results <- bake(aftersale_recipe, newdata = data[eval_type == "retail"])
    results <- rbindlist(list("auction" = auc_results, "retail" = aft_results), fill = TRUE) # idcol = "evaluation_type", fill = TRUE)
    if (strict == TRUE) {
      #TODO Error
      # If you decide to add new columns, you'll need to add the new one(s) here in the correct position.
      # They'll also need to be added in the SP.
      # Rollout synchronization doesn't really matter -- the "expected_columns" piece below will
      # dynamically handle any new columns added in the SP. Including them here just faithfully
      # replicates the behavior locally.
      vars_needed <- c("ReferenceID","ReferenceTypeID","EvaluationType","PriorityOrder","RequiredFieldsError","InvalidDataError", "InsufficientDataError",
                       "Evaluation","AcceptableEvalLower","AcceptableEvalUpper","ExceedEvalBound","SpecsUsedinModel","MessageFromR")
      vars_present <- intersect(vars_needed, names(results))
      if (exists("expected_columns", envir = globalenv())) {
        vars_needed <- get("expected_columns", envir = globalenv())
      }
      if (length(vars_present) != length(vars_needed) && interactive()) {
        warning("Required Fleet Evaluator columns ", paste0(setdiff(vars_needed, vars_present), collapse = ", "), " are missing. ",
                "These will be added as NA on scoring in the SP.", call. = FALSE)
      }
      set(x = results,
          i = NULL,
          j = setdiff(names(results), vars_needed),
          value = NULL)
    }
    return(results)
  } else {
    if (!"data_type" %in% names(data)) {
      data[,data_type := NA_character_]
    }
    #### If using one recipe.
    results <- bake(aftersale_recipe, newdata = data)
    # We'll want to melt on scoring to put in right form, but it is inconvenient
    # locally.
    if (melt == TRUE) {
      set(x = results,
          i = NULL,
          j = "EvaluationType",
          value = NULL)
      # API expects auction, retail, or asking. Changing the names is the easiest
      # way to get the correct EvaluationType
      setnames(results, old = "evaluation_aftersale", "evaluation_retail")
      if ("Evaluation" %in% names(results)) {
        set(x = results,
            i = NULL,
            j = "evaluation",
            value = NULL)
      }
      results <- melt(results, measure.vars = patterns("^evaluation_.*"),
                      variable.name = "EvaluationType",
                      value.name = "Evaluation")
      set(x = results,
          i = NULL,
          j = "EvaluationType",
          value = str_sub(results[["EvaluationType"]], 12))
      not_evaluated <- which(!is.na(results[["PriorityOrder"]]) & is.na(results[["Evaluation"]]))
      set(x = results,
          i = not_evaluated,
          j = "PriorityOrder",
          value = NA_real_)
      #TODO Error
      # Same as described above.
      if (strict == TRUE) {
        vars_needed <- if (exists("expected_columns", envir = globalenv())) {
          get("expected_columns", envir = globalenv())
        } else {
          c("ReferenceID","ReferenceTypeID","EvaluationType","PriorityOrder","RequiredFieldsError","InvalidDataError", "InsufficientDataError",
            "Evaluation","AcceptableEvalLower","AcceptableEvalUpper","ExceedEvalBound","SpecsUsedinModel","MessageFromR")
        }
        vars_present <- intersect(vars_needed, names(results))
        if (length(vars_present) != length(vars_needed) && interactive()) {
          warning("Required Fleet Evaluator columns ", paste0(setdiff(vars_needed, vars_present), collapse = ", "), " are missing. ",
                  "These will be added as NA on scoring in the SP.", call. = FALSE)
        }
        set(x = results,
            i = NULL,
            j = setdiff(names(results), vars_needed),
            value = NULL)
      }
      return(results)
    }
    if (strict == TRUE && melt == FALSE) {
      warning("`strict == TRUE` has no effect when `melt == FALSE`, since ",
              "this scenario does not occur in scoring. ",
              "Returning unmodified results.", call. = FALSE)
    }

    return(results)
  }
}


# Export support ----------------------------------------------------------



#' Posts output an object for SQL scoring
#'
#' Interface to POST to API. Has built-in checks to POST only if import is
#' requested by the command arguments (not implemented). If local, it will ask what action
#' should be taken.
#'
#' @param object Output of [sql_recipe()].
#' @param forced Logical. If `TRUE`, POSTs automatically instead of
#' asking at the console.
#' @export
#' @importFrom utils menu
#' @importFrom httr POST
#' @importFrom httr content_type_json
post_recipe <- function(object, forced = FALSE) {

  ca <- command_arguments()
  if (!is.null(ca$import_type) && ca$import_type == "import") {
    POST(command_arguments()$api_link, body = object, config = content_type_json())
  } else{
    if (interactive() && !forced) {
      choice <- menu(title = "Do you wish to POST? Set forced to TRUE to skip this prompt and always POST",
                     choices = c("POST", "Do not POST"))
      if (choice == 1) {
        print(POST(ca$api_link, body = object, config = content_type_json()))
        return(NULL)
      } else if (choice == 2) {
        return(NULL)
      }
    }
    warning("Command argument import_type != 'import'. Skipping POST")
    return(NULL)
  }
}


#' Constructs object for POSTing
#'
#' Constructs object for POSTing. Performs multiple checks to
#' validate input.
#'
#' @param category_id Scalar category ID.
#' @param auction Auction recipe.
#' @param aftersale Aftersale recipe.
#' @param exports Output of [copy_package()]
#' @param attributes Output of [attr_data()]
#'
#' @export
#' @importFrom jsonlite toJSON
sql_recipe <- function(category_id, auction, aftersale, exports, attributes) {
  stopifnot("recipe" %in% class(auction),
            "recipe" %in% class(aftersale),
            class(exports) == "list")
  auction_is_prepped <- all(unlist(lapply(auction$steps, function(x) isTRUE(x[["trained"]])), use.names = FALSE))
  aftersale_is_prepped <- all(unlist(lapply(aftersale$steps, function(x) isTRUE(x[["trained"]])), use.names = FALSE))
  if (!auction_is_prepped) {
    stop("Auction recipe is not prepped.")
  }
  if (!aftersale_is_prepped) {
    stop("Aftersale recipe is not prepped.")
  }
  if (nrow(unique(attributes, by = "AttributeName")) != nrow(attributes) & interactive()) {
    warning("Your attribute data has non-unique rows by AttributeName. Dropping",
            "all non-unique entries but the last for each AttributeName.", call. = FALSE)
  }
  toJSON(list(categoryID = category_id, Description = paste("Category", category_id, "Retail and Auction Models"),
              SerializedRModels = list(memCompress(serialize(list("AuctionModel" = minimize(auction),
                                                                  "RetailModel" = minimize(aftersale),
                                                                  "ExportedObjects" = exports), NULL))),
              AttributeList = unique(attributes, by = "AttributeName")),
         .withNames = TRUE,
         auto_unbox = TRUE,
         digits = NA)
}


#' Constructs Fleet Evaluator object for posting
#'
#' Performs multiple validation checks before constructing object.
#' passed to API.  See details.
#' @param category_id A single category ID.
#' @param recipe A single recipe which provides evaluation_auction, evaluation_aftersale,
#' etc.
#' @param exports Output from [copy_package()].
#' @param attributes Output from [attr_data()].
#' @param extras Anything you want, within reason. Perhaps a list of statistics to track information
#' over time. Should not be overly large. Should not be information you plan to use
#' from within the recipe passed.
#'
#' @export
#' @importFrom glue collapse
#' @importFrom jsonlite toJSON
#' @importFrom pryr object_size
#' @importFrom purrr modify_depth
#' @details
#' Performs a validation check on attribute names by checking for upper-case letters.
#' If none are present, a warning is printed. It removes duplicate rows from the
#' attribute data. It minimizes all "glm", "rpart" objects provided as a step argument, or in a list provided as a step argument. It provides size and load time estimates for the serialized  R model.
fleet_evaluator_model <- function(category_id, recipe, exports, attributes, extras = NULL) {
  stopifnot(is.recipe(recipe),
            is.list(exports),
            length(category_id) == 1,
            is.data.frame(attributes))
  prepped <- all(unlist(lapply(recipe$steps, function(x) isTRUE(x[["trained"]])), use.names = FALSE))
  recipe$steps <- modify_depth(.x = recipe$steps, .depth = 2, .f = minimize, .ragged = TRUE)
  # recipe$steps$add_evaluation$models <- modify(.x = recipe$steps$add_evaluation$models,  .f = minimize)
  if (!prepped) {
    stop("Not all steps in the export recipe are prepped.", call. = FALSE)
  }
  if (!is.null(extras) && interactive()) {
    extra_size <- pryr::object_size(extras)
    message("Extras included on export for future diagnostics. ",
            "Estimated size is ", extra_size, " before compression.")
  }
  # Error if an attribute name has no upper-case characters, which likely means
  # a name wasn't cached properly.
  #TODO Safety make same check as in `attr_data()` TODO
  if (sum(!str_detect(attributes[["AttributeName"]], "[A-Z]")) != 0 && interactive()) {
    bad_attrs <- which(!str_detect(attributes[["AttributeName"]], "[A-Z]"))
    warning("There appears to be at least one malformed AttributeName: ",
            collapse(attributes[['AttributeName"']][bad_attrs], sep = ", ",
                     last = " and "), call. = FALSE)
  }
  if (nrow(unique(attributes, by = "AttributeName")) != nrow(attributes) & interactive()) {
    warning("Your attribute data has non-unique rows by AttributeName. Dropping",
            "all non-unique entries but the last for each AttributeName.", call. = FALSE)
  }
  serialized <- list(memCompress(serialize(list(AuctionModel = NULL,
                                                RetailModel = minimize(recipe),
                                                ExportedObjects = exports,
                                                extras = extras), NULL)))
  res <- toJSON(list(categoryID = category_id, Description = paste("Category", category_id, "one model"),
                     SerializedRModels = serialized,
                     AttributeList = unique(attributes, by = "AttributeName")),
                .withNames = TRUE,
                auto_unbox = TRUE,
                digits = NA)

  if (interactive()) {
    test <- system.time(unserialize(memDecompress(serialized[[1]], "gzip")))
    message("The minimized scoring recipe is ", round(object_size(serialized)/1000000, 3),
            " MB after compression. ",
            "This will take an estimated ", round(test[[3]], 2), " seconds",
            " to load on scoring.")
  }
  res
}

#' Constructs Benchmark object for posting
#'
#' Performs multiple validation checks before constructing object
#' passed to API.  See details.
#' @param category_id A single category ID.
#' @param recipes A list of recipes, each of which provides scoring for a
#' specified date.
#' @param comparables A named list of valid values corresponding to the name given.
#'  These will provide comparable values for Benchmark.
#' @inheritParams fleet_evaluator_model
#' @export
#' @importFrom glue collapse
#' @importFrom jsonlite toJSON
#' @importFrom pryr object_size
#' @details
#' Performs a validation check on attribute names by checking for upper-case letters.
#' If none are present, a warning is printed. It removes duplicate rows from the
#' attribute data. It provides size and load time estimates for the first serialized
#' R model.
benchmark_model <- function(category_id, recipes, exports, attributes, extras = NULL) {
  stopifnot(length(category_id) == 1,
            is.list(exports),
            is.data.frame(attributes))
  prepped <- all(unlist(lapply(recipes, function(x)
    all(unlist(lapply(x$steps, function(y) isTRUE(y[["trained"]])))))))
  if (!prepped) {
    stop("Not all recipes are fully prepped in the export.", call. = FALSE)
  }
  if (!is.null(extras) && interactive()) {
    extra_size <- pryr::object_size(extras)
    message("Extras included on export for future diagnostics. ",
            "Estimated size is ", extra_size, " before compression.")
  }
  for (k in seq_along(recipes)) {
  recipes[[k]]$steps <- modify_depth(.x = recipes[[k]]$steps, .depth = 2, .f = minimize, .ragged = TRUE)
  }
  if (sum(!str_detect(attributes[["AttributeName"]], "[A-Z]")) != 0 & interactive()) {
    bad_attrs <- which(!str_detect(attributes[["AttributeName"]], "[A-Z]"))
    warning("There appears to be at least one malformed AttributeName: ",
            collapse(attributes[['AttributeName"']][bad_attrs], sep = ", ",
                     last = " and "), call. = FALSE)
  }
  small_recipes <- lapply(recipes, minimize)
  serialized <- lapply(small_recipes, function(x)
    memCompress(serialize(list(RetailModel = x,
                               AuctionModel = NULL,
                               ExportedObjects = exports,
                               extras = extras), NULL)))
  dates <- lapply(recipes, function(x)
    x$steps$add_date$date)
  if (interactive()) {
    len <- length(dates)
    start <- dates[[1]]
    end <- dates[[len]]
    message(glue::glue("Exporting {len} models for Benchmark, \\
                       ranging from {start} to {end}."))
    test <- system.time(unserialize(memDecompress(serialized[[1]], "gzip")))
    message("The first minimized scoring recipe is ", round(object_size(serialized[[1]])/1000000, 3),
            " MB after compression. ",
            "This will take an estimated ", round(test[[3]], 2), " seconds",
            " to load on scoring.")
  }
  toJSON(list(CategoryID = category_id,
              Description = paste("Category", category_id, "Benchmark"),
              SerializedRModels = serialized,
              ModelEndDates = dates,
              AttributeList = unique(attributes, by = "AttributeName")),
         .withNames = TRUE,
         auto_unbox = TRUE,
         digits = NA)

}


#' Stores relationship between derived and source variables
#'
#' @param ... Arguments should be of the form `derived_var = "source_var"`.
#' @param source Alternative method of passing for programming.
#' @param derived Alternative method of passing for programming.
#' @details Each time `cache_dependency()` is called,
#' dependencies are resolved. Each derived variable is linked to the terminal
#' source variable, not it's immediate parent. Each derived variable may only
#' have one immediate source variable. This is to prevent confusing error
#' messages on FE. For example, region depends on state, not state and country. This
#' is more a function of front-end decisions than technical limitations on R side.
#' @export
#' @examples
#' \dontrun{
#' cache_dependency(age_group = "age", age = "year")
#' shtrain:::shdata$dependencies
#' }
#'
cache_dependency <- function(..., source, derived) {
  #TODO Error
  # Making this change will allow multiple dependencies for each derived variable.
  # allow function calls like
  # cache_dependency(derived_var = c(source_var1, source_var2), ...)
  # cache_dependency(derived = derived_var, source = c(source_var1, source_var2))
  # Now: Named list, each element length 1, derived=source pairs.
  # New: Named list, each element variable length, derived = c(source1, source2,...)
  # I've made brief comments about what each piece does.
  if (missing(source) & missing(derived)) {
    dependencies <- list(...)
    if (anyNA(names(dependencies))) {
      stop("Every argument must be named with the derived variable name.")
    }
    shdata$dependencies <- c(shdata$dependencies, dependencies)
  } else {
    # Change this stopifnot as needed.
    stopifnot(length(source) == length(derived) | length(source) == 1 & length(derived) > 0)
    if (length(source) == 1) {
      source <- rep(source, length(derived))
    }
    new_dependencies <- vector(mode = "list", length = length(source))
    new_dependencies <- source
    names(new_dependencies) <- derived
    shdata$dependencies <- c(shdata$dependencies, new_dependencies)
  }
  # If a derived variable is cached again, delete the first dependency definition and keep the lasat.
  shdata$dependencies <- shdata$dependencies[!duplicated(names(shdata$dependencies), fromLast = TRUE)]
  # If a variable is defined as being its own source, delete it.
  circular <- which(names(shdata$dependencies) == unlist(shdata$dependencies))
  if (length(circular)) {
  shdata$dependencies <- shdata$dependencies[-circular]
  }
  # Find the SQL-sourced dependencies for each derived variable.
  shdata$dependencies <- resolve_dependencies(shdata$dependencies)
  # Change all manufacturer/model/model_group dependencies to make_model.
  mm <- unlist(shdata$dependencies, use.names = FALSE)
  mms <- str_detect(mm, "^(model|model_group|manufacturer)$")
  # This will need to iterate through the elements instead, since they can be > length 1
  shdata$dependencies[mms] <- "make_model"
  if (getOption("shtrain.industry", -99) == 28) {
    mm <- unlist(shdata$dependencies, use.names = FALSE)
    mms <- str_detect(mm, "^(make_model)$")
    shdata$dependencies[mms] <- "manufacturer"
  }
  #TODO Safety
  # Check variables against the valid ones in MMM for this category. This is needed in several places,
  # might be best to query & store in shref on the call to `get_all_data()`?
  invisible(shdata$dependencies)
}

#' Link derived variables with their sources
#'
#' Traverse the dependency tree to relate each derived variable to one
#' source variable.
#' @param x `shtrain:::shdata$dependencies`, most typically.
#' @return A named list where each name is a derived variable, and each element is
#' a vector of SQL-sourced variables.
#' @importFrom data.table chmatch data.table
resolve_dependencies <- function(x) {

  #TODO Error
  # This'll need a major change for multiple dependencies.
  # First, write some tests in tests/testthat/ to make sure current behavior is retained.
  # Basic algorithm
  # For each list element I of x,
  #   For each element J of I,
  #     Compare to names(x). If J %in% names(x), replace J with the vector in the matching slot of x.
  #   Repeat until none match. Each element of piece of the list should now be in derived = c(source1, source2,...)
  # form, where all the variables come from SQL
  #
  # Note that J might be growing during this algorithm, so account for that. Make sure each J only
  # contains unique values, don't have two source variables of "make_model", "make_model" present.
  all_derived <- names(x)
  # browser()
  while (!exists("relation", inherits = FALSE) || sum(relation[["child_of"]] > 0)) {
    second_gen <- chmatch(unlist(x, use.names = FALSE),all_derived,  nomatch = 0L)
    first_gen <- chmatch(all_derived, unlist(x, use.names = FALSE), nomatch = 0L)
    relation <- data.table(index = seq_along(first_gen),
                           parent_of = first_gen,
                           child_of = second_gen)
    for (k in seq_along(relation$index)) {
      child <- relation[["child_of"]][k]
      parent <- relation[["parent_of"]][k]
      x[[k]] <- if (child > 0) {
        x[[child]]
      } else {
        x[[k]]
      }
    }
  }
  x
}

#' Reduces object size
#'
#' Reduces object size for `glm` and `recipe` objects.
#' Some methods, such as summary for `glm` will break.
#' __Deprecated__ Do not use this function in a script. It is called internally
#' on [prep()], where appropriate.
#' This function will not be exported in future versions.
#' @param object A `recipe` or `glm` object.
#' @export
minimize <- function(object, ...) {
  UseMethod("minimize")
}
#' @export
minimize.glm <- function(object, ...) {
  object$residuals = NULL
  object$fitted.values = NULL
  object$effects = NULL
  object$qr$qr = NULL
  object$linear.predictors = NULL
  object$R = NULL
  object$y = NULL
  object$model = NULL
  object$weights = NULL
  object$prior.weights = NULL
  object$data = NULL
  object$contrasts = NULL
  object$method = NULL
  object$control = NULL
  object$offset = NULL
  object$call = NULL
  # object$formula = NULL
  object$deviance = NULL
  object$aic = NULL
  object$null.deviance = NULL
  object$iter = NULL
  object$df.residual = NULL
  object$df.null = NULL
  object$converged = NULL
  object$boundary = NULL
  object$family$variance = NULL
  object$family$dev.resids = NULL
  object$family$aic = NULL
  object$family$validmu = NULL
  object$family$simulate = NULL
  attr(object$terms, ".Environment") = NULL
  attr(object$formula, ".Environment") = NULL
  object
}
#' @export
minimize.recipe <- function(object, ...) {
  object$template <- NULL
  object$trained <- NULL
  object
}
#' @export
minimize.list <- function(object, ...) {
  lapply(object, minimize)
}
#' @export
minimize.rpart <- function(object, ...) {
  object$xlevels <- attr(object, "xlevels")
  attr(object$terms, ".Environment") = NULL
  object$cptable <- NULL
  object$y <- NULL
  object$where <- NULL
  object$variable.importance <- NULL
  object$call <- NULL
  object
}

#' @export
minimize.default <- function(object, ...) {
  # if (interactive()) {
  #   warning("No `minimize` method exists for object of class(es) ", lc(class(object)), ".",
  #           "Returning `object` unmodified.", call. = FALSE)
  # }
  object
}

#' Recreate environment for scoring
#'
#' `step_shref` creates a *specification* of a recipe step that will
#'   recreate the internal package environment `shref`, which some functions reference.
#' @inheritParams step_basic
#' @param ref_env Set during prep.
#' @inherit step_basic return
#' @export
#' @details
#'  Step: Nothing
#'  Prep: Creates named list from `shtrain:::shref`.
#'  Bake: Copies the list to the environment `shref`.
step_shref <- function(recipe, ref_env = NULL, trained = FALSE) {
  add_step(recipe,
           step_shref_new(
             ref_env = ref_env,
             trained = trained
           )
  )
}

step_shref_new <- function(ref_env = NULL, trained = FALSE) {
  step(subclass = "shref",
       ref_env = ref_env,
       trained = trained)
}

prep.step_shref <- function(x, training, ...) {
  cache_names(
    r = c("evaluation", "priority_order", "evaluation_type", "required_fields", "invalid_data", "exceed_eval",
          "upper_eval_bound", "lower_eval_bound", "spec_json", "r_message", "ref_id", "insufficient_data"),
    sql = c("Evaluation", "PriorityOrder", "EvaluationType", "RequiredFieldsError", "InvalidDataError", "ExceedEvalBound",
            "AcceptableEvalUpper", "AcceptableEvalLower", "SpecsUsedinModel", "MessageFromR", "ReferenceID",
            "InsufficientDataError")
  )
  list_env <- as.list(shref, all.names = TRUE)
  step_shref_new(ref_env = list_env,
                 trained = TRUE)
}

bake.step_shref <- function(object, newdata, ...) {
  if (!exists("shref")) {
    shref <<- new.env(parent = emptyenv())
  }
  if (length(shref) == 0) {
    list2env(object$ref_env, envir = shref)
  }
  newdata
}

