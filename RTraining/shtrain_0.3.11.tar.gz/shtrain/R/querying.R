##### Functions for constructing queries.
#' Generates a SQL query
#'
#' Writes a basic SQL query. This is used to translate and validate queries against asking,
#'  auction, or aftersale views. It will filter to observations with the correct category IDs, and perform
#'  name translation appropriate for the \code{data_type} provided. Special selections
#'  and default selections will be added to the \code{SELECT} statement. Simple matching
#'  is also available. See \code{browseVignettes("shtrain")}
#'
#' @param data_type  'auction', 'asking', or 'aftersale'.
#' @param category_id A valid category ID.
#' @param print_query Print the query to the console (as a message). Useful for debugging.
#' @param selections A character vector of columns to select. * not supported.
#'
#' @return Query string.
#' @export
#' @importFrom glue glue collapse
#' @importFrom RODBC odbcClose
base_query <- function(data_type,  category_id, selections, print_query = FALSE, archive = FALSE, con = NULL) {
  industry <- if (!is.character(category_id)) {
   get_industry(category_id = category_id)
  } else {
    category_id
  }
   if (is.null(con)) {
      con <- create_server_connection()
      on.exit(odbcClose(con))
   }
  if (length(selections) == 1 && selections == "*") {

    selections <- all_valid_selections <- sql_columns(con, category_id[1], all = TRUE)[[data_type]]
    sql_selections <- translate_names(names = all_valid_selections, from = "r", to = data_type)
  } else {
  valid_type_selections <- shdata$name_table[[data_type]] #  SQL names
  valid_industry_selections <- shdata$industry_selections[[industry]] # R Names
  def_sels <- shdata$default_selection_table # R Names
  default_selections <- def_sels[def_sels[,"industry"] %in%
                                   c("all", industry) , data_type]
  filter_selections <- shdata$filter_selections[[data_type]] # R names
  selections <- expand_selections(selections, type = data_type) # R names
  all_selections <- c(default_selections, selections, filter_selections)
  all_valid_selections <- intersect(all_selections, sql_columns(con, category_id[1], all = TRUE)[[data_type]])
  sql_selections <- translate_names(names = all_valid_selections, from = "r", to = data_type)
  }
  tbl <- get_table_name(category_id = category_id, type = data_type, archive = archive)
  if (!all(selections %in% all_valid_selections)) {
    missing <- setdiff(selections, all_valid_selections)
    if (interactive() || getOption("shtrain.verbose", FALSE)) {
    missing <- setdiff(missing, c("oh_id", "ps_id"))
    message(glue("{lc(missing)} not in {tbl}", "."))
    }
  }
 query <- if (!is.character(category_id)) {
   glue("SELECT {collapse(sql_selections, sep = ', ')} from {`tbl`} (NOLOCK) WHERE CategoryID IN ({collapse(category_id, sep = ', ')})")
  } else {
   glue("SELECT {collapse(sql_selections, sep = ', ')} from {`tbl`} (NOLOCK)")
  }
  if (isTRUE(print_query)) {
    message(query)
  }
  query
}

comma_split <- function(x) {
  if (is.character(x) & length(x) == 1) {
    trimws(unlist(strsplit(x, ","), use.names = FALSE))
  } else {
    x
  }
}


#' Expand selections
#'
#' Performs name expansion using \code{shdata$special_selections} and
#'   basic pattern matching using "_*" as a suffix.
#'
#' @param selections Vector of selections after conversion to \R names.
#'
#' @return A vector of selections.
#' @keywords internal
expand_selections <- function(selections, type) {
  selections <- comma_split(selections)
  if (type %in% c("auction", "asking", "aftersale")) {
    special_selections <-
      intersect(selections, names(shdata$special_selections))
    selections <- setdiff(selections, special_selections)
    expanded_selections <-
      c(selections,
        unlist(shdata$special_selections[special_selections], use.names = FALSE))
    star_selections <-
      selections[grepl("[[:alnum:]]+_\\*$", selections)]
    matchers <- gsub("_*", "", star_selections, fixed = TRUE)
    expanded_selections <- setdiff(expanded_selections, star_selections)
    expanded_selections <- c(expanded_selections,
                             unlist(lapply(matchers,
                                           function(x)
                                             grep(x,
                                                  shdata$name_table[["r"]],
                                                  ignore.case = TRUE,
                                                  value = TRUE
                                             )),
                                    use.names = FALSE)) }  else {
                                      # expanded_selections <- str_ex(".*_\\*", "*", selections)
    expanded_selections <- selections
                                    }
  expanded_selections
}


#' Query using R names
#'
#' Specify a query using any mix of R and SQL names, as long as they all belong
#'   to the same view. By providing type and category ID, the correct view name is
#'   inserted.
#' @param query Character string of the query. Use 'tbl' to represent the
#'   table. This will be replaced with the correct one for you.
#' @param type auction, asking, aftersale, supplemental, default, dynamic. See details.
#' @param category_id If a spec table, a single ID. If a base table,
#'   a vector of category IDs belonging to the same industry. This is used to
#'   identify the table. If you are performing a query against all trucks,
#'   simply provide any category ID within that industry.
#' @export
#' @importFrom RODBC sqlQuery
#' @importFrom glue glue
#' @examples \dontrun{
#' library(snakecase)
#' library(shtrain)
#' library(stringr)
#' library(RODBC)
#' con <- create_server_connection()
#' custom_query(con = con, "auction", 1038, query = "SELECT category_id, reference_id,
#'               model FROM tbl where category_id = 1038")
#' custom_query(con = con, "asking", 1026,
#'            query = "SELECT count(*), manufacturer from tbl
#'                where category_id in (1026, 1038) group by manufacturer")
#'
#' example <- custom_query(con,  "auction", 210, query = "SELECT COUNT(*) as number,
#'             category_id from tbl group by category_id order by category_id desc"))
#' head(example) # Oh no! I don't like the name ObjectCategoryID.
#' head(change_names(data = example, from = "sql"))
#' # change_names uses the name_cache table. The name_cache table caches base specs
#' # in the order of aftersale, auction, and asking. What this means is the
#' # asking name will take precedence over the other two. Extended specs
#' # are cached upon using \code{add_specs} or \code{custom_query} one a
#' # default, dynamic, or custom table.
#' example2 <- custom_query(con, "supplemental", 1026,
#'        query  = "SELECT count(*) as number,
#'                  'sup_transmission_rebuilt' as variable,
#'                  sup_transmission_rebuilt as value
#'                  from tbl
#'                  group by sup_transmission_rebuilt
#'                  UNION (select count(*) as number,
#'                  'sup_engine_rebuilt' as variable,
#'                  sup_engine_rebuilt as value
#'                  from tbl
#'                  group by sup_engine_rebuilt)
#'               order by variable, value desc")
#' # Oh no! now the names are in a column.
#'
#' example2
#' example2[,"variable"] <- snakecase::to_snake_case(example2[,"variable"])
#' example2
#' }
custom_query <- function(con, type, category_id, query) {
  if (type %in% c("supplemental", "dynamic", "default")) {
    sql_names <- sql_columns(con = con, category_id = category_id, raw = TRUE, all = TRUE)[[type]]
    r_names <- sql_columns(con = con, category_id =  category_id, raw = FALSE, all = TRUE)[[type]]
    cache_names(r = r_names, sql = sql_names)
    names(sql_names) <- r_names
    # query <- tolower(query)
    tbl <- get_table_name(type = type, category_id = category_id)
    query <-  gsub("\\stbl\\s", " {tbl} (NOLOCK) ", query)
    translated_query <- translate_string(query, matches = sql_names)
    final_query <- glue::glue(translated_query)
  } else{
    # query <- tolower(query)
    tbl <- get_table_name(type = type, category_id = category_id)
    query <-  gsub("\\stbl\\s", " {tbl} (NOLOCK) ", query)
    translated_query <- translate_string(query, from = "r", to = type)
    final_query <- glue::glue(translated_query)
  }
  sqlQuery(con, query = final_query, stringsAsFactors = FALSE)
}




#' Lookup base DB for a base category or industry
#'
#' Takes a vector of base category IDs or industry abbreviations
#' and returns the corresponding DB names.
#'
#' @param x A vector of base category IDs or industry abbreviations.
#' @return The db names or `character(0)` if no match is found.
#' @examples
#' base_db(4)
#' base_db(c(13, 464))
#' base_db("mat")
#' base_db("matt")
base_db <- function(x) {
  dbl <- shdata$db_lookup
  if (is.numeric(x)) {
    dbl[base_category_id %in% x, db_name]
  } else if (is.character(x)) {
    dbl[industry %in% tolower(x), db_name]
  } else {
    stop("Please enter a number (base category ID) or character (industry abbreviation)",
         call. = FALSE)
  }
}


#' @importFrom RODBC odbcClose sqlQuery
#' @importFrom data.table :=
#' @importFrom glue glue
featured_listings <- function(data) {
  data <- copy(data)
  industry <- get_industry(data = data)
  tbl <- switch(industry,
                "mat" = "dbMachinery.dbo.FeaturedListing",
                "tho" = "dbTractorHouse.dbo.FeaturedListing",
                "trk" = "dbTruck.dbo.FeaturedListing",
                "trl" = "dbTruck.dbo.FeaturedListing",
                "cnt" = "dbController.dbo.FeaturedListing")
  archive <- switch(industry,
                    "mat" = "dbMachinery.dbo.ArchiveFeaturedListing",
                    "tho" = "dbTractorHouse.dbo.ArchiveFeaturedListing",
                    "trk" = "dbTruck.dbo.ArchiveFeaturedListing",
                    "trl" = "dbTruck.dbo.ArchiveFeaturedListing",
                    "cnt" = "dbController.dbo.ArchiveFeaturedListing")
  con <- create_server_connection()
  on.exit(odbcClose(con))
  id_col <- switch(industry,
                   "cnt" = "FeaturedListingID",
                   "ListingID")
  features <- sqlQuery(con, glue("SELECT DISTINCT({id_col}) as ref_id, ExternalID as ds_lookup_id, COUNT({id_col}) AS feat_count
                                 FROM {tbl} (NOLOCK)
                                 GROUP BY externalID, {id_col}
                                 "), stringsAsFactors = FALSE)
  archive_features <- sqlQuery(con, glue("SELECT DISTINCT({id_col}) as ref_id, ExternalID as ds_lookup_id, COUNT({id_col}) AS feat_count
                                         FROM {archive} (NOLOCK)
                                         GROUP BY externalID, {id_col}
                                         "), stringsAsFactors = FALSE)
  featured1 <- data[["ref_id"]] %in% features[["ref_id"]]
  featured2 <- data[["ds_lookup_id"]] %in% features[["ds_lookup_id"]]
  all_featured <- featured1 | featured2
  old_featured1 <- data[["ref_id"]] %in% archive_features[["ref_id"]]
  old_featured2 <- data[["ds_lookup_id"]] %in% archive_features[["ds_lookup_id"]]
  all_old_featured <- old_featured1 | old_featured2
  current <- all_featured & !all_old_featured
  data[current, featured := "current"]
  past <- all_old_featured & !all_featured
  data[past, featured := "past"]
  both <- all_old_featured & all_featured
  data[both, featured := "both"]
  data[aftersale(), featured := NA_character_]
  data
}


#### TO-DO
# Use these tables in conjunction with featured listing tables to determine number of weeks featured.
# active status too
#   SELECT TOP 10 *
#   FROM dbMachinery.dbo.FeaturedListing FL(NOLOCK)
# INNER JOIN dbShared.dbo.PublicationType PT(NOLOCK) ON PT.PublicationTypeID = FL.PublicationTypeID
# LEFT JOIN dbShared.dbo.EditionType ET(NOLOCK) ON ET.EditionTypeID = FL.EditionTypeID


