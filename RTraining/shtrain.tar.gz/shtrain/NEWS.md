## **Version 0.3.10**
##### 2019-10-24
##### [TO# 32983181](http://intranet/TaskOrder/taskorderdetail.aspx?toid=32983181)

### *Bug Fixes*
* `.format_numeric()` now called within `get_duplicate_listings_records()` to fix undesired 
behavior from ReferenceIDs of class "integer". 
* `get_data()` now references the already-defined "bcat" variable instead of defining another 
redundant variable "base_cat". 
* `get_data()` now only removes HiBid records for MAT categories (BaseCategoryID = 4).


-----


## **Version 0.3.9**
##### 2019-10-17
##### [TO# 32836489](http://intranet/TaskOrder/taskorderdetail.aspx?toid=32836489)

### *Breaking changes*
* `check_levels()` removed from package.
* `web_start_date()` removed from package.

### *New features*
* New function `update_duplicate_table()`. Identifies duplicate listing records to be updated in 
dbo.DuplicateListingRecord(Archive) for a given BaseCategoryID.
* New function `get_duplicate_listing_records()`. Returns the contents of dbo.DuplicateListingRecord as
they existed on the date specified.
* New function `correct_duplicate_listings()`. Each listing identified as a duplicate is either removed
from the data, or receives an updated WebStartDate.
* New function `create_hibid_report()`. Creates a .csv report of HiBid records in our "asking" data.
* New function `read_hibid_report()`. Reads and formats a .csv report created by `create_hibid_report()`.
* New function `remove_hibid_records()`. Removes HiBid records from "asking" data within `get_data()`.
* New paramter "remove_hibid_records" in `get_data()`. If TRUE (default), removes HiBid records 
from "asking" and "archive asking" data.
* Updated `get_data()` to set a global option of "'shtrain.industry' = 28" whenever the supplied 
"category_id" is within the trailer industry (BaseCategoryID = 28).
* Updated `get_data()` to call `update_duplicate_table()`, if necessary, before calling 
`correct_duplicate_listings()` on "asking" and "archive asking" data.
* Updated `get_all_data()` to appropriately handle the new `get_data()` parameter "remove_hibid_records".
* Updated `bake.check_insufficient_data()` to add an "Insufficient" error message for "Manufacturer" 
instead of "MakeModel" for trailer categories. References global option "shtrain.industry".
* Updated `cache_dependency()` to store a source variable of "Manufacturer" instead of "MakeModel" for
trailers, when appropriate. References global option "shtrain.industry".

### *Other*
* Updated the documentation for `swap_columns()`.
* *Deprecated*: `create_duplicate_report()`. Please use `update_duplicate_table()`.
* *Deprecated*: `read_duplicate_report()`. Please use `get_duplicate_listing_records()`.
* *Deprecated*: `correct_duplicates()`. Please use `correct_duplicate_listings()`. 


-----


## **Version 0.3.8**
##### 2019-08-23
##### [TO# 31957926](http://intranet/TaskOrder/taskorderdetail.aspx?toid=31957926)

### *Bug Fix*
* Updated `.add_continuous_group()` to match Version 0.3.6 update to `add_continuous_group()`.


-----


## **Version 0.3.7**
##### 2019-08-20
##### [TO# 31895360](http://intranet/TaskOrder/taskorderdetail.aspx?toid=31895360)

### *Bug Fix*
* Updated `bound_range()` to call "data" and not "newdata".


-----


## **Version 0.3.6**
##### 2019-08-15
##### [TO# 31262202](http://intranet/TaskOrder/taskorderdetail.aspx?toid=31262202)

### *New features*
* Added "dig.lab = 15" argument to `cut()` in `add_continuous_group()`, and changed 
the inclusive upper bound around infinity to an exclusive bound, improving the names
both in readability and notation.
   + E.g. "(5000,Inf)" instead of "(5e+03, Inf]"
* `check_slope_coefficients()` now only returns a data.table. Previously, it could
return a data.table or an empty list. Ensuring a data.table is always returned, 
regardless of whether or not it's empty, should alleviate some of the errors we have 
been seeing during weekly import.
* `check_condition()` now adds "; Unsupported: Condition" to the 'r_message' field. 
Previously, this message was ";Not Used". 
* `check_country()` now adds "; Unsupported: Country" to the 'r_message' field.
Previously, this message was ";No FE: Country". 
* `check_state()` now adds "; Unsupported: State" to the 'r_message' field.
Previously, this message was ";unsupported state". 
* `check_requirements()` now adds "; Requirement Violated" to the 'r_message' field. 
Previously, this message was ";Reqs Violated". 
* `bound_range()` and `step_bound_range()` now add "Lower/Upper Bound: {spec}"
to the 'r_message' field. An example of the previous message is "bound: hoursunder".
* `step_validate()` now adds "; Validated: {spec}" message to the 'r_message' field.
This indicates that the value for {spec} was replaced with `NA`. 
* Justin changed the logic in Pr_CheckAutoRestoreJob to fit our FE needs again.
`db_restore_check()` should be good to use moving forward.

### *Other*
* Fixed some documentation bugs in `add_date()` and `step_merge()`.
* Message returned by `add_specs()` now separates spec names with ", ". 
* Implemented more specific requirements in `command_arguments()`.
* Updated documentation for `create_server_connection()`.
* Updated `read_duplicate_report()` to account for "Lab".
* Fixed the file path for accessing duplicate reports in `get_data()`. Previously, 
the file path was incorrect whenever the script was not run locally, so the relevant 
file was never successfully located, and a new report was always created. 
   + Should speed up imports on dev, staging, and live.
* Messages produced locally by `add_ratio_evaluations()` are now easier to read.


-----


## **Version 0.3.5**
##### 2019-06-06
##### [TO# 30640170](http://intranet/TaskOrder/taskorderdetail.aspx?toid=30640170)

### *Other*
* Fixed `add_specs()` bug by changing 'ref_id' to 'ref_id2'. This bug was withholding 
supplemental specs from a large number of aftersale records.
* Changed API key used in API URL links generated in `create_server_connection()`.
* Fixed `create_server_connection()` bug by adding env = "lab".
* Edited warning message produced within `copy_package()`.
* Updated documentation for `check_insufficient_data()` and `check_required_fields()`. 


-----


## **Version 0.3.4**
##### 2019-05-30
##### [TO# 30499954](http://intranet/TaskOrder/taskorderdetail.aspx?toid=30499954)

### *Breaking changes*
* `scraped_table()` removed from package. 

### *New features*
* New function `add_rec_spec()`. Checks and adds recommended specs to data.
* New function `db_restore_check()`. Checks the restore status of numerous databases.
Please add this to the top of each updated master.R script. 
* `add_json()` now includes recommended specs in the json, if any "rec_" specs
are found in the data.
* `check_insufficient_data()` now correctly checks the "ValidMakeModel" boolean
for all data, not only the current subset of the data.
* `command_arguments()` now accounts for the new 'lab' server 'SISQLDWSTG1\\DTA'
for testing, and is consistent with version of function in shconfig2.
* `create_server_connection()` can now handle server instances, such as the new
"lab" server instance 'SISQLDWSTG1\\DTA'.
* `impute_numeric()` can now impute specs using an absolute variance, in addition
to the default percent variance.
* `create_duplicate_report()` now correctly writes reports to the "Lab" directory
in DataScience on staging.

### *Other*
* `lc()` "sep" vs "collapse" bug-fix.
* `rm_duplicates()` now uses 'oh_id' instead of 'ref_id'.
* `sp_info()` rbind "fill = TRUE" bug-fix.
* `custom_query()` "stringsAsFactors = FALSE" bug-fix.
* `zzz.R` "stringsAsFactors = FALSE" bug-fix.
* `step_coalesce()` documentation typo fix.
* `add_msrp()` now lives in add_msrp.R, add_msrp2.R no longer exists.


-----


## **Version 0.3.3**
##### 2019-04-15
##### [TO# 29913759](http://intranet/TaskOrder/taskorderdetail.aspx?toid=29913759)

### *Version control*
* shtrain "sync"
* Using the latest version of the package pulled from Sean's computer, ensured that same 
version of shtrain exists in TFS, shared folder, and 3 environments.

### *Other*
* Moved `sp_info()` from savin to shtrain.
* Moved `check_row_id()` from savin to shtrain.
* Added documentation for `create_odbc_connection()`.
* Additional `bake.add_prediction()` bug-fix. 


-----


## **Version 0.3.2**
##### 2019-03-26
##### [TO# 29545787](http://intranet/TaskOrder/taskorderdetail.aspx?toid=29545787)

* `bake.add_prediction()` bug-fix 


-----


## **Version 0.3.1**
##### 2019-03-22
##### [TO# 26331662](http://intranet/TaskOrder/taskorderdetail.aspx?toid=26331662)

### *Error messaging*
It is now possible to provide differing error messages between formulas within a category script. Examples
showcasing this functionality are at the bottom of the relevant function documentation.

* `check_required_fields()` and `check_insufficient_data()` have gained `subset`  as a new argument. It takes a logical expression which will be evaluated in the context of the data. Only rows which have `subset == TRUE` will receive error messages from this step definition. By providing multiple checks of the same type with mutually exclusive `subset` arguments and manually specified `check` vectors, you may provide differing sets of required variables. The default of `subset` is `NULL`, which will retain old behavior.
* Added tests to ensure functionality of new features.

### *New features*
* New function `impute_numeric()`. Please remove use of user-defined `impute_numeric()` from scripts going forward.
* New function `step_roll_join()`. Please remove use of `step_roll_join_custom()` from scripts going forward. Tests have been added for this function.
* New functions `cascade_join()` `step_cascade_join()`. Please remove use of `cascade_join()`, `step_cascade_join_custom()` from scripts going forward. Tests have been added for this function.
* New function `add_ratio_evaluations()`. See documentation for details. Tests have been added for this function.
* `add_prediction()` class-detection for `rx*` models has been fixed. Please use this in lieu of `add_predictions()`,
a custom function which is defined in many categories.
* New function `create_trusted_connection()`, which creates a RODBC connection using your Windows credentials.
You may specify server and database.
* `step_validate()` now validates character columns. The input to the `validate` list for character columns should be of the form `col_name = c(possible_value1, possible_value2, ...)`.
* `fleet_evaluator_model()` and `benchmark_model()` gained a new argument, `extras`. This can comprise
whatever you want to save with the serialized model. It should:
    1. Not be overly large.
    2. Not contain information to be used in the scoring recipe.

### *Other*
* Added test for new `step_validate()` functionality.
* Update to `step_coalesce()` documentation and examples.
* Reorganized tests/testthat directory.
* `get_mode()` methods are exported.
* Greatly expanded `check_slope_coefficients()` documentation.
* `resolve_dependencies()` can no longer fall into an infinite loop (Oops!).
* `na.action` is maintained in `minimize.rpart()`.
* `step_coalesce()` correctly matches on full prefix, such as "sup_". Previous behavior did not
include the underscore.
* `recipe.data.frame()` passes `info` through to `recipe.data.table()`.
* `summary.impute_ratio()`. Also re-orders on `prop` internally in case any re-ordering
took place between `impute_ratio()` and its `summary()` method.
* `add_continuous_group()` no longer emits a warning when specifying group column namse manually.
* `cv_model()` removed from package. If working in a category which used it, replace with holdout approach. Does not affect live scripts since this is never run on production.
* `impute_ratio()` documentation updated.
* `export_data()` documentation updated.
* `add_region()` documentation updated.
* `attr_data()` documentation updated.
*  Other documentation improvements.


-----


## **Version 0.3.0**
##### 2019-03-06
##### [TO# 29244327](http://intranet/TaskOrder/taskorderdetail.aspx?toid=29244327)

### *New features*
* Added new functions `create_odbc_connection()` and `execute_sp()` in `odbc.R`. 
* New function `create_provider_info()`. Queries and formats relevant provider 
information for use when creating duplicate record reports.
* New function `create_duplicate_report()`. Creates a .csv report on duplicate 
listings for given industries. 
* New function `read_duplicate_report()`. Can be used to easily read in and 
format the data within the duplicate report .csv files.
* New function `correct_duplicates()`. Updates or removes duplicate asking
records using the appropriate duplicate report. 
* Update to `get_data()`. Additional logical argument "correct_duplicates",
defaulted to TRUE. Specifies whether or not to use `correct_duplicates()` 
to remove duplicates records from the data before returning.
* Update to `get_all_data()`. Additional logical argument "correct_duplicates",
defaulted to TRUE.


-----


## **Version 0.2.12**
##### 2019-02-17

* `check_condition()` now returns "Invalid Data: Condition".
* Update `step_coalsce()` diagnostic message to properly separate orders.


-----


## **Version 0.2.11**
##### 2019-02-19
##### [TO# 28761258](http://intranet/TaskOrder/taskorderdetail.aspx?toid=28761258)

* The location of the website has been updated to `\\sandhills.int\file\Data\DTA\R\Resources\website\index.html`.
Update any bookmarks accordingly.
* Added new selections "oh_id" and "ps_id" in `get_all_data()`. These should
be preferred for use over "ref_id", which would be great to phase out. They will
will be pulled by default.
"oh_id" will be ObjectHistoryID for all 3 data types, "ps_id" will only exist for
aftersale. "ref_id" will continue to exist as it always has. 
* `get_all_data()` will pull in "oh_id" by default to make sure aftersale data
gets all the supplemental specs it should.
* `add_specs()` accounts for new columns "oh_id" and "ps_id", which means more
aftersale listings will receive supplemental specs.
* `add_specs()` filters on "reference_type_id" to exclude scraped listings. The
entry-point for scraped listing information does not properly validate listing
information. We can remove this filter at a later date.
* Update to website to include How-Tos under the "R" menu heading. The source
files are in TFS if you would like to suggest changes to the directions.
* Reorganization of other help files.


-----


## **Version 0.2.10**
##### 2018-11-19
##### [TO# 27887869](http://intranet/TaskOrder/taskorderdetail.aspx?toid=27887869)

* Change `format_yes_no()` to avoid changing "HoursMeterInaccurate", "EngineRebuilt",
and "TransmissionRebuilt" from 1/0 to yes/no. Maintains compability with `filter_sup_specs()`,
and retains identical behavior between industries.


-----


## **Version 0.2.9**

* New recipe step `step_counts_usage()`. Parses several non-numeric forms of a count
into the purely numeric representation. See documentation for details.
* Added test for `steps_counts_usage()`.
* Update to internal function to ensure all tests pass.
* Added "Regular expressions" section to the resources article.
* Minor documentation updates.


-----


## **Version 0.2.8**
##### 2018-10-08
##### [TO# 26949706](http://intranet/TaskOrder/taskorderdetail.aspx?toid=26949706)

* New recipe step `add_prediction()`. Note the lack of an "s" at the end to differentiate from versions found in scripts. Arguments slightly different, see documentation. `add_rx_predictions()` was skipped in favor of rolling all functionality into this function.
* New function for `i`-slot of a `data.table`: `current_asking()`. It will subset to rows which satisfy `data_type == asking() & web_end_date > as.IDate(Sys.Date(), origin = "1753-01-01")`. Now works even if nested inside parentheses in the `[.data.table` call.
* New recipe step `step_coalesce()`, courtesy of Tyler. It takes a spec data source `order`ing (dlr, sup, def, imp) and optionally a vector of columns. It successively replaces missing values in the first spec data source, preferring values from sources in order. Similar to SQL's coalesce function. See documentation.
* New recipe step `step_validate()`, courtesy of Tyler. It takes a named list of bounds. Any value outside of those bounds for the spec is set to `NA_real_`. Conveniently, you may also provide a vector of spec data source types to provide the same bounds to multiple columns. *If used on export, do not validate dealer-entered values!*. See documentation.
* New functions `set_r_names()`, `set_sql_names()`. These will take a `data.table` and
update the names by reference -- you do not need to assign the result back to a name.
* New function `trained()`. Equivalent to `prep(recipe, retain = TRUE) %>% {.$trained}`.
* New recipe step `add_wmqy()`, courtesy of Tyler. Adds `month_of_sale`, `week_of_sale`, `year_of_sale`, and  `quarter_of_sale`. All of these may be toggled by logical arguments.
* New method `minimize.rpart()`. 
* `fleet_evaluator_model()` will now `minimize()` any object of class "rpart", "glm" or "recipe" within the steps of the outer recipe.
As new `minimize()` methods are added, they will also receive this behavior. With this change, *you no longer need to manually `minimize()`objects*.
* Reworked `add_msrp()` to be a recipe step. See documentation.
* `impute_ratio()` allows min_ratio/min_count to be the same length as `col`, meaning only one call should be necessary to produce all imputations.
* `impute_ratio()` now picks highest proportion value which exceeds `min_ratio`. This is useful in conjunction with `min_ratio < 0.50`, and is no different for
`min_ratio >= 0.50`. `min_ratio == 0` corresponds to choosing a mode.
* `bake.filter_sale_date()`, `.filter_sale_date()` will remove auction listings with a sale date greater than `Sys.Date()`.
* Removed extraneous `copy()` arguments from recipe steps.
* CNT categories gained a default age offset of 0.
* Removed cleanse_numerics.R file, whose functions were contained elsewhere.
* Added tests for `step_coalesce()`, `step_validate()`, and subsetters (`auction()`, `aftersale()`, etc.)
* `review_status_table()` now works.
* Listings which fail `check_condition()` will skip additional checks.
* `check_state()` properly delimits error messages.
* `command_arguments()` now looks for `shconfig2.env` as an option to determine environment.
* `command_arguments()` is more intelligent about when it is being run on util servers vs. running from CLI elsewhere.
* Added note to documentation of `step_dt()` about `i = NULL`.


-----


## **Version 0.2.7**
##### 2018-08-06
##### [TO# 26411726](http://intranet/TaskOrder/taskorderdetail.aspx?toid=26411726)

* `scraped_table()` now contains the `scraped_provider` column. This can be useful
for determining whi
* `impute_ratio()` added to the package - note the name change.
*  New  `summary` method for class `impute_ratio`. `summary(<impute_ratio>)`
will reformat the input data into, for example, a `data.table` with columns
`make_model`, `imp_horse_power`, and `imp_capacity`.
* `mm_table()` returns additional columns. See documentation.
* New function `mm_check()`. This will add `odc_status` and `n_categories`
to the data, which can be used to determine the validity of make models. 
`odc_status == 'active' & n_categories > 0` active cat/make/models.
* New function `filter_sup_conditions()`, courtesy of Tyler.
* Enormous file reorganization.
* `score_models()` will return asking evaluations in the SP.
* `get_all_data()` no longer returns the `featured` column. This can be appended
to the data using `featured_listings()`. 
* `web_start_date` added as a default selection for asking views.
* `get_all_data()` and `get_data()`
* `get_data()` and `get_all_data()` significantly reworked to simplify code. This should
make it easier to pull just the type of data you want and still receive all 
formatting.
* `check_slope_coefficients()` gained a new column in its result, `numeric`. 
You can now subset like so: `factor == "manufacturer" & numeric == "age"`.
* `.format_numeric()` will no longer fail on data with no non-date numerics.
* `get_data()` adds a new logical column `archive`, to indicate which view it
came from. This is important becausue there are several issues which primarily
affect archived listings.
* `add_region()` now accepts `region_dt = data.table(NULL)` to indicate all
regions are handled by `region_list`.
* `add_age()` now has a default offset of 0 if it can't determine industry.
* `market_correction()`/`add_market_correction()` now have the `response` argument
to indicate what variable errors are calculated against.


-----


## **Version 0.2.6**
##### 2018-07-19
##### [TO# 26283100](http://intranet/TaskOrder/taskorderdetail.aspx?toid=26283100)

### *Multiple top-tier formula support*
* Modified 'check_insufficient_data()' to allow custom 'info' and 'check_required_fields()' 
to allow custom 'used_vars' to be supplied. 
* Modified 'add_evaluations()' to subset to rows without an evaluation if the evaluation
column already exists. 
* 'copy_package()' and 'attr_data()' now only print a warning message when run locally.
* Modified '.format_1_0()' to ensure that event_type_id is never changed to yes/no.


-----


## **Version 0.2.5**
##### 2018-06-21
##### [TO# 25813981](http://intranet/TaskOrder/taskorderdetail.aspx?toid=25813981)

### *One model support*
* Added `fleet_evaluator_model()` to make the export object. This only accepts
one recipe, and should be used going forward. See the documentation.
* Added `benchmark_model()` to make the Benchmark export object. This accepts
a list of recipes. See the documentation.
* `score_models()` now can be passed a single recipe in the `aftersale_recipe` 
argument. This recipe should generate `evaluation_*` columns, where 
`*` is one of "auction", "aftersale", or "asking".
* `add_evaluations()`'s `type` argument now accepts `evaluation_*` in addition
to "auction" and "retail". This allows for first providing evaluations
for `auction`, `aftersale`, or `asking` lists. If provided `evaluation_*`,
the prediction column will receive that name.
* `step_bound_evaluations()` will appropriately detect which column bounds
should be applied to. This will be `evaluation` for 2-recipe models,
`evaluation_aftersale` for 1-recipe models.
* `bake.add_date` will assign any row missing `data_type` the `object$date`, since
`data_type` is not populated on scoring with 1-recipe models.

### *Additions*
* `step_dt()` added to the package. This should have no conflicts with versions
sourced from files.
* Added several vignettes, accessible through `browseVignettes("shtrain")`.
* Support for Controller views.

### *Other*
* `score_models()` no longer reorders columns. This is done in the SP.
* `score_models()` no longer fails if a column isn't present and `strict == TRUE`. 
Instead, it provides a warning listing the missing columns.
The SP will create any columns which you do not provide and delete any extra.
In general, you should not post before fixing this warning. 
This will allow the SP to start requesting additional columns without needing a package update.
* Significantly improved `score_models()` documentation.
* Deleted several functions which weren't used in the package or any scripts.
* Size of the results of `copy_package()` reduced by about 60%.
* Removed all uses of `industry()`, `base_category_id()`, and `category_id()`.
This means we no longer need to use `set_category_id()`.
* `prep.add_json()` now checks each name provided for capital letters. It will warn
if any name does not include them, since our SQL standards use UpperCamelCase.
* Improved documentation for all filter steps. What each does and why should be
much clearer.
* Non-recipe versions of filter functions now documented with the recipe versions.
* `add_region()` correctly handles truck regions.
* Updated several messages and warnings.
* Some file reorganization.
* Fixed typo in `filter_web_end_date()` which resulted in always using `Sys.Date()`
for the cutoff.
* `cv_model()` correctly splits the data for cross validation.
* Greatly improved documentation on `check_insufficient_data()`.
* `check_insufficient_data()` correctly handles factor-derived numerics.
* Additional tests written.


-----


## **Version 0.2.4 (Live)**
##### 2018-05-04

* Addition of `cleanse_numerics()`, `step_fix_dimensions()`.
Who knows what else. I'm bad at documenting :(


-----


## **Version 0.2.3**
##### 2018-04-19
##### [TO# 25003517](http://intranet/TaskOrder/taskorderdetail.aspx?toid=25003517)

* web_start_date can be added with `data <- web_start_date(data)`
* `add_date()` gains new argument `date`, which defaults to today. This date will
be added to current asking, and auction/aftersale missing dates -- needed for scoring. Current asking are determined as having a `web_end_date` after `date`,
and `web_start_date` before. If `web_start_date` is not present, give any
asking points still missing `sale_date` `date`. This should ensure all live
categories keep the same results. 
* `filter_sale_date()` gains arguments `start_date` (previously `date`), and `end_date`. Setting these filters to listings with a `sale_date` between and including the dates. Removes missing values. Defaults to a 3 year period using
`end_date` as today.
* `cache_dependency()`'s behavior has changed. Passing any of model, model_group,
or manufacturer as the source will change the source variable to make_model.
FE recognizes MakeModel as an atomic unit, and doesn't consider manufacturer/model
separately. This should have no impact on existing code other than simplifying
error message resolution.
* `check_required_fields()` now excludes "state" by default.
* New function `reconcile_names()` to fix default or supplemental spec names which
do not have the correct casing to match static view or dynamic specs. This should
be called immediately after `add_specs()`. See `?reconcile_names`.
* `check_insufficient_data()` is complete. It takes the place of `check_levels()`. 
* Various helpers were added to assist in error messaging. If you need to write a custom
function for error messaging, see `dt_helpers.R`
* Archive Auction and Asking views are now available. They will be pulled in through `get_all_data(..., archive = TRUE)`.
See `?get_all_data` and `?get_data` for details.
* Tests were added to cover SQL name translation to R, FleetEvaluator error messaging, and others.
* Updated `recipe()` class and `prep()`. Using `prep(..., retain = TRUE)` will store the trained training data
into `recipe$trained`. This means each recipe will carry a copy of the un-trained and trained data. This will
be helpful for reporting, and prevents `bake()` from being run twice per recipe. Instead of 
`feature_data <- {pipeline} %>% prep() %>% bake()`, you can set `retain = TRUE`,
and do `feature_data <- {pipeline} %>% prep() %>% {.trained}`. Or, save the recipe to an object then extract the data.
* Misc improvements related to interactive messages.
* Misc documentation updates.
* `recipe()` now correctly accepts a `data.frame` input as coerces to `data.table`.
* `get_mode()`, used in `add_imputations()`, no longer errors on empty or all `NA` vectors.
* Several tests were added.

### *API*
This version brings a basic interface to Sandhills' APIs through the \R package `shapi`.
`shapi` is imported for use inside non-essential (read: not used in scoring) functions. 
* Added recipe step `format_yes_no()`. Given a category ID, this queries the MMM API
 and converts the appropriate specs in the data to yes/no. Note we do not need this
 step on scoring.
 
 
-----


## **Version 0.2.2**
##### 2018-03-26
##### [TO# 24740645](http://intranet/TaskOrder/taskorderdetail.aspx?toid=24740645)

* Quick fix for sale_type change "auction" -> "sold at auction"


-----


## **Version 0.2.1**

### *A snippet recipe demonstrating error messages*
```{r, eval = FALSE}
  step_bound_evaluations(bounds = c(1000, 150000), percent = 25, amount = 20000) %>%
  check_levels(bad_aftersale_levels) %>%
  check_required_fields(exclude = "state") %>%
  check_requirements(capacity <= 30000 & hours <= 15000, priority_order = 1) %>%
  check_requirements(year > 1950 & age > 0, priority_order = NULL) %>%
  check_country(allowed = c("usa", "canada")) %>%
  check_state(has_states = c("usa", "canada")) %>%
  check_condition() %>%
  check_insufficient_data(bad_aftersale_levels) %>%
  add_json() #%>%
```

### *Changes to make:*
1. If you were relying on `get_all_data()` doubling asking, use `double_asking()` after.
2. Add `filter_event_type_id()`.
3. Add `filter_aftersale_exclusions()`.
4. add `filter_web_end_date()`.
5. Remove `add_fe_message()` and use `check`s similar to above.

* New function: `filter_web_end_date()`. If `date` 
is not provided, uses today.
* New function: `filter_event_type_id()`. This filters asking data to event types
which correspond to 'for sale', 'for lease', and 'for rent'. 
* The `server` argument of `create_server_connection()` now allows you to connect
to sandhills.int servers where RDevelopmentUser is authorized. These include SISQLDWDEV1 and SISQLDWSTG2.
Use this along with `sqlQuery` to pull data for testing on environments. 
* `get_all_data` no longer doubles asking. Use `double_asking()` instead.
* If a US listing has a region, it will not be considered in `check_state()`'s "unsupported state" check. This allows
support for Alaska on a category by category basis. Will also apply for PR and HI if we ever start including them.
* `format_character()` gained an `exclude` argument to prevent typical formatting.
  Error message columns are always excluded from this formatting.
* New filter `filter_aftersale_exclusions()`. 
* New `check_` functions for generating errors. `check_requirements`,
`check_required_fields`, `check_state`, `check_country`, `check_condition`, and `check_levels` (previously `step_drop_levels`). These should all be called after adding evaluations
* New `check` functions add specific info to `r_message`.
* New helper functions for `check_*`s; `dt_rm_errors`, `dt_rm_evaluations`, and `dt_add_message`.
* `add_json` gained arguments to include/exclude specs from the JSON.
* `attr_data` checks for uniqueness of rows. Takes the first match for each unique value in
`AttributeName`.
* Changed `merge_region()` back to `add_region()`, to reflect the change below.
* Changed `ref_regions` to `region_dt` in `add_region()`. 
* Added `region_list` argument to `add_regions()`. This takes a named list of the
  form `list(region = c(country1, country2, ...))`. While this splits the
  specification of region into the table provided and a named list, it keeps all
  the information in one step. Additionally, it removes the need to assign
  country as state or some other work around to use the table.
* Changed `cv_weeks()` to `cv_model()`, which better reflects the fact it
 can be specified using any time period.
* `cv_model()` no longer scales the evaluation for you using `step_scale_index()`.
* Added `cv_compare()`. This allows for easy comparison of a combination of
 models, data, and post processing steps. See documentation for details.
* `add_factor_group()` now correctly assigns groups.
* `add_simulations()` no longer adds an `origin` column, whose value has now 
been rolled into `data_type`.
* `gather_info()` no longer accepts the bad levels from `check_slope_coefficients()`.
These should be applied using `step_drop_levels()`.
* `cache_dependency()` now accepts 1 source variable with multiple derived variables.
You may find this particularly useful when using conditional attributes.
* `filter_review_status_id` no longer removes listings with `sale_price == list_price`.


-----


## **Version 0.2.0**

### *Breaking changes* (I'm sure some changes slipped through the cracks. Sorry!)
Initially, several operations were keyed to the `data_type` column. This has proved
to be cumbersome. The solution has been to essentially split `data_type` into 
two columns. One remains `data_type`, and it tells you where the data came from.
This is either "asking", "auction", "aftersale", or "simulated". The second is `eval_type`:
"auction" or "retail". 

* `set_aftersale_bounds()` is now `set_retail_bounds()`. Also, use `retail_floor()` 
instead of `aftersale_floor()`, etc. 
* Removed `asking_aftersale()` and `asking_auction()` helpers.


### *New functions*
* Added a new set of functions for use in `j` slot of a `data.table`;
  `dt_we()`, `dt_fe()`, `dt_mae()`, `dt_qae()`. They each take `pred`, `value`, 
  as arguments, defaulting to `evaluation` and `usd_sale_price`, respectively.
  `dt_qae()` also takes a quantile.
* Added `cv_model()`. This is very similar to `testWeeks` from `Framework.Base`.
  Note that it is automatically scaling the evaluations.
* Added `metrics()`. It takes `data`, `pred`, `value`, and `by`. `pred` and `value` 
 may be any numeric columns in `data`. `by` may be any
valid `by` expression for a `data.table`. By default, it returns the following by
 `eval_type` (auction or retail);
    + weighted error
    + fleet error
    + mean absolute error
    + median absolute error
    + 5th, 25th, 75th, and 95th percentile absolute errors
    + total evaluated
    + total listings
  
  This function allows for *very* easy pivot tables in R for those metrics. 
  Looking at the code should be illuminating on how to do this for any statistic
  you may wish to see by group frequently.

* Added `cv_compare()`. This compares models which differ ins pecification, differ in
training data, or both. It returns a `data.table` containing the metrics
from each model.
* Added `set_category_id()` and `category_id()`. `set_category_id()` will set
  industry, base category ID, and category ID. The set values will be printed 
  to the console. Use `category_id()` to access the value set by `set_category_id()`.
* Added `step_scale_index()`. This takes a column name or scalar. It will multiply
 or divide `col` by `index`, based on `op`.
* Added a method to `dplyr::filter()` for a recipe object. You can now use it
  within a recipe for custom filters. See documentation for `filter.recipe()`.
* New step `add_simulations()`. This simulates sale points based off of asking data.
  This is the replacement for `computeAskingMarkdown()` and `mergeToAsking()`. It is
  untested, but the general outline should be correct. Note that you can use it with
  all the data together, and it will add listings for both evaluation types.
  This does not use `rm_outliers()`.
* Added `featured_listings()`. This is a function (not a step) which will query
  the appropriate SQL table and compare IDs to identify which listings were featured.
  Adds the column "featured". Called in `get_data`, so it is unecessary to call directly.
* New step `validate_domain()`. Sets values violating the domain of the model predictor
  to `NA_real_`. The domain is determined as a percentage of the min/max values.
  So `c(1,1)` will use the min/max, c(1, 1.5) will `NA` values above 150% of the max. 
  Set `range` manually for hardcoded limits. Useful for one-sided limits, such as age > 0.
  __Needs to be rethought__
* Added `extract_ref()`. This will return the reference data tables which are present
 in a prepped recipe. You may provide a specific step name to just return the reference
 from that. Steps without references which are data tables will be skipped.
* New step `add_count()`. Adds a count to each listing based on `by`. 

### *Changes*
* `format_class()` now coerces variable to the correct type, based on the state
 of the data provided to `recipe()`. Ideally, this will not affect anything you
 do locally.
* Updated `get_response()`, an internal function, to more reliably identify the response
 variable if passed a character string.
* Updated `market_correction()` to subtract "correction" from 1. We have always done
  this outside of the function to center around 1.
* It looks  like `Framework.Base::prepAsking()` is covered by several current steps:
    + `merge_region()` to add region
    + `add_age()` to add age
    + `add_summary()` to compute mean, median, and sd by make_model on usd_sale_price
    + New `filter.recipe()` method to perform the subset passing for example,
    `usd_sale_price <= median + deviation*1.7 | is.na(deviation)`
* Removed `load_conditional_attributes()`.
* Removed region from default selections for `get_all_data()`.
  `region_table()` now caches the region dependency, so there is no need to call it
  in the script. This function is called by `merge_region()` if you don't provide a table.
* `add_specs()` additions will now be coerced to a class based on the corresponding 
base spec, if present. Otherwise, best efforts are made to determine if it should be numeric.
Messages are printed. See documentation for more info.
* `step_replace()` and `step_replace_na()` may now be provided with a single prefix. Every
  `NA` base spec value will be replaced with the prefixed spec value.
* `cache_dependency()` now walks the dependency tree. This means if `age_group` depends on
  `age`, and `age` depends on `year`, the system will know that `age_group` depends on `year`.
* `add_fe_message()` takes about 10% of the time it did before.
* `rm_outliers()` and `step_rm_outliers()` gain a `by` argument. This should be
 a vector of column names. The data will be split and modeled separately, with
 outliers removed from each group.

### *TO-DO*
* ~~Test `add_simulations()`.~~
* Test `validate_domain()`.
* ~~Test `featured_listings()`.~~
* Test `summary()` methods.
* Test `summarize_steps()`.
* ~~Test `add_summary()`.~~
* ~~Test `step_scale_index()`~~


-----


## **Version 0.1.4** 
##### 2018-01-31


### *Changes*
* Documentation now uses [Markdown](https://github.com/adam-p/markdown-here/wiki/Markdown-Cheatsheet)
  instead of the Rd markup. Basically, this means it is much easier to link functions,
  bold, quote, etc.
* Added a new method, `summary` for recipes and steps. Depending on the input,
  `summary()` will output rectangular data containing information about the object.
  This output can differ depending on whether the step is trained.
  The `summary()` method will return `NULL` if no method exists for the specific
  step operation.
* Added `summarize_steps()`, which will iterate through the steps of a recipe with `summary()`, and
  return the results in a list.
* `predict_tiers()` now has a step equivalent of `add_evaluations()`. 
* Updated all steps to have the appropriate prefix.
* New step: `add_summary()` will add a column to the data consisting of the
  summary statistic computed on the column(s) by group.
* Some functions were renamed to be less verbose. By using `package?shtrain`
  and looking at the index link on bottom, the changes should be fairly clear.
* With the adaptation of most functions to work in-recipe, out-of-recipe
  versions have been prefixed with ".". so for example `add_age()` is for recipes and
  `.add_age()` is for data frames.This isn't fully completed.
* Added valid currencies for "united kingdom" in `filter_sale_currency()`.
* Rolled `format_state()`, which basically just convered "" to NA_character_,
* into `format_character()`.
* Reorganized files
* Updated documentation.

### *TO-DO*
* Rethink `check_range()` and convert to a step.
* Rename `check_slope_coefficients()` to indicate it is not a step.Perhaps
  `bad_slopes()`?
* Finish testing `cleanse_numerics()`.
* ~~Consider a new set of `validate()` functions which will set inputs to NA if not meeting some criteria.
  These will take the place of the requirements we pass now in some sense.~~
* ~~Provide a step for scaling evaluations up and down by a correction.~~
* ~~Adapt functions Henry wrote to work within the framework.~~
* ~~ Rework "export_sql.R" and "export_functions" to reduce size of serialized object.~~
* ~~Determine logic for region merging in R. Once done, remove Region from default selection for data retrieval~~
* Put `cleanse_numerics()` into step form.
* ~~Add `set_category_id()`. This will set industry, base_category_id, and output the results
 to the console when working interactively.~~
* ~~Is `load_conditional_attributes()` still needed?


-----


## **Version 0.1.3** 
##### 2018-01-25

### *Changes*
* generate_data.R SQL connection from SISQLDWSTG1 to default
* Fixed `add_link` for trailers.
* Changed to `DECIMAL(18,2)` from `REAL` for numeric SQL data type
* Changed default ordering in `format_order`
* Updated `load_conditional_attributes` to new naming conventions
* `cleanse_numerics` perfectly matches output of the current version for dimensional specs.
* Added logic to `step_bound_evaluations()` to choose max of floor price, lower bound, min of ceiling, upper bound.
* Added several functions to support  recipe export: `sql_recipe()`, `post_recipe()`, 
    `score_models()`, `copy_package()`, and `best_eval()`. See documentation for use.
* Revisted package loading code. Updated, and still rely on `command_arguments()` pasted in.
     This is so `shtrain` does not depend on `shconfig`. This is important to prevent
     difficulties in package development.
* `replace_na_specs` was incorrectly determining listings to modify. This is now fixed. 
    Resolved an issue related to 'invalid' manufacturer or model values.
* All references to `retail` have been updated to `asking`. 
* `step_class` has been updated to convert factors to characters, and initialize an
    'r_message' column for diagnostic information on each listing.
* Added `format_state()` to set "" to `NA_character_`.   
* Added `step_drop_levels()`. This removes levels from the data. It takes in either a list,     or a data.table with columns 'factor' and 'level', such as that returned by      `check_slope_coefficients()`. Untested.

### *TO-DO*
* Remove aftersale filter from view, move into R
* ~~Change `filter_sale_currency()` to accept additional val                   id currency/country combos~~
  - Instead, add as we roll out to countries since we want to apply across the board.
* Rethink `format_1_0()`
* Finish testing `cleanse_numerics`
* ~~Consider a new set of `validate()` functions which will set inputs to NA if not meeting some criteria.~~
* ~~Adapt functions Henry wrote to work within the framework.~~
* ~~Alter step naming scheme?~~
* Implement unit testing
* ~~Rework "export_sql.R" and "export_functions" to reduce size of serialized object.~~
* ~~Make additions to `format_state` to handle countries with no state, such as the UK.~~
* ~~Determine logic for region merging in R. Once done, remove Region from default selection for data retrieval~~